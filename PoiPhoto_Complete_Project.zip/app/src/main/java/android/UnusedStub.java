package android;

public final class UnusedStub {
    private UnusedStub() {
    }
}
