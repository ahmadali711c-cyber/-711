package com.google.android.gms.internal;

import org.json.JSONObject;

@ey
public final class ad {
    private final String mD;
    private final JSONObject mE;
    private final String mF;
    private final String mG;

    public ad(String str, gs gsVar, String str2, JSONObject jSONObject) {
        this.mG = gsVar.wS;
        this.mE = jSONObject;
        this.mF = str;
        this.mD = str2;
    }

    public String aE() {
        return this.mD;
    }

    public String aF() {
        return this.mG;
    }

    public JSONObject aG() {
        return this.mE;
    }

    public String aH() {
        return this.mF;
    }
}
