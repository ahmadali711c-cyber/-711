package com.google.android.gms.internal;

import com.google.android.gms.ads.doubleclick.b;
import com.google.android.gms.internal.br;

@ey
public final class bs extends br.a {
    private final b oO;

    public bs(b bVar) {
        this.oO = bVar;
    }

    public void a(bq bqVar) {
        this.oO.a(new bp(bqVar));
    }
}
