package com.google.android.gms.internal;

import android.os.IInterface;
import android.os.RemoteException;

public interface by extends IInterface {
    void a(bw bwVar) throws RemoteException;
}
