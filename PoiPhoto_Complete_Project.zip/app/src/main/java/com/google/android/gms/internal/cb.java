package com.google.android.gms.internal;

public interface cb {
    void onAppEvent(String str, String str2);
}
