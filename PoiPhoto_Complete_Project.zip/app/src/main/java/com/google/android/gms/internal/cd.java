package com.google.android.gms.internal;

import java.util.Map;

public interface cd {
    void a(gu guVar, Map<String, String> map);
}
