package com.google.android.gms.internal;

import java.util.Map;

@ey
public class cf implements cd {
    private final cg qa;

    public cf(cg cgVar) {
        this.qa = cgVar;
    }

    public void a(gu guVar, Map<String, String> map) {
        this.qa.d("1".equals(map.get("transparentBackground")));
    }
}
