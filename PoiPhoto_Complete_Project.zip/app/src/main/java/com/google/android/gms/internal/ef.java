package com.google.android.gms.internal;

@ey
public final class ef {
    public long sT;
    public final String sU;
    public final String sV;

    public ef(long j, String str, String str2) {
        this.sT = j;
        this.sV = str;
        this.sU = str2;
    }

    public ef(String str, String str2) {
        this.sV = str;
        this.sU = str2;
    }
}
