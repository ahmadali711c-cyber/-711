package com.google.android.gms.internal;

import com.google.android.gms.internal.fn;
import java.util.concurrent.ExecutionException;
import org.json.JSONException;
import org.json.JSONObject;

@ey
public class fo implements fn.a<bt> {
    /* renamed from: b */
    public bt a(fn fnVar, JSONObject jSONObject) throws JSONException, InterruptedException, ExecutionException {
        return new bt(jSONObject.getString("headline"), fnVar.a(jSONObject, "image", true).get(), jSONObject.getString("body"), fnVar.a(jSONObject, "app_icon", true).get(), jSONObject.getString("call_to_action"), jSONObject.optDouble("rating", -1.0d), jSONObject.optString("store"), jSONObject.optString("price"));
    }
}
