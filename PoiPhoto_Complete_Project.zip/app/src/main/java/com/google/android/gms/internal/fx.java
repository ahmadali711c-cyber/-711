package com.google.android.gms.internal;

@ey
public final class fx implements fw {
    public String K(String str) {
        return null;
    }
}
