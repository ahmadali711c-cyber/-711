package com.google.android.gms.internal;

import android.content.Context;
import android.view.MotionEvent;

public interface g {
    String a(Context context);

    String a(Context context, String str);

    void a(int i, int i2, int i3);

    void a(MotionEvent motionEvent);
}
