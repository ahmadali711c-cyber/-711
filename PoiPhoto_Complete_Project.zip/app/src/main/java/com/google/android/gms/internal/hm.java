package com.google.android.gms.internal;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.internal.hl;

public class hm implements Parcelable.Creator<hl.a> {
    static void a(hl.a aVar, Parcel parcel, int i) {
        int H = b.H(parcel);
        b.a(parcel, 1, (Parcelable) aVar.Dc, i, false);
        b.c(parcel, 1000, aVar.CK);
        b.H(parcel, H);
    }

    /* renamed from: N */
    public hl.a[] newArray(int i) {
        return new hl.a[i];
    }

    /* renamed from: p */
    public hl.a createFromParcel(Parcel parcel) {
        int G = a.G(parcel);
        int i = 0;
        Account account = null;
        while (parcel.dataPosition() < G) {
            int F = a.F(parcel);
            switch (a.aH(F)) {
                case 1:
                    account = (Account) a.a(parcel, F, Account.CREATOR);
                    break;
                case 1000:
                    i = a.g(parcel, F);
                    break;
                default:
                    a.b(parcel, F);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new hl.a(i, account);
        }
        throw new a.C0004a("Overread allowed size end=" + G, parcel);
    }
}
