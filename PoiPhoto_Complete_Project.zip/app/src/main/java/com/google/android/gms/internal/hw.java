package com.google.android.gms.internal;

import android.os.ParcelFileDescriptor;
import com.google.android.gms.common.api.BaseImplementation;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.hl;
import com.google.android.gms.internal.hv;

public abstract class hw<T> extends hv.a {
    protected BaseImplementation.b<T> DA;

    public hw(BaseImplementation.b<T> bVar) {
        this.DA = bVar;
    }

    public void a(Status status) {
    }

    public void a(Status status, ParcelFileDescriptor parcelFileDescriptor) {
    }

    public void a(Status status, boolean z) {
    }

    public void a(hl.b bVar) {
    }
}
