package com.google.android.gms.internal;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndexApi;
import com.google.android.gms.internal.hd;
import com.google.android.gms.internal.hp;
import com.google.android.gms.internal.mv;
import com.google.android.gms.plus.PlusShare;
import java.util.ArrayList;
import java.util.List;

public class hy {
    private static hh a(String str, mv.c cVar) {
        return new hh(qw.f(cVar), new hp.a(str).G(true).au(str).at("blob").fG());
    }

    public static hr a(Action action, String str, long j, String str2, int i) {
        Bundle bundle = new Bundle();
        bundle.putAll(action.fI());
        Bundle bundle2 = bundle.getBundle("object");
        Uri parse = bundle2.containsKey("id") ? Uri.parse(bundle2.getString("id")) : null;
        String string = bundle2.getString("name");
        String string2 = bundle2.getString("type");
        Intent a = hz.a(str2, Uri.parse(bundle2.getString(PlusShare.KEY_CALL_TO_ACTION_URL)));
        hd.a a2 = hr.a(a, string, parse, string2, (List<AppIndexApi.AppIndexingLink>) null);
        a2.a(a(".private:action", d(action.fI())));
        a2.a(aw(str));
        return new hr(hr.a(str2, a), j, i, (String) null, a2.fD());
    }

    private static hh aw(String str) {
        return new hh(str, new hp.a(".private:actionId").G(true).au(".private:actionId").at("blob").fG());
    }

    static mv.c d(Bundle bundle) {
        mv.c cVar = new mv.c();
        ArrayList arrayList = new ArrayList();
        for (String str : bundle.keySet()) {
            Object obj = bundle.get(str);
            mv.b bVar = new mv.b();
            bVar.name = str;
            bVar.afz = new mv.d();
            if (obj instanceof String) {
                bVar.afz.NJ = (String) obj;
            } else if (obj instanceof Bundle) {
                bVar.afz.afE = d((Bundle) obj);
            } else {
                Log.e("AppDataSearchClient", "Unsupported value: " + obj);
            }
            arrayList.add(bVar);
        }
        if (bundle.containsKey("type")) {
            cVar.type = bundle.getString("type");
        }
        cVar.afA = (mv.b[]) arrayList.toArray(new mv.b[arrayList.size()]);
        return cVar;
    }
}
