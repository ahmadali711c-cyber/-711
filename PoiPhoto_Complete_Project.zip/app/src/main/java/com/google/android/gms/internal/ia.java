package com.google.android.gms.internal;

import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.internal.ic;

public abstract class ia extends ic.a {
    public void T(int i) {
    }

    public void a(int i, DataHolder dataHolder) {
    }

    public void a(DataHolder dataHolder) {
    }

    public void e(int i, int i2) {
    }

    public void fK() {
    }
}
