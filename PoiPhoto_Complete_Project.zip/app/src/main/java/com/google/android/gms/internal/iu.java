package com.google.android.gms.internal;

import java.io.IOException;

public interface iu {
    void a(String str, String str2, long j, String str3) throws IOException;

    long fS();
}
