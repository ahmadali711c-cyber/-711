package com.google.android.gms.internal;

public class jf {
    public static final boolean Mv = hl();

    private static final boolean hl() {
        return false;
    }
}
