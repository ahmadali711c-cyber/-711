package com.google.android.gms.internal;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface jt extends IInterface {

    public static abstract class a extends Binder implements jt {

        /* renamed from: com.google.android.gms.internal.jt$a$a  reason: collision with other inner class name */
        private static class C0060a implements jt {
            private IBinder le;

            C0060a(IBinder iBinder) {
                this.le = iBinder;
            }

            public void a(js jsVar, int i) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    this.le.transact(4, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(js jsVar, int i, String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    this.le.transact(3, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(js jsVar, int i, String str, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(2, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(js jsVar, int i, String str, IBinder iBinder, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    obtain.writeStrongBinder(iBinder);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(19, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(js jsVar, int i, String str, String str2) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    this.le.transact(34, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(js jsVar, int i, String str, String str2, String str3, String[] strArr) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeString(str3);
                    obtain.writeStringArray(strArr);
                    this.le.transact(33, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(js jsVar, int i, String str, String str2, String[] strArr) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeStringArray(strArr);
                    this.le.transact(10, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(js jsVar, int i, String str, String str2, String[] strArr, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeStringArray(strArr);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(30, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(js jsVar, int i, String str, String str2, String[] strArr, String str3, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeStringArray(strArr);
                    obtain.writeString(str3);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(js jsVar, int i, String str, String str2, String[] strArr, String str3, IBinder iBinder, String str4, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeStringArray(strArr);
                    obtain.writeString(str3);
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeString(str4);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(9, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(js jsVar, int i, String str, String[] strArr, String str2, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    obtain.writeStringArray(strArr);
                    obtain.writeString(str2);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(20, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(js jsVar, jj jjVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    if (jjVar != null) {
                        obtain.writeInt(1);
                        jjVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(46, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public IBinder asBinder() {
                return this.le;
            }

            public void b(js jsVar, int i, String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    this.le.transact(21, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void b(js jsVar, int i, String str, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(5, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void b(js jsVar, int i, String str, String str2, String[] strArr) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeStringArray(strArr);
                    this.le.transact(28, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void c(js jsVar, int i, String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    this.le.transact(22, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void c(js jsVar, int i, String str, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(6, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void d(js jsVar, int i, String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    this.le.transact(24, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void d(js jsVar, int i, String str, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(7, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void e(js jsVar, int i, String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    this.le.transact(26, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void e(js jsVar, int i, String str, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(8, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void f(js jsVar, int i, String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    this.le.transact(31, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void f(js jsVar, int i, String str, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(11, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void g(js jsVar, int i, String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    this.le.transact(32, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void g(js jsVar, int i, String str, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(12, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void h(js jsVar, int i, String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    this.le.transact(35, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void h(js jsVar, int i, String str, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(13, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void i(js jsVar, int i, String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    this.le.transact(36, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void i(js jsVar, int i, String str, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(14, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void j(js jsVar, int i, String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    this.le.transact(40, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void j(js jsVar, int i, String str, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(15, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void k(js jsVar, int i, String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    this.le.transact(42, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void k(js jsVar, int i, String str, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(16, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void l(js jsVar, int i, String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    this.le.transact(44, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void l(js jsVar, int i, String str, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(17, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void m(js jsVar, int i, String str, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(18, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void n(js jsVar, int i, String str, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(23, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void o(js jsVar, int i, String str, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(25, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void p(js jsVar, int i, String str, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(27, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void q(js jsVar, int i, String str, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(37, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void r(js jsVar, int i, String str, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(38, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void s(js jsVar, int i, String str, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(41, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void t(js jsVar, int i, String str, Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.IGmsServiceBroker");
                    obtain.writeStrongBinder(jsVar != null ? jsVar.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    if (bundle != null) {
                        obtain.writeInt(1);
                        bundle.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(43, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }

        public static jt Q(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.common.internal.IGmsServiceBroker");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof jt)) ? new C0060a(iBinder) : (jt) queryLocalInterface;
        }

        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v1, resolved type: com.google.android.gms.internal.jj} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v10, resolved type: android.os.Bundle} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v19, resolved type: android.os.Bundle} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v28, resolved type: android.os.Bundle} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v33, resolved type: android.os.Bundle} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v71, resolved type: android.os.Bundle} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v80, resolved type: android.os.Bundle} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v89, resolved type: android.os.Bundle} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v112, resolved type: android.os.Bundle} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v117, resolved type: android.os.Bundle} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v122, resolved type: android.os.Bundle} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v127, resolved type: android.os.Bundle} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v132, resolved type: android.os.Bundle} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v137, resolved type: android.os.Bundle} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v142, resolved type: android.os.Bundle} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v147, resolved type: android.os.Bundle} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v161, resolved type: android.os.Bundle} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v166, resolved type: android.os.Bundle} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v171, resolved type: android.os.Bundle} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v176, resolved type: android.os.Bundle} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v189, resolved type: android.os.Bundle} */
        /* JADX WARNING: type inference failed for: r0v0 */
        /* JADX WARNING: type inference failed for: r0v202 */
        /* JADX WARNING: type inference failed for: r0v203 */
        /* JADX WARNING: type inference failed for: r0v204 */
        /* JADX WARNING: type inference failed for: r0v205 */
        /* JADX WARNING: type inference failed for: r0v206 */
        /* JADX WARNING: type inference failed for: r0v207 */
        /* JADX WARNING: type inference failed for: r0v208 */
        /* JADX WARNING: type inference failed for: r0v209 */
        /* JADX WARNING: type inference failed for: r0v210 */
        /* JADX WARNING: type inference failed for: r0v211 */
        /* JADX WARNING: type inference failed for: r0v212 */
        /* JADX WARNING: type inference failed for: r0v213 */
        /* JADX WARNING: type inference failed for: r0v214 */
        /* JADX WARNING: type inference failed for: r0v215 */
        /* JADX WARNING: type inference failed for: r0v216 */
        /* JADX WARNING: type inference failed for: r0v217 */
        /* JADX WARNING: type inference failed for: r0v218 */
        /* JADX WARNING: type inference failed for: r0v219 */
        /* JADX WARNING: type inference failed for: r0v220 */
        /* JADX WARNING: type inference failed for: r0v221 */
        /* JADX WARNING: type inference failed for: r0v222 */
        /* JADX WARNING: Multi-variable type inference failed */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean onTransact(int r12, android.os.Parcel r13, android.os.Parcel r14, int r15) throws android.os.RemoteException {
            /*
                r11 = this;
                r0 = 0
                r10 = 1
                switch(r12) {
                    case 1: goto L_0x0011;
                    case 2: goto L_0x004c;
                    case 3: goto L_0x0077;
                    case 4: goto L_0x0095;
                    case 5: goto L_0x00af;
                    case 6: goto L_0x00db;
                    case 7: goto L_0x0107;
                    case 8: goto L_0x0133;
                    case 9: goto L_0x015f;
                    case 10: goto L_0x01a3;
                    case 11: goto L_0x01ca;
                    case 12: goto L_0x01f6;
                    case 13: goto L_0x0222;
                    case 14: goto L_0x024e;
                    case 15: goto L_0x027a;
                    case 16: goto L_0x02a6;
                    case 17: goto L_0x02d2;
                    case 18: goto L_0x02fe;
                    case 19: goto L_0x032a;
                    case 20: goto L_0x035e;
                    case 21: goto L_0x0396;
                    case 22: goto L_0x03b4;
                    case 23: goto L_0x03d2;
                    case 24: goto L_0x03fe;
                    case 25: goto L_0x041c;
                    case 26: goto L_0x0448;
                    case 27: goto L_0x0466;
                    case 28: goto L_0x0492;
                    case 30: goto L_0x04b9;
                    case 31: goto L_0x04f1;
                    case 32: goto L_0x050f;
                    case 33: goto L_0x052d;
                    case 34: goto L_0x0558;
                    case 35: goto L_0x057a;
                    case 36: goto L_0x0598;
                    case 37: goto L_0x05b6;
                    case 38: goto L_0x05e2;
                    case 40: goto L_0x060e;
                    case 41: goto L_0x062c;
                    case 42: goto L_0x0658;
                    case 43: goto L_0x0676;
                    case 44: goto L_0x06a2;
                    case 46: goto L_0x06c0;
                    case 1598968902: goto L_0x000a;
                    default: goto L_0x0005;
                }
            L_0x0005:
                boolean r0 = super.onTransact(r12, r13, r14, r15)
            L_0x0009:
                return r0
            L_0x000a:
                java.lang.String r0 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r14.writeString(r0)
                r0 = r10
                goto L_0x0009
            L_0x0011:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                java.lang.String r4 = r13.readString()
                java.lang.String[] r5 = r13.createStringArray()
                java.lang.String r6 = r13.readString()
                int r7 = r13.readInt()
                if (r7 == 0) goto L_0x004a
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
                r7 = r0
            L_0x0041:
                r0 = r11
                r0.a(r1, r2, r3, r4, r5, r6, r7)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x004a:
                r7 = r0
                goto L_0x0041
            L_0x004c:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                int r4 = r13.readInt()
                if (r4 == 0) goto L_0x006f
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
            L_0x006f:
                r11.a((com.google.android.gms.internal.js) r1, (int) r2, (java.lang.String) r3, (android.os.Bundle) r0)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x0077:
                java.lang.String r0 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r0)
                android.os.IBinder r0 = r13.readStrongBinder()
                com.google.android.gms.internal.js r0 = com.google.android.gms.internal.js.a.P(r0)
                int r1 = r13.readInt()
                java.lang.String r2 = r13.readString()
                r11.a(r0, r1, r2)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x0095:
                java.lang.String r0 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r0)
                android.os.IBinder r0 = r13.readStrongBinder()
                com.google.android.gms.internal.js r0 = com.google.android.gms.internal.js.a.P(r0)
                int r1 = r13.readInt()
                r11.a((com.google.android.gms.internal.js) r0, (int) r1)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x00af:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                int r4 = r13.readInt()
                if (r4 == 0) goto L_0x00d2
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
            L_0x00d2:
                r11.b(r1, r2, r3, r0)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x00db:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                int r4 = r13.readInt()
                if (r4 == 0) goto L_0x00fe
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
            L_0x00fe:
                r11.c(r1, r2, r3, r0)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x0107:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                int r4 = r13.readInt()
                if (r4 == 0) goto L_0x012a
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
            L_0x012a:
                r11.d(r1, r2, r3, r0)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x0133:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                int r4 = r13.readInt()
                if (r4 == 0) goto L_0x0156
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
            L_0x0156:
                r11.e(r1, r2, r3, r0)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x015f:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                java.lang.String r4 = r13.readString()
                java.lang.String[] r5 = r13.createStringArray()
                java.lang.String r6 = r13.readString()
                android.os.IBinder r7 = r13.readStrongBinder()
                java.lang.String r8 = r13.readString()
                int r9 = r13.readInt()
                if (r9 == 0) goto L_0x01a1
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
                r9 = r0
            L_0x0197:
                r0 = r11
                r0.a(r1, r2, r3, r4, r5, r6, r7, r8, r9)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x01a1:
                r9 = r0
                goto L_0x0197
            L_0x01a3:
                java.lang.String r0 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r0)
                android.os.IBinder r0 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r0)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                java.lang.String r4 = r13.readString()
                java.lang.String[] r5 = r13.createStringArray()
                r0 = r11
                r0.a((com.google.android.gms.internal.js) r1, (int) r2, (java.lang.String) r3, (java.lang.String) r4, (java.lang.String[]) r5)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x01ca:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                int r4 = r13.readInt()
                if (r4 == 0) goto L_0x01ed
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
            L_0x01ed:
                r11.f(r1, r2, r3, r0)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x01f6:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                int r4 = r13.readInt()
                if (r4 == 0) goto L_0x0219
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
            L_0x0219:
                r11.g(r1, r2, r3, r0)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x0222:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                int r4 = r13.readInt()
                if (r4 == 0) goto L_0x0245
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
            L_0x0245:
                r11.h(r1, r2, r3, r0)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x024e:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                int r4 = r13.readInt()
                if (r4 == 0) goto L_0x0271
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
            L_0x0271:
                r11.i(r1, r2, r3, r0)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x027a:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                int r4 = r13.readInt()
                if (r4 == 0) goto L_0x029d
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
            L_0x029d:
                r11.j(r1, r2, r3, r0)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x02a6:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                int r4 = r13.readInt()
                if (r4 == 0) goto L_0x02c9
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
            L_0x02c9:
                r11.k(r1, r2, r3, r0)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x02d2:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                int r4 = r13.readInt()
                if (r4 == 0) goto L_0x02f5
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
            L_0x02f5:
                r11.l(r1, r2, r3, r0)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x02fe:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                int r4 = r13.readInt()
                if (r4 == 0) goto L_0x0321
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
            L_0x0321:
                r11.m(r1, r2, r3, r0)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x032a:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                android.os.IBinder r4 = r13.readStrongBinder()
                int r5 = r13.readInt()
                if (r5 == 0) goto L_0x035c
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
                r5 = r0
            L_0x0352:
                r0 = r11
                r0.a((com.google.android.gms.internal.js) r1, (int) r2, (java.lang.String) r3, (android.os.IBinder) r4, (android.os.Bundle) r5)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x035c:
                r5 = r0
                goto L_0x0352
            L_0x035e:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                java.lang.String[] r4 = r13.createStringArray()
                java.lang.String r5 = r13.readString()
                int r6 = r13.readInt()
                if (r6 == 0) goto L_0x0394
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
                r6 = r0
            L_0x038a:
                r0 = r11
                r0.a((com.google.android.gms.internal.js) r1, (int) r2, (java.lang.String) r3, (java.lang.String[]) r4, (java.lang.String) r5, (android.os.Bundle) r6)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x0394:
                r6 = r0
                goto L_0x038a
            L_0x0396:
                java.lang.String r0 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r0)
                android.os.IBinder r0 = r13.readStrongBinder()
                com.google.android.gms.internal.js r0 = com.google.android.gms.internal.js.a.P(r0)
                int r1 = r13.readInt()
                java.lang.String r2 = r13.readString()
                r11.b(r0, r1, r2)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x03b4:
                java.lang.String r0 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r0)
                android.os.IBinder r0 = r13.readStrongBinder()
                com.google.android.gms.internal.js r0 = com.google.android.gms.internal.js.a.P(r0)
                int r1 = r13.readInt()
                java.lang.String r2 = r13.readString()
                r11.c(r0, r1, r2)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x03d2:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                int r4 = r13.readInt()
                if (r4 == 0) goto L_0x03f5
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
            L_0x03f5:
                r11.n(r1, r2, r3, r0)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x03fe:
                java.lang.String r0 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r0)
                android.os.IBinder r0 = r13.readStrongBinder()
                com.google.android.gms.internal.js r0 = com.google.android.gms.internal.js.a.P(r0)
                int r1 = r13.readInt()
                java.lang.String r2 = r13.readString()
                r11.d(r0, r1, r2)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x041c:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                int r4 = r13.readInt()
                if (r4 == 0) goto L_0x043f
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
            L_0x043f:
                r11.o(r1, r2, r3, r0)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x0448:
                java.lang.String r0 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r0)
                android.os.IBinder r0 = r13.readStrongBinder()
                com.google.android.gms.internal.js r0 = com.google.android.gms.internal.js.a.P(r0)
                int r1 = r13.readInt()
                java.lang.String r2 = r13.readString()
                r11.e(r0, r1, r2)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x0466:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                int r4 = r13.readInt()
                if (r4 == 0) goto L_0x0489
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
            L_0x0489:
                r11.p(r1, r2, r3, r0)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x0492:
                java.lang.String r0 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r0)
                android.os.IBinder r0 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r0)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                java.lang.String r4 = r13.readString()
                java.lang.String[] r5 = r13.createStringArray()
                r0 = r11
                r0.b(r1, r2, r3, r4, r5)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x04b9:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                java.lang.String r4 = r13.readString()
                java.lang.String[] r5 = r13.createStringArray()
                int r6 = r13.readInt()
                if (r6 == 0) goto L_0x04ef
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
                r6 = r0
            L_0x04e5:
                r0 = r11
                r0.a((com.google.android.gms.internal.js) r1, (int) r2, (java.lang.String) r3, (java.lang.String) r4, (java.lang.String[]) r5, (android.os.Bundle) r6)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x04ef:
                r6 = r0
                goto L_0x04e5
            L_0x04f1:
                java.lang.String r0 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r0)
                android.os.IBinder r0 = r13.readStrongBinder()
                com.google.android.gms.internal.js r0 = com.google.android.gms.internal.js.a.P(r0)
                int r1 = r13.readInt()
                java.lang.String r2 = r13.readString()
                r11.f(r0, r1, r2)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x050f:
                java.lang.String r0 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r0)
                android.os.IBinder r0 = r13.readStrongBinder()
                com.google.android.gms.internal.js r0 = com.google.android.gms.internal.js.a.P(r0)
                int r1 = r13.readInt()
                java.lang.String r2 = r13.readString()
                r11.g(r0, r1, r2)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x052d:
                java.lang.String r0 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r0)
                android.os.IBinder r0 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r0)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                java.lang.String r4 = r13.readString()
                java.lang.String r5 = r13.readString()
                java.lang.String[] r6 = r13.createStringArray()
                r0 = r11
                r0.a((com.google.android.gms.internal.js) r1, (int) r2, (java.lang.String) r3, (java.lang.String) r4, (java.lang.String) r5, (java.lang.String[]) r6)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x0558:
                java.lang.String r0 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r0)
                android.os.IBinder r0 = r13.readStrongBinder()
                com.google.android.gms.internal.js r0 = com.google.android.gms.internal.js.a.P(r0)
                int r1 = r13.readInt()
                java.lang.String r2 = r13.readString()
                java.lang.String r3 = r13.readString()
                r11.a((com.google.android.gms.internal.js) r0, (int) r1, (java.lang.String) r2, (java.lang.String) r3)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x057a:
                java.lang.String r0 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r0)
                android.os.IBinder r0 = r13.readStrongBinder()
                com.google.android.gms.internal.js r0 = com.google.android.gms.internal.js.a.P(r0)
                int r1 = r13.readInt()
                java.lang.String r2 = r13.readString()
                r11.h(r0, r1, r2)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x0598:
                java.lang.String r0 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r0)
                android.os.IBinder r0 = r13.readStrongBinder()
                com.google.android.gms.internal.js r0 = com.google.android.gms.internal.js.a.P(r0)
                int r1 = r13.readInt()
                java.lang.String r2 = r13.readString()
                r11.i(r0, r1, r2)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x05b6:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                int r4 = r13.readInt()
                if (r4 == 0) goto L_0x05d9
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
            L_0x05d9:
                r11.q(r1, r2, r3, r0)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x05e2:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                int r4 = r13.readInt()
                if (r4 == 0) goto L_0x0605
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
            L_0x0605:
                r11.r(r1, r2, r3, r0)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x060e:
                java.lang.String r0 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r0)
                android.os.IBinder r0 = r13.readStrongBinder()
                com.google.android.gms.internal.js r0 = com.google.android.gms.internal.js.a.P(r0)
                int r1 = r13.readInt()
                java.lang.String r2 = r13.readString()
                r11.j(r0, r1, r2)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x062c:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                int r4 = r13.readInt()
                if (r4 == 0) goto L_0x064f
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
            L_0x064f:
                r11.s(r1, r2, r3, r0)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x0658:
                java.lang.String r0 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r0)
                android.os.IBinder r0 = r13.readStrongBinder()
                com.google.android.gms.internal.js r0 = com.google.android.gms.internal.js.a.P(r0)
                int r1 = r13.readInt()
                java.lang.String r2 = r13.readString()
                r11.k(r0, r1, r2)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x0676:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                java.lang.String r3 = r13.readString()
                int r4 = r13.readInt()
                if (r4 == 0) goto L_0x0699
                android.os.Parcelable$Creator r0 = android.os.Bundle.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                android.os.Bundle r0 = (android.os.Bundle) r0
            L_0x0699:
                r11.t(r1, r2, r3, r0)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x06a2:
                java.lang.String r0 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r0)
                android.os.IBinder r0 = r13.readStrongBinder()
                com.google.android.gms.internal.js r0 = com.google.android.gms.internal.js.a.P(r0)
                int r1 = r13.readInt()
                java.lang.String r2 = r13.readString()
                r11.l(r0, r1, r2)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            L_0x06c0:
                java.lang.String r1 = "com.google.android.gms.common.internal.IGmsServiceBroker"
                r13.enforceInterface(r1)
                android.os.IBinder r1 = r13.readStrongBinder()
                com.google.android.gms.internal.js r1 = com.google.android.gms.internal.js.a.P(r1)
                int r2 = r13.readInt()
                if (r2 == 0) goto L_0x06db
                android.os.Parcelable$Creator<com.google.android.gms.internal.jj> r0 = com.google.android.gms.internal.jj.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r13)
                com.google.android.gms.internal.jj r0 = (com.google.android.gms.internal.jj) r0
            L_0x06db:
                r11.a((com.google.android.gms.internal.js) r1, (com.google.android.gms.internal.jj) r0)
                r14.writeNoException()
                r0 = r10
                goto L_0x0009
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.jt.a.onTransact(int, android.os.Parcel, android.os.Parcel, int):boolean");
        }
    }

    void a(js jsVar, int i) throws RemoteException;

    void a(js jsVar, int i, String str) throws RemoteException;

    void a(js jsVar, int i, String str, Bundle bundle) throws RemoteException;

    void a(js jsVar, int i, String str, IBinder iBinder, Bundle bundle) throws RemoteException;

    void a(js jsVar, int i, String str, String str2) throws RemoteException;

    void a(js jsVar, int i, String str, String str2, String str3, String[] strArr) throws RemoteException;

    void a(js jsVar, int i, String str, String str2, String[] strArr) throws RemoteException;

    void a(js jsVar, int i, String str, String str2, String[] strArr, Bundle bundle) throws RemoteException;

    void a(js jsVar, int i, String str, String str2, String[] strArr, String str3, Bundle bundle) throws RemoteException;

    void a(js jsVar, int i, String str, String str2, String[] strArr, String str3, IBinder iBinder, String str4, Bundle bundle) throws RemoteException;

    void a(js jsVar, int i, String str, String[] strArr, String str2, Bundle bundle) throws RemoteException;

    void a(js jsVar, jj jjVar) throws RemoteException;

    void b(js jsVar, int i, String str) throws RemoteException;

    void b(js jsVar, int i, String str, Bundle bundle) throws RemoteException;

    void b(js jsVar, int i, String str, String str2, String[] strArr) throws RemoteException;

    void c(js jsVar, int i, String str) throws RemoteException;

    void c(js jsVar, int i, String str, Bundle bundle) throws RemoteException;

    void d(js jsVar, int i, String str) throws RemoteException;

    void d(js jsVar, int i, String str, Bundle bundle) throws RemoteException;

    void e(js jsVar, int i, String str) throws RemoteException;

    void e(js jsVar, int i, String str, Bundle bundle) throws RemoteException;

    void f(js jsVar, int i, String str) throws RemoteException;

    void f(js jsVar, int i, String str, Bundle bundle) throws RemoteException;

    void g(js jsVar, int i, String str) throws RemoteException;

    void g(js jsVar, int i, String str, Bundle bundle) throws RemoteException;

    void h(js jsVar, int i, String str) throws RemoteException;

    void h(js jsVar, int i, String str, Bundle bundle) throws RemoteException;

    void i(js jsVar, int i, String str) throws RemoteException;

    void i(js jsVar, int i, String str, Bundle bundle) throws RemoteException;

    void j(js jsVar, int i, String str) throws RemoteException;

    void j(js jsVar, int i, String str, Bundle bundle) throws RemoteException;

    void k(js jsVar, int i, String str) throws RemoteException;

    void k(js jsVar, int i, String str, Bundle bundle) throws RemoteException;

    void l(js jsVar, int i, String str) throws RemoteException;

    void l(js jsVar, int i, String str, Bundle bundle) throws RemoteException;

    void m(js jsVar, int i, String str, Bundle bundle) throws RemoteException;

    void n(js jsVar, int i, String str, Bundle bundle) throws RemoteException;

    void o(js jsVar, int i, String str, Bundle bundle) throws RemoteException;

    void p(js jsVar, int i, String str, Bundle bundle) throws RemoteException;

    void q(js jsVar, int i, String str, Bundle bundle) throws RemoteException;

    void r(js jsVar, int i, String str, Bundle bundle) throws RemoteException;

    void s(js jsVar, int i, String str, Bundle bundle) throws RemoteException;

    void t(js jsVar, int i, String str, Bundle bundle) throws RemoteException;
}
