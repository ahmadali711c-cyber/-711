package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.BaseImplementation;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.kf;

public final class ke implements kd {

    private static class a extends kb {
        private final BaseImplementation.b<Status> Ea;

        public a(BaseImplementation.b<Status> bVar) {
            this.Ea = bVar;
        }

        public void aI(int i) throws RemoteException {
            this.Ea.b(new Status(i));
        }
    }

    public PendingResult<Status> c(GoogleApiClient googleApiClient) {
        return new kf.a(googleApiClient) {
            /* access modifiers changed from: protected */
            public void a(kg kgVar) throws RemoteException {
                ((ki) kgVar.hw()).a(new a(this));
            }
        }.gE();
    }
}
