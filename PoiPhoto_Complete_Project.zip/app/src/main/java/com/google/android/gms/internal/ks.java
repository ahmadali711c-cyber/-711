package com.google.android.gms.internal;

import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public abstract class ks extends kr implements SafeParcelable {
    public Object bc(String str) {
        return null;
    }

    public boolean bd(String str) {
        return false;
    }
}
