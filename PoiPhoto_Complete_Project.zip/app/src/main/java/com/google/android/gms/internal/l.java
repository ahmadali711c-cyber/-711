package com.google.android.gms.internal;

public class l extends Exception {
    public l() {
    }

    public l(String str) {
        super(str);
    }
}
