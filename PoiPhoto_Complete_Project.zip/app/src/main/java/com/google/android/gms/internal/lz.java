package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.fitness.request.DataDeleteRequest;
import com.google.android.gms.fitness.request.DataReadRequest;
import com.google.android.gms.fitness.request.DataSourcesRequest;
import com.google.android.gms.fitness.request.DataTypeCreateRequest;
import com.google.android.gms.fitness.request.SessionInsertRequest;
import com.google.android.gms.fitness.request.SessionReadRequest;
import com.google.android.gms.fitness.request.StartBleScanRequest;
import com.google.android.gms.fitness.request.aa;
import com.google.android.gms.fitness.request.ad;
import com.google.android.gms.fitness.request.af;
import com.google.android.gms.fitness.request.ah;
import com.google.android.gms.fitness.request.aj;
import com.google.android.gms.fitness.request.b;
import com.google.android.gms.fitness.request.e;
import com.google.android.gms.fitness.request.j;
import com.google.android.gms.fitness.request.m;
import com.google.android.gms.fitness.request.o;
import com.google.android.gms.fitness.request.q;
import com.google.android.gms.fitness.request.u;
import com.google.android.gms.fitness.request.w;
import com.google.android.gms.fitness.request.y;

public interface lz extends IInterface {

    public static abstract class a extends Binder implements lz {

        /* renamed from: com.google.android.gms.internal.lz$a$a  reason: collision with other inner class name */
        private static class C0067a implements lz {
            private IBinder le;

            C0067a(IBinder iBinder) {
                this.le = iBinder;
            }

            public void a(DataDeleteRequest dataDeleteRequest, md mdVar, String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                    if (dataDeleteRequest != null) {
                        obtain.writeInt(1);
                        dataDeleteRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(mdVar != null ? mdVar.asBinder() : null);
                    obtain.writeString(str);
                    this.le.transact(19, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(DataReadRequest dataReadRequest, lw lwVar, String str) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                    if (dataReadRequest != null) {
                        obtain.writeInt(1);
                        dataReadRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (lwVar != null) {
                        iBinder = lwVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeString(str);
                    this.le.transact(8, obtain, (Parcel) null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void a(DataSourcesRequest dataSourcesRequest, lx lxVar, String str) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                    if (dataSourcesRequest != null) {
                        obtain.writeInt(1);
                        dataSourcesRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (lxVar != null) {
                        iBinder = lxVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeString(str);
                    this.le.transact(1, obtain, (Parcel) null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void a(DataTypeCreateRequest dataTypeCreateRequest, ly lyVar, String str) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                    if (dataTypeCreateRequest != null) {
                        obtain.writeInt(1);
                        dataTypeCreateRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (lyVar != null) {
                        iBinder = lyVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeString(str);
                    this.le.transact(13, obtain, (Parcel) null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void a(SessionInsertRequest sessionInsertRequest, md mdVar, String str) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                    if (sessionInsertRequest != null) {
                        obtain.writeInt(1);
                        sessionInsertRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (mdVar != null) {
                        iBinder = mdVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeString(str);
                    this.le.transact(9, obtain, (Parcel) null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void a(SessionReadRequest sessionReadRequest, mb mbVar, String str) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                    if (sessionReadRequest != null) {
                        obtain.writeInt(1);
                        sessionReadRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (mbVar != null) {
                        iBinder = mbVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeString(str);
                    this.le.transact(10, obtain, (Parcel) null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void a(StartBleScanRequest startBleScanRequest, md mdVar, String str) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                    if (startBleScanRequest != null) {
                        obtain.writeInt(1);
                        startBleScanRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (mdVar != null) {
                        iBinder = mdVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeString(str);
                    this.le.transact(15, obtain, (Parcel) null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void a(aa aaVar, md mdVar, String str) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                    if (aaVar != null) {
                        obtain.writeInt(1);
                        aaVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (mdVar != null) {
                        iBinder = mdVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeString(str);
                    this.le.transact(21, obtain, (Parcel) null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void a(ad adVar, md mdVar, String str) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                    if (adVar != null) {
                        obtain.writeInt(1);
                        adVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (mdVar != null) {
                        iBinder = mdVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeString(str);
                    this.le.transact(16, obtain, (Parcel) null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void a(af afVar, md mdVar, String str) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                    if (afVar != null) {
                        obtain.writeInt(1);
                        afVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (mdVar != null) {
                        iBinder = mdVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeString(str);
                    this.le.transact(4, obtain, (Parcel) null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void a(ah ahVar, md mdVar, String str) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                    if (ahVar != null) {
                        obtain.writeInt(1);
                        ahVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (mdVar != null) {
                        iBinder = mdVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeString(str);
                    this.le.transact(18, obtain, (Parcel) null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void a(aj ajVar, md mdVar, String str) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                    if (ajVar != null) {
                        obtain.writeInt(1);
                        ajVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (mdVar != null) {
                        iBinder = mdVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeString(str);
                    this.le.transact(5, obtain, (Parcel) null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void a(b bVar, md mdVar, String str) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                    if (bVar != null) {
                        obtain.writeInt(1);
                        bVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (mdVar != null) {
                        iBinder = mdVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeString(str);
                    this.le.transact(17, obtain, (Parcel) null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void a(e eVar, md mdVar, String str) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                    if (eVar != null) {
                        obtain.writeInt(1);
                        eVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (mdVar != null) {
                        iBinder = mdVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeString(str);
                    this.le.transact(7, obtain, (Parcel) null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void a(j jVar, ly lyVar, String str) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                    if (jVar != null) {
                        obtain.writeInt(1);
                        jVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (lyVar != null) {
                        iBinder = lyVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeString(str);
                    this.le.transact(14, obtain, (Parcel) null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void a(m mVar, ma maVar, String str) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                    if (mVar != null) {
                        obtain.writeInt(1);
                        mVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (maVar != null) {
                        iBinder = maVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeString(str);
                    this.le.transact(6, obtain, (Parcel) null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void a(o oVar, md mdVar, String str) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                    if (oVar != null) {
                        obtain.writeInt(1);
                        oVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (mdVar != null) {
                        iBinder = mdVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeString(str);
                    this.le.transact(2, obtain, (Parcel) null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void a(q qVar, md mdVar, String str) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                    if (qVar != null) {
                        obtain.writeInt(1);
                        qVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (mdVar != null) {
                        iBinder = mdVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeString(str);
                    this.le.transact(3, obtain, (Parcel) null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void a(u uVar, md mdVar, String str) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                    if (uVar != null) {
                        obtain.writeInt(1);
                        uVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (mdVar != null) {
                        iBinder = mdVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeString(str);
                    this.le.transact(20, obtain, (Parcel) null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void a(w wVar, md mdVar, String str) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                    if (wVar != null) {
                        obtain.writeInt(1);
                        wVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (mdVar != null) {
                        iBinder = mdVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeString(str);
                    this.le.transact(11, obtain, (Parcel) null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void a(y yVar, mc mcVar, String str) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                    if (yVar != null) {
                        obtain.writeInt(1);
                        yVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (mcVar != null) {
                        iBinder = mcVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeString(str);
                    this.le.transact(12, obtain, (Parcel) null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void a(md mdVar, String str) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                    if (mdVar != null) {
                        iBinder = mdVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeString(str);
                    this.le.transact(22, obtain, (Parcel) null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void a(mp mpVar, String str) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                    if (mpVar != null) {
                        iBinder = mpVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeString(str);
                    this.le.transact(24, obtain, (Parcel) null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public IBinder asBinder() {
                return this.le;
            }

            public void b(md mdVar, String str) throws RemoteException {
                IBinder iBinder = null;
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.fitness.internal.IGoogleFitnessService");
                    if (mdVar != null) {
                        iBinder = mdVar.asBinder();
                    }
                    obtain.writeStrongBinder(iBinder);
                    obtain.writeString(str);
                    this.le.transact(23, obtain, (Parcel) null, 1);
                } finally {
                    obtain.recycle();
                }
            }
        }

        public static lz av(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.fitness.internal.IGoogleFitnessService");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof lz)) ? new C0067a(iBinder) : (lz) queryLocalInterface;
        }

        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v13, resolved type: com.google.android.gms.fitness.request.aa} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v18, resolved type: com.google.android.gms.fitness.request.u} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v23, resolved type: com.google.android.gms.fitness.request.ah} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v28, resolved type: com.google.android.gms.fitness.request.b} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v33, resolved type: com.google.android.gms.fitness.request.ad} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v38, resolved type: com.google.android.gms.fitness.request.StartBleScanRequest} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v43, resolved type: com.google.android.gms.fitness.request.y} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v48, resolved type: com.google.android.gms.fitness.request.w} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v53, resolved type: com.google.android.gms.fitness.request.SessionReadRequest} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v58, resolved type: com.google.android.gms.fitness.request.SessionInsertRequest} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v63, resolved type: com.google.android.gms.fitness.request.DataReadRequest} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v68, resolved type: com.google.android.gms.fitness.request.j} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v73, resolved type: com.google.android.gms.fitness.request.DataTypeCreateRequest} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v78, resolved type: com.google.android.gms.fitness.request.DataDeleteRequest} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v83, resolved type: com.google.android.gms.fitness.request.e} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v88, resolved type: com.google.android.gms.fitness.request.m} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v93, resolved type: com.google.android.gms.fitness.request.aj} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v98, resolved type: com.google.android.gms.fitness.request.af} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v103, resolved type: com.google.android.gms.fitness.request.q} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v108, resolved type: com.google.android.gms.fitness.request.o} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v113, resolved type: com.google.android.gms.fitness.request.DataSourcesRequest} */
        /* JADX WARNING: type inference failed for: r0v0 */
        /* JADX WARNING: type inference failed for: r0v121 */
        /* JADX WARNING: type inference failed for: r0v122 */
        /* JADX WARNING: type inference failed for: r0v123 */
        /* JADX WARNING: type inference failed for: r0v124 */
        /* JADX WARNING: type inference failed for: r0v125 */
        /* JADX WARNING: type inference failed for: r0v126 */
        /* JADX WARNING: type inference failed for: r0v127 */
        /* JADX WARNING: type inference failed for: r0v128 */
        /* JADX WARNING: type inference failed for: r0v129 */
        /* JADX WARNING: type inference failed for: r0v130 */
        /* JADX WARNING: type inference failed for: r0v131 */
        /* JADX WARNING: type inference failed for: r0v132 */
        /* JADX WARNING: type inference failed for: r0v133 */
        /* JADX WARNING: type inference failed for: r0v134 */
        /* JADX WARNING: type inference failed for: r0v135 */
        /* JADX WARNING: type inference failed for: r0v136 */
        /* JADX WARNING: type inference failed for: r0v137 */
        /* JADX WARNING: type inference failed for: r0v138 */
        /* JADX WARNING: type inference failed for: r0v139 */
        /* JADX WARNING: type inference failed for: r0v140 */
        /* JADX WARNING: type inference failed for: r0v141 */
        /* JADX WARNING: Multi-variable type inference failed */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean onTransact(int r5, android.os.Parcel r6, android.os.Parcel r7, int r8) throws android.os.RemoteException {
            /*
                r4 = this;
                r0 = 0
                r1 = 1
                switch(r5) {
                    case 1: goto L_0x0011;
                    case 2: goto L_0x0035;
                    case 3: goto L_0x0059;
                    case 4: goto L_0x007d;
                    case 5: goto L_0x00a2;
                    case 6: goto L_0x00c7;
                    case 7: goto L_0x00ec;
                    case 8: goto L_0x0183;
                    case 9: goto L_0x01a8;
                    case 10: goto L_0x01cd;
                    case 11: goto L_0x01f2;
                    case 12: goto L_0x0217;
                    case 13: goto L_0x0139;
                    case 14: goto L_0x015e;
                    case 15: goto L_0x023c;
                    case 16: goto L_0x0261;
                    case 17: goto L_0x0286;
                    case 18: goto L_0x02ab;
                    case 19: goto L_0x0111;
                    case 20: goto L_0x02d0;
                    case 21: goto L_0x02f5;
                    case 22: goto L_0x031a;
                    case 23: goto L_0x0331;
                    case 24: goto L_0x0348;
                    case 1598968902: goto L_0x000a;
                    default: goto L_0x0005;
                }
            L_0x0005:
                boolean r0 = super.onTransact(r5, r6, r7, r8)
            L_0x0009:
                return r0
            L_0x000a:
                java.lang.String r0 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r7.writeString(r0)
                r0 = r1
                goto L_0x0009
            L_0x0011:
                java.lang.String r2 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r6.enforceInterface(r2)
                int r2 = r6.readInt()
                if (r2 == 0) goto L_0x0024
                android.os.Parcelable$Creator<com.google.android.gms.fitness.request.DataSourcesRequest> r0 = com.google.android.gms.fitness.request.DataSourcesRequest.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r6)
                com.google.android.gms.fitness.request.DataSourcesRequest r0 = (com.google.android.gms.fitness.request.DataSourcesRequest) r0
            L_0x0024:
                android.os.IBinder r2 = r6.readStrongBinder()
                com.google.android.gms.internal.lx r2 = com.google.android.gms.internal.lx.a.at(r2)
                java.lang.String r3 = r6.readString()
                r4.a((com.google.android.gms.fitness.request.DataSourcesRequest) r0, (com.google.android.gms.internal.lx) r2, (java.lang.String) r3)
                r0 = r1
                goto L_0x0009
            L_0x0035:
                java.lang.String r2 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r6.enforceInterface(r2)
                int r2 = r6.readInt()
                if (r2 == 0) goto L_0x0048
                android.os.Parcelable$Creator<com.google.android.gms.fitness.request.o> r0 = com.google.android.gms.fitness.request.o.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r6)
                com.google.android.gms.fitness.request.o r0 = (com.google.android.gms.fitness.request.o) r0
            L_0x0048:
                android.os.IBinder r2 = r6.readStrongBinder()
                com.google.android.gms.internal.md r2 = com.google.android.gms.internal.md.a.az(r2)
                java.lang.String r3 = r6.readString()
                r4.a((com.google.android.gms.fitness.request.o) r0, (com.google.android.gms.internal.md) r2, (java.lang.String) r3)
                r0 = r1
                goto L_0x0009
            L_0x0059:
                java.lang.String r2 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r6.enforceInterface(r2)
                int r2 = r6.readInt()
                if (r2 == 0) goto L_0x006c
                android.os.Parcelable$Creator<com.google.android.gms.fitness.request.q> r0 = com.google.android.gms.fitness.request.q.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r6)
                com.google.android.gms.fitness.request.q r0 = (com.google.android.gms.fitness.request.q) r0
            L_0x006c:
                android.os.IBinder r2 = r6.readStrongBinder()
                com.google.android.gms.internal.md r2 = com.google.android.gms.internal.md.a.az(r2)
                java.lang.String r3 = r6.readString()
                r4.a((com.google.android.gms.fitness.request.q) r0, (com.google.android.gms.internal.md) r2, (java.lang.String) r3)
                r0 = r1
                goto L_0x0009
            L_0x007d:
                java.lang.String r2 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r6.enforceInterface(r2)
                int r2 = r6.readInt()
                if (r2 == 0) goto L_0x0090
                android.os.Parcelable$Creator<com.google.android.gms.fitness.request.af> r0 = com.google.android.gms.fitness.request.af.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r6)
                com.google.android.gms.fitness.request.af r0 = (com.google.android.gms.fitness.request.af) r0
            L_0x0090:
                android.os.IBinder r2 = r6.readStrongBinder()
                com.google.android.gms.internal.md r2 = com.google.android.gms.internal.md.a.az(r2)
                java.lang.String r3 = r6.readString()
                r4.a((com.google.android.gms.fitness.request.af) r0, (com.google.android.gms.internal.md) r2, (java.lang.String) r3)
                r0 = r1
                goto L_0x0009
            L_0x00a2:
                java.lang.String r2 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r6.enforceInterface(r2)
                int r2 = r6.readInt()
                if (r2 == 0) goto L_0x00b5
                android.os.Parcelable$Creator<com.google.android.gms.fitness.request.aj> r0 = com.google.android.gms.fitness.request.aj.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r6)
                com.google.android.gms.fitness.request.aj r0 = (com.google.android.gms.fitness.request.aj) r0
            L_0x00b5:
                android.os.IBinder r2 = r6.readStrongBinder()
                com.google.android.gms.internal.md r2 = com.google.android.gms.internal.md.a.az(r2)
                java.lang.String r3 = r6.readString()
                r4.a((com.google.android.gms.fitness.request.aj) r0, (com.google.android.gms.internal.md) r2, (java.lang.String) r3)
                r0 = r1
                goto L_0x0009
            L_0x00c7:
                java.lang.String r2 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r6.enforceInterface(r2)
                int r2 = r6.readInt()
                if (r2 == 0) goto L_0x00da
                android.os.Parcelable$Creator<com.google.android.gms.fitness.request.m> r0 = com.google.android.gms.fitness.request.m.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r6)
                com.google.android.gms.fitness.request.m r0 = (com.google.android.gms.fitness.request.m) r0
            L_0x00da:
                android.os.IBinder r2 = r6.readStrongBinder()
                com.google.android.gms.internal.ma r2 = com.google.android.gms.internal.ma.a.aw(r2)
                java.lang.String r3 = r6.readString()
                r4.a((com.google.android.gms.fitness.request.m) r0, (com.google.android.gms.internal.ma) r2, (java.lang.String) r3)
                r0 = r1
                goto L_0x0009
            L_0x00ec:
                java.lang.String r2 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r6.enforceInterface(r2)
                int r2 = r6.readInt()
                if (r2 == 0) goto L_0x00ff
                android.os.Parcelable$Creator<com.google.android.gms.fitness.request.e> r0 = com.google.android.gms.fitness.request.e.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r6)
                com.google.android.gms.fitness.request.e r0 = (com.google.android.gms.fitness.request.e) r0
            L_0x00ff:
                android.os.IBinder r2 = r6.readStrongBinder()
                com.google.android.gms.internal.md r2 = com.google.android.gms.internal.md.a.az(r2)
                java.lang.String r3 = r6.readString()
                r4.a((com.google.android.gms.fitness.request.e) r0, (com.google.android.gms.internal.md) r2, (java.lang.String) r3)
                r0 = r1
                goto L_0x0009
            L_0x0111:
                java.lang.String r2 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r6.enforceInterface(r2)
                int r2 = r6.readInt()
                if (r2 == 0) goto L_0x0124
                android.os.Parcelable$Creator<com.google.android.gms.fitness.request.DataDeleteRequest> r0 = com.google.android.gms.fitness.request.DataDeleteRequest.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r6)
                com.google.android.gms.fitness.request.DataDeleteRequest r0 = (com.google.android.gms.fitness.request.DataDeleteRequest) r0
            L_0x0124:
                android.os.IBinder r2 = r6.readStrongBinder()
                com.google.android.gms.internal.md r2 = com.google.android.gms.internal.md.a.az(r2)
                java.lang.String r3 = r6.readString()
                r4.a((com.google.android.gms.fitness.request.DataDeleteRequest) r0, (com.google.android.gms.internal.md) r2, (java.lang.String) r3)
                r7.writeNoException()
                r0 = r1
                goto L_0x0009
            L_0x0139:
                java.lang.String r2 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r6.enforceInterface(r2)
                int r2 = r6.readInt()
                if (r2 == 0) goto L_0x014c
                android.os.Parcelable$Creator<com.google.android.gms.fitness.request.DataTypeCreateRequest> r0 = com.google.android.gms.fitness.request.DataTypeCreateRequest.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r6)
                com.google.android.gms.fitness.request.DataTypeCreateRequest r0 = (com.google.android.gms.fitness.request.DataTypeCreateRequest) r0
            L_0x014c:
                android.os.IBinder r2 = r6.readStrongBinder()
                com.google.android.gms.internal.ly r2 = com.google.android.gms.internal.ly.a.au(r2)
                java.lang.String r3 = r6.readString()
                r4.a((com.google.android.gms.fitness.request.DataTypeCreateRequest) r0, (com.google.android.gms.internal.ly) r2, (java.lang.String) r3)
                r0 = r1
                goto L_0x0009
            L_0x015e:
                java.lang.String r2 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r6.enforceInterface(r2)
                int r2 = r6.readInt()
                if (r2 == 0) goto L_0x0171
                android.os.Parcelable$Creator<com.google.android.gms.fitness.request.j> r0 = com.google.android.gms.fitness.request.j.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r6)
                com.google.android.gms.fitness.request.j r0 = (com.google.android.gms.fitness.request.j) r0
            L_0x0171:
                android.os.IBinder r2 = r6.readStrongBinder()
                com.google.android.gms.internal.ly r2 = com.google.android.gms.internal.ly.a.au(r2)
                java.lang.String r3 = r6.readString()
                r4.a((com.google.android.gms.fitness.request.j) r0, (com.google.android.gms.internal.ly) r2, (java.lang.String) r3)
                r0 = r1
                goto L_0x0009
            L_0x0183:
                java.lang.String r2 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r6.enforceInterface(r2)
                int r2 = r6.readInt()
                if (r2 == 0) goto L_0x0196
                android.os.Parcelable$Creator<com.google.android.gms.fitness.request.DataReadRequest> r0 = com.google.android.gms.fitness.request.DataReadRequest.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r6)
                com.google.android.gms.fitness.request.DataReadRequest r0 = (com.google.android.gms.fitness.request.DataReadRequest) r0
            L_0x0196:
                android.os.IBinder r2 = r6.readStrongBinder()
                com.google.android.gms.internal.lw r2 = com.google.android.gms.internal.lw.a.as(r2)
                java.lang.String r3 = r6.readString()
                r4.a((com.google.android.gms.fitness.request.DataReadRequest) r0, (com.google.android.gms.internal.lw) r2, (java.lang.String) r3)
                r0 = r1
                goto L_0x0009
            L_0x01a8:
                java.lang.String r2 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r6.enforceInterface(r2)
                int r2 = r6.readInt()
                if (r2 == 0) goto L_0x01bb
                android.os.Parcelable$Creator<com.google.android.gms.fitness.request.SessionInsertRequest> r0 = com.google.android.gms.fitness.request.SessionInsertRequest.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r6)
                com.google.android.gms.fitness.request.SessionInsertRequest r0 = (com.google.android.gms.fitness.request.SessionInsertRequest) r0
            L_0x01bb:
                android.os.IBinder r2 = r6.readStrongBinder()
                com.google.android.gms.internal.md r2 = com.google.android.gms.internal.md.a.az(r2)
                java.lang.String r3 = r6.readString()
                r4.a((com.google.android.gms.fitness.request.SessionInsertRequest) r0, (com.google.android.gms.internal.md) r2, (java.lang.String) r3)
                r0 = r1
                goto L_0x0009
            L_0x01cd:
                java.lang.String r2 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r6.enforceInterface(r2)
                int r2 = r6.readInt()
                if (r2 == 0) goto L_0x01e0
                android.os.Parcelable$Creator<com.google.android.gms.fitness.request.SessionReadRequest> r0 = com.google.android.gms.fitness.request.SessionReadRequest.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r6)
                com.google.android.gms.fitness.request.SessionReadRequest r0 = (com.google.android.gms.fitness.request.SessionReadRequest) r0
            L_0x01e0:
                android.os.IBinder r2 = r6.readStrongBinder()
                com.google.android.gms.internal.mb r2 = com.google.android.gms.internal.mb.a.ax(r2)
                java.lang.String r3 = r6.readString()
                r4.a((com.google.android.gms.fitness.request.SessionReadRequest) r0, (com.google.android.gms.internal.mb) r2, (java.lang.String) r3)
                r0 = r1
                goto L_0x0009
            L_0x01f2:
                java.lang.String r2 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r6.enforceInterface(r2)
                int r2 = r6.readInt()
                if (r2 == 0) goto L_0x0205
                android.os.Parcelable$Creator<com.google.android.gms.fitness.request.w> r0 = com.google.android.gms.fitness.request.w.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r6)
                com.google.android.gms.fitness.request.w r0 = (com.google.android.gms.fitness.request.w) r0
            L_0x0205:
                android.os.IBinder r2 = r6.readStrongBinder()
                com.google.android.gms.internal.md r2 = com.google.android.gms.internal.md.a.az(r2)
                java.lang.String r3 = r6.readString()
                r4.a((com.google.android.gms.fitness.request.w) r0, (com.google.android.gms.internal.md) r2, (java.lang.String) r3)
                r0 = r1
                goto L_0x0009
            L_0x0217:
                java.lang.String r2 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r6.enforceInterface(r2)
                int r2 = r6.readInt()
                if (r2 == 0) goto L_0x022a
                android.os.Parcelable$Creator<com.google.android.gms.fitness.request.y> r0 = com.google.android.gms.fitness.request.y.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r6)
                com.google.android.gms.fitness.request.y r0 = (com.google.android.gms.fitness.request.y) r0
            L_0x022a:
                android.os.IBinder r2 = r6.readStrongBinder()
                com.google.android.gms.internal.mc r2 = com.google.android.gms.internal.mc.a.ay(r2)
                java.lang.String r3 = r6.readString()
                r4.a((com.google.android.gms.fitness.request.y) r0, (com.google.android.gms.internal.mc) r2, (java.lang.String) r3)
                r0 = r1
                goto L_0x0009
            L_0x023c:
                java.lang.String r2 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r6.enforceInterface(r2)
                int r2 = r6.readInt()
                if (r2 == 0) goto L_0x024f
                android.os.Parcelable$Creator<com.google.android.gms.fitness.request.StartBleScanRequest> r0 = com.google.android.gms.fitness.request.StartBleScanRequest.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r6)
                com.google.android.gms.fitness.request.StartBleScanRequest r0 = (com.google.android.gms.fitness.request.StartBleScanRequest) r0
            L_0x024f:
                android.os.IBinder r2 = r6.readStrongBinder()
                com.google.android.gms.internal.md r2 = com.google.android.gms.internal.md.a.az(r2)
                java.lang.String r3 = r6.readString()
                r4.a((com.google.android.gms.fitness.request.StartBleScanRequest) r0, (com.google.android.gms.internal.md) r2, (java.lang.String) r3)
                r0 = r1
                goto L_0x0009
            L_0x0261:
                java.lang.String r2 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r6.enforceInterface(r2)
                int r2 = r6.readInt()
                if (r2 == 0) goto L_0x0274
                android.os.Parcelable$Creator<com.google.android.gms.fitness.request.ad> r0 = com.google.android.gms.fitness.request.ad.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r6)
                com.google.android.gms.fitness.request.ad r0 = (com.google.android.gms.fitness.request.ad) r0
            L_0x0274:
                android.os.IBinder r2 = r6.readStrongBinder()
                com.google.android.gms.internal.md r2 = com.google.android.gms.internal.md.a.az(r2)
                java.lang.String r3 = r6.readString()
                r4.a((com.google.android.gms.fitness.request.ad) r0, (com.google.android.gms.internal.md) r2, (java.lang.String) r3)
                r0 = r1
                goto L_0x0009
            L_0x0286:
                java.lang.String r2 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r6.enforceInterface(r2)
                int r2 = r6.readInt()
                if (r2 == 0) goto L_0x0299
                android.os.Parcelable$Creator<com.google.android.gms.fitness.request.b> r0 = com.google.android.gms.fitness.request.b.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r6)
                com.google.android.gms.fitness.request.b r0 = (com.google.android.gms.fitness.request.b) r0
            L_0x0299:
                android.os.IBinder r2 = r6.readStrongBinder()
                com.google.android.gms.internal.md r2 = com.google.android.gms.internal.md.a.az(r2)
                java.lang.String r3 = r6.readString()
                r4.a((com.google.android.gms.fitness.request.b) r0, (com.google.android.gms.internal.md) r2, (java.lang.String) r3)
                r0 = r1
                goto L_0x0009
            L_0x02ab:
                java.lang.String r2 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r6.enforceInterface(r2)
                int r2 = r6.readInt()
                if (r2 == 0) goto L_0x02be
                android.os.Parcelable$Creator<com.google.android.gms.fitness.request.ah> r0 = com.google.android.gms.fitness.request.ah.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r6)
                com.google.android.gms.fitness.request.ah r0 = (com.google.android.gms.fitness.request.ah) r0
            L_0x02be:
                android.os.IBinder r2 = r6.readStrongBinder()
                com.google.android.gms.internal.md r2 = com.google.android.gms.internal.md.a.az(r2)
                java.lang.String r3 = r6.readString()
                r4.a((com.google.android.gms.fitness.request.ah) r0, (com.google.android.gms.internal.md) r2, (java.lang.String) r3)
                r0 = r1
                goto L_0x0009
            L_0x02d0:
                java.lang.String r2 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r6.enforceInterface(r2)
                int r2 = r6.readInt()
                if (r2 == 0) goto L_0x02e3
                android.os.Parcelable$Creator<com.google.android.gms.fitness.request.u> r0 = com.google.android.gms.fitness.request.u.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r6)
                com.google.android.gms.fitness.request.u r0 = (com.google.android.gms.fitness.request.u) r0
            L_0x02e3:
                android.os.IBinder r2 = r6.readStrongBinder()
                com.google.android.gms.internal.md r2 = com.google.android.gms.internal.md.a.az(r2)
                java.lang.String r3 = r6.readString()
                r4.a((com.google.android.gms.fitness.request.u) r0, (com.google.android.gms.internal.md) r2, (java.lang.String) r3)
                r0 = r1
                goto L_0x0009
            L_0x02f5:
                java.lang.String r2 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r6.enforceInterface(r2)
                int r2 = r6.readInt()
                if (r2 == 0) goto L_0x0308
                android.os.Parcelable$Creator<com.google.android.gms.fitness.request.aa> r0 = com.google.android.gms.fitness.request.aa.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r6)
                com.google.android.gms.fitness.request.aa r0 = (com.google.android.gms.fitness.request.aa) r0
            L_0x0308:
                android.os.IBinder r2 = r6.readStrongBinder()
                com.google.android.gms.internal.md r2 = com.google.android.gms.internal.md.a.az(r2)
                java.lang.String r3 = r6.readString()
                r4.a((com.google.android.gms.fitness.request.aa) r0, (com.google.android.gms.internal.md) r2, (java.lang.String) r3)
                r0 = r1
                goto L_0x0009
            L_0x031a:
                java.lang.String r0 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r6.enforceInterface(r0)
                android.os.IBinder r0 = r6.readStrongBinder()
                com.google.android.gms.internal.md r0 = com.google.android.gms.internal.md.a.az(r0)
                java.lang.String r2 = r6.readString()
                r4.a((com.google.android.gms.internal.md) r0, (java.lang.String) r2)
                r0 = r1
                goto L_0x0009
            L_0x0331:
                java.lang.String r0 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r6.enforceInterface(r0)
                android.os.IBinder r0 = r6.readStrongBinder()
                com.google.android.gms.internal.md r0 = com.google.android.gms.internal.md.a.az(r0)
                java.lang.String r2 = r6.readString()
                r4.b(r0, r2)
                r0 = r1
                goto L_0x0009
            L_0x0348:
                java.lang.String r0 = "com.google.android.gms.fitness.internal.IGoogleFitnessService"
                r6.enforceInterface(r0)
                android.os.IBinder r0 = r6.readStrongBinder()
                com.google.android.gms.internal.mp r0 = com.google.android.gms.internal.mp.a.aA(r0)
                java.lang.String r2 = r6.readString()
                r4.a((com.google.android.gms.internal.mp) r0, (java.lang.String) r2)
                r0 = r1
                goto L_0x0009
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.lz.a.onTransact(int, android.os.Parcel, android.os.Parcel, int):boolean");
        }
    }

    void a(DataDeleteRequest dataDeleteRequest, md mdVar, String str) throws RemoteException;

    void a(DataReadRequest dataReadRequest, lw lwVar, String str) throws RemoteException;

    void a(DataSourcesRequest dataSourcesRequest, lx lxVar, String str) throws RemoteException;

    void a(DataTypeCreateRequest dataTypeCreateRequest, ly lyVar, String str) throws RemoteException;

    void a(SessionInsertRequest sessionInsertRequest, md mdVar, String str) throws RemoteException;

    void a(SessionReadRequest sessionReadRequest, mb mbVar, String str) throws RemoteException;

    void a(StartBleScanRequest startBleScanRequest, md mdVar, String str) throws RemoteException;

    void a(aa aaVar, md mdVar, String str) throws RemoteException;

    void a(ad adVar, md mdVar, String str) throws RemoteException;

    void a(af afVar, md mdVar, String str) throws RemoteException;

    void a(ah ahVar, md mdVar, String str) throws RemoteException;

    void a(aj ajVar, md mdVar, String str) throws RemoteException;

    void a(b bVar, md mdVar, String str) throws RemoteException;

    void a(e eVar, md mdVar, String str) throws RemoteException;

    void a(j jVar, ly lyVar, String str) throws RemoteException;

    void a(m mVar, ma maVar, String str) throws RemoteException;

    void a(o oVar, md mdVar, String str) throws RemoteException;

    void a(q qVar, md mdVar, String str) throws RemoteException;

    void a(u uVar, md mdVar, String str) throws RemoteException;

    void a(w wVar, md mdVar, String str) throws RemoteException;

    void a(y yVar, mc mcVar, String str) throws RemoteException;

    void a(md mdVar, String str) throws RemoteException;

    void a(mp mpVar, String str) throws RemoteException;

    void b(md mdVar, String str) throws RemoteException;
}
