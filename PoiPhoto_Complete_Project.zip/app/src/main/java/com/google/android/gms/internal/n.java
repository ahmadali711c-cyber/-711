package com.google.android.gms.internal;

import java.io.IOException;

interface n {
    byte[] D() throws IOException;

    void b(int i, long j) throws IOException;

    void b(int i, String str) throws IOException;

    void reset();
}
