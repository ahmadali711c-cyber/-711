package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.internal.pi;
import java.util.HashSet;
import java.util.Set;

public class pl implements Parcelable.Creator<pi.b> {
    static void a(pi.b bVar, Parcel parcel, int i) {
        int H = b.H(parcel);
        Set<Integer> set = bVar.aon;
        if (set.contains(1)) {
            b.c(parcel, 1, bVar.CK);
        }
        if (set.contains(2)) {
            b.a(parcel, 2, (Parcelable) bVar.apG, i, true);
        }
        if (set.contains(3)) {
            b.a(parcel, 3, (Parcelable) bVar.apH, i, true);
        }
        if (set.contains(4)) {
            b.c(parcel, 4, bVar.apI);
        }
        b.H(parcel, H);
    }

    /* renamed from: dB */
    public pi.b createFromParcel(Parcel parcel) {
        pi.b.C0082b bVar = null;
        int i = 0;
        int G = a.G(parcel);
        HashSet hashSet = new HashSet();
        pi.b.a aVar = null;
        int i2 = 0;
        while (parcel.dataPosition() < G) {
            int F = a.F(parcel);
            switch (a.aH(F)) {
                case 1:
                    i2 = a.g(parcel, F);
                    hashSet.add(1);
                    break;
                case 2:
                    hashSet.add(2);
                    aVar = (pi.b.a) a.a(parcel, F, pi.b.a.CREATOR);
                    break;
                case 3:
                    hashSet.add(3);
                    bVar = (pi.b.C0082b) a.a(parcel, F, pi.b.C0082b.CREATOR);
                    break;
                case 4:
                    i = a.g(parcel, F);
                    hashSet.add(4);
                    break;
                default:
                    a.b(parcel, F);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new pi.b(hashSet, i2, aVar, bVar, i);
        }
        throw new a.C0004a("Overread allowed size end=" + G, parcel);
    }

    /* renamed from: fz */
    public pi.b[] newArray(int i) {
        return new pi.b[i];
    }
}
