package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.internal.pi;
import java.util.HashSet;
import java.util.Set;

public class po implements Parcelable.Creator<pi.c> {
    static void a(pi.c cVar, Parcel parcel, int i) {
        int H = b.H(parcel);
        Set<Integer> set = cVar.aon;
        if (set.contains(1)) {
            b.c(parcel, 1, cVar.CK);
        }
        if (set.contains(2)) {
            b.a(parcel, 2, cVar.vf, true);
        }
        b.H(parcel, H);
    }

    /* renamed from: dE */
    public pi.c createFromParcel(Parcel parcel) {
        int G = a.G(parcel);
        HashSet hashSet = new HashSet();
        int i = 0;
        String str = null;
        while (parcel.dataPosition() < G) {
            int F = a.F(parcel);
            switch (a.aH(F)) {
                case 1:
                    i = a.g(parcel, F);
                    hashSet.add(1);
                    break;
                case 2:
                    str = a.o(parcel, F);
                    hashSet.add(2);
                    break;
                default:
                    a.b(parcel, F);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new pi.c(hashSet, i, str);
        }
        throw new a.C0004a("Overread allowed size end=" + G, parcel);
    }

    /* renamed from: fC */
    public pi.c[] newArray(int i) {
        return new pi.c[i];
    }
}
