package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.internal.pi;
import java.util.HashSet;
import java.util.Set;

public class pp implements Parcelable.Creator<pi.d> {
    static void a(pi.d dVar, Parcel parcel, int i) {
        int H = b.H(parcel);
        Set<Integer> set = dVar.aon;
        if (set.contains(1)) {
            b.c(parcel, 1, dVar.CK);
        }
        if (set.contains(2)) {
            b.a(parcel, 2, dVar.aoL, true);
        }
        if (set.contains(3)) {
            b.a(parcel, 3, dVar.apL, true);
        }
        if (set.contains(4)) {
            b.a(parcel, 4, dVar.aoO, true);
        }
        if (set.contains(5)) {
            b.a(parcel, 5, dVar.apM, true);
        }
        if (set.contains(6)) {
            b.a(parcel, 6, dVar.apN, true);
        }
        if (set.contains(7)) {
            b.a(parcel, 7, dVar.apO, true);
        }
        b.H(parcel, H);
    }

    /* renamed from: dF */
    public pi.d createFromParcel(Parcel parcel) {
        String str = null;
        int G = a.G(parcel);
        HashSet hashSet = new HashSet();
        int i = 0;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        String str5 = null;
        String str6 = null;
        while (parcel.dataPosition() < G) {
            int F = a.F(parcel);
            switch (a.aH(F)) {
                case 1:
                    i = a.g(parcel, F);
                    hashSet.add(1);
                    break;
                case 2:
                    str6 = a.o(parcel, F);
                    hashSet.add(2);
                    break;
                case 3:
                    str5 = a.o(parcel, F);
                    hashSet.add(3);
                    break;
                case 4:
                    str4 = a.o(parcel, F);
                    hashSet.add(4);
                    break;
                case 5:
                    str3 = a.o(parcel, F);
                    hashSet.add(5);
                    break;
                case 6:
                    str2 = a.o(parcel, F);
                    hashSet.add(6);
                    break;
                case 7:
                    str = a.o(parcel, F);
                    hashSet.add(7);
                    break;
                default:
                    a.b(parcel, F);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new pi.d(hashSet, i, str6, str5, str4, str3, str2, str);
        }
        throw new a.C0004a("Overread allowed size end=" + G, parcel);
    }

    /* renamed from: fD */
    public pi.d[] newArray(int i) {
        return new pi.d[i];
    }
}
