package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.internal.pi;
import java.util.HashSet;
import java.util.Set;

public class ps implements Parcelable.Creator<pi.h> {
    static void a(pi.h hVar, Parcel parcel, int i) {
        int H = b.H(parcel);
        Set<Integer> set = hVar.aon;
        if (set.contains(1)) {
            b.c(parcel, 1, hVar.CK);
        }
        if (set.contains(3)) {
            b.c(parcel, 3, hVar.oU());
        }
        if (set.contains(4)) {
            b.a(parcel, 4, hVar.mValue, true);
        }
        if (set.contains(5)) {
            b.a(parcel, 5, hVar.XL, true);
        }
        if (set.contains(6)) {
            b.c(parcel, 6, hVar.Gt);
        }
        b.H(parcel, H);
    }

    /* renamed from: dI */
    public pi.h createFromParcel(Parcel parcel) {
        String str = null;
        int i = 0;
        int G = a.G(parcel);
        HashSet hashSet = new HashSet();
        int i2 = 0;
        String str2 = null;
        int i3 = 0;
        while (parcel.dataPosition() < G) {
            int F = a.F(parcel);
            switch (a.aH(F)) {
                case 1:
                    i3 = a.g(parcel, F);
                    hashSet.add(1);
                    break;
                case 3:
                    i = a.g(parcel, F);
                    hashSet.add(3);
                    break;
                case 4:
                    str = a.o(parcel, F);
                    hashSet.add(4);
                    break;
                case 5:
                    str2 = a.o(parcel, F);
                    hashSet.add(5);
                    break;
                case 6:
                    i2 = a.g(parcel, F);
                    hashSet.add(6);
                    break;
                default:
                    a.b(parcel, F);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new pi.h(hashSet, i3, str2, i2, str, i);
        }
        throw new a.C0004a("Overread allowed size end=" + G, parcel);
    }

    /* renamed from: fG */
    public pi.h[] newArray(int i) {
        return new pi.h[i];
    }
}
