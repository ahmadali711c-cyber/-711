package com.google.android.gms.internal;

import android.app.Activity;
import android.os.IBinder;
import android.os.RemoteException;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.dynamic.c;
import com.google.android.gms.dynamic.e;
import com.google.android.gms.dynamic.g;
import com.google.android.gms.internal.qd;
import com.google.android.gms.wallet.fragment.WalletFragmentOptions;

public class qi extends g<qd> {
    private static qi awH;

    protected qi() {
        super("com.google.android.gms.wallet.dynamite.WalletDynamiteCreatorImpl");
    }

    public static qa a(Activity activity, c cVar, WalletFragmentOptions walletFragmentOptions, qb qbVar) throws GooglePlayServicesNotAvailableException {
        int isGooglePlayServicesAvailable = GooglePlayServicesUtil.isGooglePlayServicesAvailable(activity);
        if (isGooglePlayServicesAvailable != 0) {
            throw new GooglePlayServicesNotAvailableException(isGooglePlayServicesAvailable);
        }
        try {
            return ((qd) rg().L(activity)).a(e.k(activity), cVar, walletFragmentOptions, qbVar);
        } catch (RemoteException e) {
            throw new RuntimeException(e);
        } catch (g.a e2) {
            throw new RuntimeException(e2);
        }
    }

    private static qi rg() {
        if (awH == null) {
            awH = new qi();
        }
        return awH;
    }

    /* access modifiers changed from: protected */
    /* renamed from: bW */
    public qd d(IBinder iBinder) {
        return qd.a.bS(iBinder);
    }
}
