package com.google.android.gms.internal;

import com.google.android.gms.wallet.wobs.r;

public class qk implements r {
}
