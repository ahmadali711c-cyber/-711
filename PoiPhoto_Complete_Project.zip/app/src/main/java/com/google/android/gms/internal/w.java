package com.google.android.gms.internal;

import android.view.View;

public interface w {
    void av();

    void aw();

    void b(View view);
}
