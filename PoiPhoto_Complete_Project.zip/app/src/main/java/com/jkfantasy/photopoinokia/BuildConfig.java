package com.jkfantasy.photopoinokia;

public final class BuildConfig {
    public static final boolean DEBUG = false;
}
