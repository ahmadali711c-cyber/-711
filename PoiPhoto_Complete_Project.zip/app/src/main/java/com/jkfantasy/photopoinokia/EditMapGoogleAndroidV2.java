package com.jkfantasy.photopoinokia;

import android.annotation.SuppressLint;
import android.os.Build;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Toast;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class EditMapGoogleAndroidV2 {
    EditPoiPage mActivity = null;
    GoogleMap mMap = null;
    LatLng m_curLatLng = null;
    Marker m_curMarker = null;
    boolean m_isMapNeedMove = true;
    boolean m_isMarkerVisible = false;

    /* access modifiers changed from: package-private */
    public void setMainActivity(EditPoiPage mainActivity) {
        this.mActivity = mainActivity;
    }

    class CustomInfoWindowAdapter implements GoogleMap.InfoWindowAdapter {
        private final View mContents;
        private final int mOPTION_MODE_CUSTOM_CONTENTS = 2;
        private final int mOPTION_MODE_CUSTOM_WINDOW = 1;
        private final int mOPTION_MODE_DEFAULT = 0;
        private int mOption_mode = 0;
        private final View mWindow;

        CustomInfoWindowAdapter() {
            this.mWindow = EditMapGoogleAndroidV2.this.mActivity.getLayoutInflater().inflate(R.layout.custom_info_window, (ViewGroup) null);
            this.mContents = EditMapGoogleAndroidV2.this.mActivity.getLayoutInflater().inflate(R.layout.custom_info_contents, (ViewGroup) null);
        }

        public View getInfoWindow(Marker marker) {
            if (this.mOption_mode != 1) {
                return null;
            }
            render(marker, this.mWindow);
            return this.mWindow;
        }

        public View getInfoContents(Marker marker) {
            if (this.mOption_mode != 2) {
                return null;
            }
            render(marker, this.mContents);
            return this.mContents;
        }

        private void render(Marker marker, View view) {
        }
    }

    public void setUpMapIfNeeded() {
        if (this.mMap == null) {
            this.mMap = ((SupportMapFragment) this.mActivity.getSupportFragmentManager().findFragmentById(R.id.googleMapAndroidV2)).getMap();
            if (this.mMap != null) {
                setUpMap();
                this.mActivity.content1_sp_map_type.setVisibility(0);
                this.mActivity.btn_content1_normal_full_screen.setVisibility(0);
                return;
            }
            this.mActivity.content1_sp_map_type.setVisibility(4);
            this.mActivity.btn_content1_normal_full_screen.setVisibility(4);
        }
    }

    private void setUpMap() {
        switch (this.mActivity.m_mapTypeSelect) {
            case 0:
                if (this.mMap != null) {
                    this.mMap.setMapType(1);
                    break;
                }
                break;
            case 1:
                if (this.mMap != null) {
                    this.mMap.setMapType(2);
                    break;
                }
                break;
            case 2:
                if (this.mMap != null) {
                    this.mMap.setMapType(3);
                    break;
                }
                break;
            case 3:
                if (this.mMap != null) {
                    this.mMap.setMapType(4);
                    break;
                }
                break;
            default:
                if (this.mMap != null) {
                    this.mMap.setMapType(1);
                    break;
                }
                break;
        }
        this.mMap.getUiSettings().setZoomControlsEnabled(true);
        this.mMap.setOnCameraChangeListener(new GoogleMap.OnCameraChangeListener() {
            public void onCameraChange(CameraPosition position) {
                EditMapGoogleAndroidV2.this.mActivity.m_mapZoomLevel = position.zoom;
                MyLatLng myLatLng = new MyLatLng(position.target.latitude, position.target.longitude);
                synchronized (EditMapGoogleAndroidV2.this.mActivity.gMapcenterList) {
                    if (myLatLng != null) {
                        EditMapGoogleAndroidV2.this.mActivity.gMapcenterList.add(myLatLng);
                    }
                }
            }
        });
        this.mMap.setOnMapLongClickListener(new GoogleMap.OnMapLongClickListener() {
            public void onMapLongClick(LatLng point) {
            }
        });
        this.mMap.clear();
        addMarkersToMap();
        this.mMap.setInfoWindowAdapter(new CustomInfoWindowAdapter());
        final View mapView = this.mActivity.getSupportFragmentManager().findFragmentById(R.id.googleMapAndroidV2).getView();
        if (mapView.getViewTreeObserver().isAlive()) {
            mapView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                @SuppressLint({"NewApi"})
                public void onGlobalLayout() {
                    LatLngBounds build = new LatLngBounds.Builder().include(EditMapGoogleAndroidV2.this.m_curLatLng).build();
                    if (Build.VERSION.SDK_INT < 16) {
                        mapView.getViewTreeObserver().removeGlobalOnLayoutListener(this);
                    } else {
                        mapView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    }
                }
            });
        }
    }

    private void addMarkersToMap() {
        if (this.m_isMarkerVisible) {
            this.m_curMarker = this.mMap.addMarker(new MarkerOptions().position(this.m_curLatLng).title(this.mActivity.getString(R.string.PhotoPosition)).anchor(0.5f, 0.5f).icon(BitmapDescriptorFactory.fromResource(R.drawable.edit_poi_before)));
        }
    }

    private boolean checkReady() {
        if (this.mMap != null) {
            return true;
        }
        Toast.makeText(this.mActivity, R.string.map_not_ready, 0).show();
        return false;
    }

    public void onResetMap() {
        if (checkReady()) {
            this.mMap.clear();
            addMarkersToMap();
            if (this.m_isMapNeedMove) {
                this.mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(this.m_curLatLng, this.mActivity.m_mapZoomLevel));
            }
        }
    }

    public void setMapTypeEx(int posOfSelect) {
        switch (posOfSelect) {
            case 0:
                if (this.mMap != null) {
                    this.mMap.setMapType(1);
                    return;
                }
                return;
            case 1:
                if (this.mMap != null) {
                    this.mMap.setMapType(2);
                    return;
                }
                return;
            case 2:
                if (this.mMap != null) {
                    this.mMap.setMapType(3);
                    return;
                }
                return;
            case 3:
                if (this.mMap != null) {
                    this.mMap.setMapType(4);
                    return;
                }
                return;
            default:
                if (this.mMap != null) {
                    this.mMap.setMapType(1);
                    return;
                }
                return;
        }
    }

    public boolean isMapReadyForUse() {
        this.mMap = ((SupportMapFragment) this.mActivity.getSupportFragmentManager().findFragmentById(R.id.googleMapAndroidV2)).getMap();
        if (this.mMap != null) {
            return true;
        }
        return false;
    }

    public void setLatitudeLongitude(double latitude, double longitude) {
        this.m_curLatLng = new LatLng(latitude, longitude);
    }

    public void setMapVisible(boolean bVisible) {
        if (bVisible) {
            Fragment fragment_map = this.mActivity.getSupportFragmentManager().findFragmentById(R.id.googleMapAndroidV2);
            if (fragment_map.isHidden()) {
                FragmentTransaction tr = this.mActivity.getSupportFragmentManager().beginTransaction();
                tr.show(fragment_map);
                tr.commit();
                return;
            }
            return;
        }
        Fragment fragment_map2 = this.mActivity.getSupportFragmentManager().findFragmentById(R.id.googleMapAndroidV2);
        if (!fragment_map2.isHidden()) {
            FragmentTransaction tr2 = this.mActivity.getSupportFragmentManager().beginTransaction();
            tr2.hide(fragment_map2);
            tr2.commit();
        }
    }

    public void setMarkerVisible(boolean bVisible) {
        this.m_isMarkerVisible = bVisible;
    }

    public void setMapNeedMove(boolean bMove) {
        this.m_isMapNeedMove = bMove;
    }
}
