package com.jkfantasy.photopoinokia;

import android.content.Context;
import android.os.Message;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.widget.EditText;

public class EditTextWithBackKey extends EditText {
    EditPoiPage mActivity = null;

    /* access modifiers changed from: package-private */
    public void setMainActivity(EditPoiPage mainActivity) {
        this.mActivity = mainActivity;
    }

    public EditTextWithBackKey(Context context) {
        super(context);
    }

    public EditTextWithBackKey(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public EditTextWithBackKey(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    public boolean onKeyPreIme(int keyCode, KeyEvent event) {
        if (keyCode != 4 || event.getAction() != 1) {
            return super.dispatchKeyEvent(event);
        }
        Message m = this.mActivity.customHandler.obtainMessage();
        m.what = 512;
        this.mActivity.customHandler.sendMessageDelayed(m, 1);
        return false;
    }
}
