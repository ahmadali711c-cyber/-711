package com.jkfantasy.photopoinokia;

import android.media.ExifInterface;

public class GeoDegree {
    Float Altitude = Float.valueOf(0.0f);
    Float Latitude = Float.valueOf(0.0f);
    Float Longitude = Float.valueOf(0.0f);
    Boolean isAltitudeNull = true;
    String strAltitude = null;
    private boolean valid = false;

    GeoDegree(ExifInterface exif) {
        String attrLATITUDE = exif.getAttribute("GPSLatitude");
        String attrLATITUDE_REF = exif.getAttribute("GPSLatitudeRef");
        String attrLONGITUDE = exif.getAttribute("GPSLongitude");
        String attrLONGITUDE_REF = exif.getAttribute("GPSLongitudeRef");
        String attrALTITUDE = exif.getAttribute("GPSAltitude");
        String attrALTITUDE_REF = exif.getAttribute("GPSAltitudeRef");
        if (!(attrLATITUDE == null || attrLATITUDE_REF == null || attrLONGITUDE == null || attrLONGITUDE_REF == null)) {
            this.valid = true;
            if (attrLATITUDE_REF.equals("N")) {
                this.Latitude = convertToDegree(attrLATITUDE);
            } else {
                this.Latitude = Float.valueOf(0.0f - convertToDegree(attrLATITUDE).floatValue());
            }
            if (attrLONGITUDE_REF.equals("E")) {
                this.Longitude = convertToDegree(attrLONGITUDE);
            } else {
                this.Longitude = Float.valueOf(0.0f - convertToDegree(attrLONGITUDE).floatValue());
            }
        }
        if (attrALTITUDE == null || attrALTITUDE_REF == null) {
            this.strAltitude = attrALTITUDE;
            return;
        }
        if (Integer.valueOf(attrALTITUDE_REF).intValue() == 0) {
            this.Altitude = convertToMeter(attrALTITUDE);
        } else {
            this.Altitude = Float.valueOf(0.0f - convertToMeter(attrALTITUDE).floatValue());
        }
        this.isAltitudeNull = false;
    }

    private Float convertToDegree(String stringDMS) {
        String[] DMS = stringDMS.split(",", 3);
        String[] stringD = DMS[0].split("/", 2);
        Double FloatD = Double.valueOf(new Double(stringD[0]).doubleValue() / new Double(stringD[1]).doubleValue());
        String[] stringM = DMS[1].split("/", 2);
        Double FloatM = Double.valueOf(new Double(stringM[0]).doubleValue() / new Double(stringM[1]).doubleValue());
        String[] stringS = DMS[2].split("/", 2);
        return new Float(FloatD.doubleValue() + (FloatM.doubleValue() / 60.0d) + (Double.valueOf(new Double(stringS[0]).doubleValue() / new Double(stringS[1]).doubleValue()).doubleValue() / 3600.0d));
    }

    private Float convertToMeter(String stringMeterPercent) {
        String[] stringMeter = stringMeterPercent.split("/", 2);
        return Float.valueOf(new Float(stringMeter[0]).floatValue() / new Float(stringMeter[1]).floatValue());
    }

    public boolean isValid() {
        return this.valid;
    }

    public String toString() {
        return String.valueOf(String.valueOf(this.Latitude)) + ", " + String.valueOf(this.Longitude);
    }

    public int getLatitudeE6() {
        return (int) (this.Latitude.floatValue() * 1000000.0f);
    }

    public int getLongitudeE6() {
        return (int) (this.Longitude.floatValue() * 1000000.0f);
    }
}
