package com.jkfantasy.photopoinokia;

public class GlobalConstVariable {
    static final String sharePreferenceName = "JK.FinalFantasy_PoiPhoto_V1.0.0.ini";
}
