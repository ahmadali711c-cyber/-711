package com.jkfantasy.photopoinokia;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.media.ExifInterface;
import android.media.MediaScannerConnection;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.MotionEventCompat;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.accessibility.AccessibilityEventCompat;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.animation.TranslateAnimation;
import android.webkit.MimeTypeMap;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
// Removed Ad Imports
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.drive.DriveFile;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.lang.Thread;
import java.lang.ref.SoftReference;
import java.lang.ref.WeakReference;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;
import java.util.WeakHashMap;

public class MainActivity extends FragmentActivity {
    private static final int INTENT_REQUEST_CODE_GOOGLE_MAP = 2;
    private static final int INTENT_REQUEST_CODE_PHOTO_FILTER = 1;
    private static final int INTENT_REQUEST_CODE_TAKE_PICTURE = 3;
    private static final int MESSAGE_WHAT_AfterFewTimeAndReRequestAD = 1540;
    private static final int MESSAGE_WHAT_CheckIfNoAdEventResponse = 1538;
    private static final int MESSAGE_WHAT_Decode_BigBitmap = 256;
    private static final int MESSAGE_WHAT_FastReRequestAD = 1539;
    private static final int MESSAGE_WHAT_Load_Another_AD = 1537;
    private static final int MESSAGE_WHAT_Load_First_AD = 1536;
    static final int MESSAGE_WHAT_content1_baidu_bugFix_addMarkersToMap = 560;
    static final int MESSAGE_WHAT_content1_display_place_popup_window = 513;
    static final int MESSAGE_WHAT_content1_normal_full_screen_swicth = 512;
    static final int MESSAGE_WHAT_content1_onResetMap = 514;
    final String PACKAGE_NAME_FOR_GOOGLE_EARTH = "com.google.earth";
    final String PACKAGE_NAME_FOR_GOOGLE_MAP = "com.google.android.apps.maps";
    final String PACKAGE_NAME_FOR_OTHER = "othermap.jkfantasy.com";
    Dialog aboutDialog = null;
    ImageAdapter adapter;
    int adhubAdState = 0;
    int admobAdState = 0;
    AdView admobAdView = null;
    int amazonAdState = 0;
    PosATask bigBmp_forPosAtask = null;
    Button btn_content0_normal_full_screen;
    Button btn_content1_normal_full_screen;
    Button btn_tab0;
    Button btn_tab1;
    Button btn_tab2;
    Button btn_toolbar_camera_take_picture;
    Button btn_toolbar_delete_file;
    Button btn_toolbar_file_menu;
    Button btn_toolbar_google_map;
    Button btn_toolbar_option_menu;
    Button btn_toolbar_photo_filter_left;
    LinearLayout btn_toolbar_photo_filter_middle;
    Button btn_toolbar_photo_filter_right;
    Button btn_toolbar_share_file;
    Button btn_toolbar_switch_MainUpDown;
    TextView btn_toolbar_tv_file_num;
    FrameLayout content0_container;
    ImagePagerAdapter content0_pageAdapter = null;
    ImageViewPager content0_viewPager;
    FrameLayout content1_container;
    int content1_height;
    LinearLayout content1_ll_edit_poi;
    int content1_marginTop;
    Spinner content1_sp_map_type;
    TextView content1_tv_no_gps_info;
    int content1_width;
    TextView content2_info_Altitude;
    TextView content2_info_Aperture;
    TextView content2_info_ExposureTime;
    TextView content2_info_FileModifiedTime;
    TextView content2_info_FileName;
    TextView content2_info_FileSize;
    TextView content2_info_Flash;
    TextView content2_info_FocalLength;
    TextView content2_info_FolderName;
    TextView content2_info_ISO;
    TextView content2_info_ImageCaptureTime;
    TextView content2_info_ImageHeight;
    TextView content2_info_ImageWidth;
    TextView content2_info_Latitude;
    TextView content2_info_Longitude;
    TextView content2_info_Make;
    TextView content2_info_Model;
    TextView content2_info_Orientation;
    TextView content2_info_WhiteBalance;
    LinearLayout content_x_dummyLine_top;
    Handler customHandler = null;
    Object decodeSyncObj = new Object();
    DisplayMetrics displayMetrics;
    long dtMiliCur_ADs = 0;
    long dtMiliPre_ADs = 0;
    int dummyLayout_height;
    final int gBuildVerSDK = Build.VERSION.SDK_INT;
    boolean gIsFinished = false;
    boolean gIsInstallGooglePlayMarket = false;
    boolean gIsInstallGooglePlayService = false;
    boolean gIsInstalledAmazonMap = false;
    boolean gIsInstalledBaiduMap = false;
    boolean gIsInstalledGoogleMap = false;
    boolean gIsInstalledNokiaMap = false;
    Boolean gIs_content0_full_screen = false;
    Boolean gIs_content1_full_screen = false;
    long gMaxMemory = 16777216;
    ProgressDialog gProgressDlg;
    GridView gridView;
    Boolean hasMeasuredLayout = false;
    int ic_height;
    int ic_width;
    List<String> imageList_forSel = new ArrayList();
    String intent_imageRealPath = null;
    Boolean isAsyncTaskDialogOn = false;
    Boolean isAsyncTaskDirtyWork = false;
    Boolean isFileSelectModeEnabled = false;
    Boolean isGridViewInitialized = false;
    Boolean isInPause = false;
    Boolean isLongItemSelected = false;
    Boolean isNeedProcessINTENT_action_view = false;
    Boolean isNeedProcessRET_take_picture = false;
    boolean isResuming = false;
    int iv_height;
    int iv_padding;
    int iv_width;
    Dialog launchMapsDialog = null;
    LaunchMapsListAdapter launchMapsListAdapter = null;
    ListView launchMapsListView = null;
    LinearLayout layout_ad;
    LinearLayout layout_content0;
    FrameLayout layout_content1;
    LinearLayout layout_content2;
    FrameLayout layout_dummy;
    FrameLayout layout_main;
    FrameLayout layout_root;
    List<PosATask> list_forPosAtask = new ArrayList();
    final boolean mDirectGoToAndroidPlayStore = true;
    PromoteExpandableListAdapter mExpListAdapter = null;
    HashMap<String, List<PromoteItem>> mExpListDataChild = null;
    List<String> mExpListDataHeader = null;
    ExpandableListView mExpListView = null;
    double mLatInSelPhoto = 0.0d;
    double mLonInSelPhoto = 0.0d;
    Dialog mPromoteDialog = null;
    boolean mShowSketchCamera = false;
    String m_bucketId = "";
    String m_bucketName = "";
    String m_curFileName = "";
    int m_curFilePosition = 0;
    ViewHolder m_curFileViewHolder = null;
    int m_folderMode = 0;
    int m_gpsMode = 0;
    Boolean m_isGoogleMapEnable = false;
    int m_mapLayerIndex = 0;
    int m_mapPlaceCmpIndex = 0;
    String m_mapPlaceCmpString = "";
    String m_mapPlaceSearchValue = "";
    int m_mapTypeSelect = 0;
    boolean m_mapWeatherDegreeIsC = false;
    float m_mapZoomLevel = 15.0f;
    int m_mimeMode = 0;
    int m_pageNumber = 0;
    int m_sortBy = 0;
    int m_sortMode = 0;
    int m_viewMode = 1;
    MainActivity mainActivity = null;
    TranslateAnimation mainAnim;
    int mainLayout_height;
    int mainLayout_width;
    ArrayList<HashMap<String, String>> mainList;
    int main_y_anim_shift;
    String manufactureStr = Build.MANUFACTURER;
    MapNokiaJavascript mapNokiaJavascript = new MapNokiaJavascript();
    List<MapPkgItem> mapPkgItemAry = new ArrayList();
    boolean mbIsGeo_GoogleEarthInclude = false;
    boolean mbIsGeo_GoogleMapInclude = false;
    boolean mbIsGeo_OtherAppsInclude = false;
    String modelStr = Build.MODEL;
    Dialog placeDialog = null;
    PlaceListAdapter placeListAdapter = null;
    ListView placeListView = null;
    AlertDialog renameDialog;
    String renameExtOnly;
    String renameNameOnly;
    String renamePathOnly;
    SharedPreferences settings;
    String settings_bucketId = "";
    String settings_bucketName = "";
    String settings_curFileName = "";
    int settings_curFilePosition = 0;
    int settings_folderMode = 0;
    int settings_gpsMode = 0;
    int settings_mapLayerIndex = 0;
    int settings_mapPlaceCmpIndex = 0;
    String settings_mapPlaceCmpString = "";
    String settings_mapPlaceSearchValue = "";
    int settings_mapTypeSelect = 0;
    boolean settings_mapWeatherDegreeIsC = false;
    float settings_mapZoomLevel = 15.0f;
    int settings_mimeMode = 0;
    int settings_pageNumber = 0;
    int settings_sortBy = 0;
    int settings_sortMode = 0;
    int settings_viewMode = 1;
    Dialog sortDialog;
    LinearLayout submenu_toolbar_func0;
    LinearLayout submenu_toolbar_func1;
    TextView tv_toolbar_photo_filter_folder_name;
    TextView tv_toolbar_photo_filter_gps;
    TextView tv_toolbar_photo_filter_jpeg;
    final int which_map = WHICH_MAP.NOKIA_MAP_JS;
    final int which_publish_market = WHICH_PUBLISH_MARKET.GOOGLE;

    /* access modifiers changed from: package-private */
    public void createCustomHandler() {
        this.customHandler = new Handler() {
            public void handleMessage(Message msg) {
                int position;
                boolean bResumeState = true;
                if (msg.what == 256 && (position = msg.arg1) == MainActivity.this.m_curFilePosition) {
                    if (!(MainActivity.this.bigBmp_forPosAtask == null || MainActivity.this.bigBmp_forPosAtask.aTask == null)) {
                        MainActivity.this.bigBmp_forPosAtask.aTask.cancel(true);
                        MainActivity.this.bigBmp_forPosAtask = null;
                    }
                    if (position >= 0) {
                        TouchImageView tiv = (TouchImageView) MainActivity.this.content0_viewPager.findViewWithTag(String.valueOf(position));
                        if (tiv != null) {
                            tiv.setBigBitmapNeedLoaded(true);
                            MainActivity.this.content_0_process_decode_bigBitmap_async(position, tiv);
                        } else if (msg.arg2 == 1) {
                            Message m = MainActivity.this.customHandler.obtainMessage();
                            m.what = 256;
                            m.arg1 = position;
                            m.arg2 = 2;
                            MainActivity.this.customHandler.sendMessageDelayed(m, 300);
                        }
                    }
                }
                if (msg.what == 512) {
                    MainActivity.this.content1_normal_full_screen_swicth();
                }
                if (msg.what == MainActivity.MESSAGE_WHAT_content1_display_place_popup_window) {
                    MainActivity.this.content1_display_place_popup_window();
                }
                if (msg.what == MainActivity.MESSAGE_WHAT_content1_onResetMap) {
                    MainActivity.this.content1_onResetMap();
                }
                if (!(msg.what != MainActivity.MESSAGE_WHAT_content1_baidu_bugFix_addMarkersToMap || MainActivity.this.which_map == WHICH_MAP.GOOGLE_MAP_ANDROID_V2 || MainActivity.this.which_map == WHICH_MAP.GOOGLE_MAP_JS_V3 || MainActivity.this.which_map == WHICH_MAP.BAIDU_MAP_ANDROID || MainActivity.this.which_map == WHICH_MAP.AMAZON_MAP_ANDROID)) {
                    int i = WHICH_MAP.NOKIA_MAP_JS;
                }
                if (msg.what == MainActivity.MESSAGE_WHAT_Load_First_AD) {
                    MainActivity.this.load_First_ADs();
                } else if (msg.what == MainActivity.MESSAGE_WHAT_Load_Another_AD && MainActivity.this.admobAdState == 0) {
                    MainActivity.this.create_admobAD();
                }
                if (!(msg.what != MainActivity.MESSAGE_WHAT_CheckIfNoAdEventResponse || MainActivity.this.admobAdState == 2 || MainActivity.this.adhubAdState == 2 || MainActivity.this.amazonAdState == 2 || MainActivity.this.admobAdState != 0)) {
                    MainActivity.this.create_admobAD();
                }
                if (msg.what == MainActivity.MESSAGE_WHAT_FastReRequestAD && MainActivity.this.amazonAdState == 2) {
                    MainActivity.this.reRequest_ADs();
                    MainActivity.this.sendMessageToAfterFewTimeAndReRequestAD();
                }
                if (msg.what == MainActivity.MESSAGE_WHAT_AfterFewTimeAndReRequestAD && MainActivity.this.amazonAdState == 2) {
                    if (MainActivity.this.isInPause.booleanValue()) {
                        bResumeState = false;
                    }
                    if (bResumeState) {
                        MainActivity.this.reRequest_ADs();
                        MainActivity.this.sendMessageToAfterFewTimeAndReRequestAD();
                    }
                }
                super.handleMessage(msg);
            }
        };
    }

    /* access modifiers changed from: package-private */
    public void destroyCustomHandler() {
        if (this.customHandler != null) {
            this.customHandler.removeCallbacksAndMessages((Object) null);
            this.customHandler = null;
        }
    }

    public String getRealPathFromURI(Uri contentUri) {
        Cursor cursor = getContentResolver().query(contentUri, new String[]{"_data"}, (String) null, (String[]) null, (String) null);
        int column_index = cursor.getColumnIndexOrThrow("_data");
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }

    public static String removeUriFromPath(String uri) {
        return uri.substring(7, uri.length());
    }

    private String getLastImageFullPath() {
        Cursor imageCursor = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, new String[]{"_id", "_data"}, (String) null, (String[]) null, "date_added DESC");
        if (!imageCursor.moveToFirst()) {
            return null;
        }
        int i = imageCursor.getInt(imageCursor.getColumnIndex("_id"));
        String fullPath = imageCursor.getString(imageCursor.getColumnIndex("_data"));
        imageCursor.close();
        return fullPath;
    }

    private String getMediaBucketFromFilename() {
        Cursor imageCursor = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, new String[]{"_id", "_data", "bucket_id", "bucket_display_name"}, "_data='" + this.intent_imageRealPath + "'", (String[]) null, "date_added DESC");
        if (imageCursor == null || !imageCursor.moveToFirst()) {
            return null;
        }
        int i = imageCursor.getInt(imageCursor.getColumnIndex("_id"));
        String BucketId = imageCursor.getString(imageCursor.getColumnIndex("bucket_id"));
        String BucketName = imageCursor.getString(imageCursor.getColumnIndex("bucket_display_name"));
        String fullPath = imageCursor.getString(imageCursor.getColumnIndex("_data"));
        this.m_folderMode = 1;
        this.m_bucketId = BucketId;
        this.m_bucketName = BucketName;
        this.m_curFilePosition = 0;
        this.m_curFileName = fullPath;
        imageCursor.close();
        return fullPath;
    }

    public void onCreate(Bundle savedInstanceState) {
        Uri imageUri;
        super.onCreate(savedInstanceState);
        this.mainActivity = this;
        createCustomHandler();
        if (!(this.which_map == WHICH_MAP.GOOGLE_MAP_ANDROID_V2 || this.which_map == WHICH_MAP.GOOGLE_MAP_JS_V3 || this.which_map == WHICH_MAP.BAIDU_MAP_ANDROID || this.which_map == WHICH_MAP.AMAZON_MAP_ANDROID || this.which_map != WHICH_MAP.NOKIA_MAP_JS)) {
            this.mapNokiaJavascript.setMainActivity(this);
        }
        Intent intent = getIntent();
        String action = intent.getAction();
        String type = intent.getType();
        if ("android.intent.action.VIEW".equals(action) && type != null && type.startsWith("image/") && (imageUri = intent.getData()) != null) {
            this.intent_imageRealPath = removeUriFromPath(imageUri.toString());
            this.isNeedProcessINTENT_action_view = true;
        }
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.activity_main);
        initResources();
        this.displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(this.displayMetrics);
        this.iv_width = this.displayMetrics.widthPixels / 4;
        this.iv_height = this.iv_width;
        this.iv_padding = this.iv_width / 20;
        int i = this.iv_width / 5;
        this.ic_height = i;
        this.ic_width = i;
        findViews();
        if (this.isNeedProcessINTENT_action_view.booleanValue()) {
            this.btn_toolbar_photo_filter_left.setVisibility(4);
            this.btn_toolbar_photo_filter_middle.setVisibility(4);
            this.btn_toolbar_photo_filter_right.setVisibility(4);
            this.btn_toolbar_camera_take_picture.setVisibility(4);
        }
        if (this.which_map == WHICH_MAP.GOOGLE_MAP_ANDROID_V2) {
            this.gIsInstalledGoogleMap = isGoogleMapsInstalled();
        } else if (this.which_map == WHICH_MAP.GOOGLE_MAP_JS_V3) {
            this.gIsInstalledGoogleMap = isGoogleMapsInstalled();
        } else if (this.which_map == WHICH_MAP.BAIDU_MAP_ANDROID) {
            this.gIsInstalledBaiduMap = isBaiduMapsInstalled();
        } else if (this.which_map == WHICH_MAP.AMAZON_MAP_ANDROID) {
            this.gIsInstalledAmazonMap = false;
        } else if (this.which_map == WHICH_MAP.NOKIA_MAP_JS) {
            this.gIsInstalledNokiaMap = true;
        }
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
    }

    /* access modifiers changed from: protected */
    public void onRestart() {
        super.onRestart();
    }

    /* access modifiers changed from: package-private */
    public void general_refresh_view_func() {
        this.isFileSelectModeEnabled = false;
        this.isLongItemSelected = false;
        this.submenu_toolbar_func0.setVisibility(0);
        this.submenu_toolbar_func1.setVisibility(4);
        this.list_forPosAtask.clear();
        if (!this.isFileSelectModeEnabled.booleanValue()) {
            this.imageList_forSel.clear();
        }
        if (this.content0_pageAdapter != null) {
            this.content0_viewPager.setAdapter((PagerAdapter) null);
            this.content0_pageAdapter = null;
        }
        if (!(this.adapter == null || this.adapter.imageLoader == null)) {
            this.adapter.imageLoader.stopThread();
            try {
                this.adapter.imageLoader.photoLoaderThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        if (this.adapter != null) {
            this.gridView.setAdapter((ListAdapter) null);
        }
        if (!getMediaData().booleanValue()) {
            Toast.makeText(this, getString(R.string.StorageIsPrepare), 1).show();
            this.gIsFinished = true;
            finish();
            return;
        }
        getCurrentData();
        initialGridView();
        settingKernelToUI();
    }

    /* access modifiers changed from: package-private */
    public void pause_creation_resources() {
        this.list_forPosAtask.clear();
        if (!this.isFileSelectModeEnabled.booleanValue()) {
            this.imageList_forSel.clear();
        }
        if (this.content0_pageAdapter != null) {
            this.content0_viewPager.setAdapter((PagerAdapter) null);
            this.content0_pageAdapter = null;
        }
        if (!(this.adapter == null || this.adapter.imageLoader == null)) {
            this.adapter.imageLoader.stopThread();
            try {
                this.adapter.imageLoader.photoLoaderThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        if (this.adapter != null) {
            this.gridView.setAdapter((ListAdapter) null);
        }
        saveCurrentSettings();
    }

    /* access modifiers changed from: package-private */
    public void resume_creation_resources() {
        if (!hasStorage(true)) {
            Toast.makeText(this, getString(R.string.StorageIsNotReady), 1).show();
            this.gIsFinished = true;
            finish();
        } else if (isMediaScannerScanning()) {
            Toast.makeText(this, getString(R.string.MediaIsScanningPleaseWait), 1).show();
            this.gIsFinished = true;
            finish();
        } else {
            initializeSettings();
            if (this.isNeedProcessINTENT_action_view.booleanValue()) {
                getMediaBucketFromFilename();
            }
            if (!getMediaData().booleanValue()) {
                Toast.makeText(this, getString(R.string.StorageIsPrepare), 1).show();
                this.gIsFinished = true;
                finish();
                return;
            }
            if (this.isNeedProcessRET_take_picture.booleanValue()) {
                this.isNeedProcessRET_take_picture = false;
                String fullPath = getLastImageFullPath();
                Toast.makeText(this, String.valueOf(getString(R.string.CaptureFilePathPre)) + "\n" + fullPath, 1).show();
                int mainListSize = this.mainList.size();
                if (mainListSize > 0) {
                    for (int i = 0; i < mainListSize; i++) {
                        if (fullPath.compareTo((String) this.mainList.get(i).get("data")) == 0) {
                            this.m_curFilePosition = i;
                            this.m_curFileName = fullPath;
                        }
                    }
                }
            }
            getCurrentData();
            initialGridView();
            settingKernelToUI();
        }
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        this.isInPause = true;
        if (!this.isAsyncTaskDialogOn.booleanValue()) {
            pause_creation_resources();
        }
        super.onPause();
    }

    /* access modifiers changed from: protected */
    public void onResumeFragments() {
        super.onResumeFragments();
        this.isResuming = true;
        if (!this.isAsyncTaskDialogOn.booleanValue()) {
            if (this.isAsyncTaskDirtyWork.booleanValue()) {
                this.isAsyncTaskDirtyWork = false;
                settingKernelToUI();
            } else {
                resume_creation_resources();
            }
        }
        this.isInPause = false;
        sendMessageToFastReRequestAD();
        this.isResuming = false;
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
        destroy_ADs();
        this.isGridViewInitialized = false;
        if (this.aboutDialog != null) {
            this.aboutDialog.dismiss();
        }
        destroyCustomHandler();
        this.isNeedProcessINTENT_action_view = false;
    }

    public void onBackPressed() {
        boolean isPlaceSearchInputFocus = false;
        if (!(this.which_map == WHICH_MAP.GOOGLE_MAP_ANDROID_V2 || this.which_map == WHICH_MAP.GOOGLE_MAP_JS_V3 || this.which_map == WHICH_MAP.BAIDU_MAP_ANDROID || this.which_map == WHICH_MAP.AMAZON_MAP_ANDROID || this.which_map != WHICH_MAP.NOKIA_MAP_JS)) {
            isPlaceSearchInputFocus = this.mapNokiaJavascript.mIsPlaceSearchInputFocus;
        }
        if (isPlaceSearchInputFocus) {
            if (this.which_map != WHICH_MAP.GOOGLE_MAP_ANDROID_V2 && this.which_map != WHICH_MAP.GOOGLE_MAP_JS_V3 && this.which_map != WHICH_MAP.BAIDU_MAP_ANDROID && this.which_map != WHICH_MAP.AMAZON_MAP_ANDROID && this.which_map == WHICH_MAP.NOKIA_MAP_JS) {
                this.mapNokiaJavascript.setBackKeyPressed();
            }
        } else if (this.gIs_content0_full_screen.booleanValue()) {
            this.gIs_content0_full_screen = false;
            TouchImageView tiv = (TouchImageView) this.content0_viewPager.findViewWithTag(String.valueOf(this.m_curFilePosition));
            if (tiv != null) {
                tiv.setTo1X();
            }
            FrameLayout.LayoutParams params2 = (FrameLayout.LayoutParams) this.content0_container.getLayoutParams();
            params2.width = this.content1_width;
            params2.height = this.content1_height;
            params2.topMargin = this.content1_marginTop;
            this.content0_container.setLayoutParams(params2);
            if (this.gIs_content0_full_screen.booleanValue()) {
                this.btn_content0_normal_full_screen.setBackgroundDrawable(getResources().getDrawable(R.drawable.to_normal_screen_normal));
            } else {
                this.btn_content0_normal_full_screen.setBackgroundDrawable(getResources().getDrawable(R.drawable.to_full_screen_normal));
            }
        } else if (this.gIs_content1_full_screen.booleanValue()) {
            this.gIs_content1_full_screen = false;
            FrameLayout.LayoutParams params22 = (FrameLayout.LayoutParams) this.content1_container.getLayoutParams();
            params22.width = this.content1_width;
            params22.height = this.content1_height;
            params22.topMargin = this.content1_marginTop;
            this.content1_container.setLayoutParams(params22);
            this.btn_content1_normal_full_screen.setBackgroundDrawable(getResources().getDrawable(R.drawable.to_full_screen_normal));
            if (this.which_map != WHICH_MAP.GOOGLE_MAP_ANDROID_V2 && this.which_map != WHICH_MAP.GOOGLE_MAP_JS_V3 && this.which_map != WHICH_MAP.BAIDU_MAP_ANDROID && this.which_map != WHICH_MAP.AMAZON_MAP_ANDROID && this.which_map == WHICH_MAP.NOKIA_MAP_JS) {
                this.mapNokiaJavascript.setGotoFullScreenImage(true);
            }
        } else if (this.isFileSelectModeEnabled.booleanValue()) {
            this.isFileSelectModeEnabled = false;
            this.isLongItemSelected = false;
            this.adapter.notifyDataSetChanged();
            this.submenu_toolbar_func0.setVisibility(0);
            this.submenu_toolbar_func1.setVisibility(4);
        } else {
            super.onBackPressed();
        }
    }

    /* access modifiers changed from: package-private */
    public void __________global_class() {
    }

    class ViewHolder {
        ImageView cameraIcon;
        TextView filenameView;
        ImageView gpsIcon;
        ImageView imageView;
        ImageView selectIcon;

        ViewHolder() {
        }
    }

    /* access modifiers changed from: package-private */
    public void __________mark_notification() {
    }

    /* access modifiers changed from: package-private */
    public void __________mark_admob() {
    }

    /* access modifiers changed from: package-private */
    public void __________mark_help_function() {
    }

    public boolean isGoogleMapsInstalled() {
        try {
            getPackageManager().getApplicationInfo("com.google.android.apps.maps", 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    public boolean isGooglePlayServiceInstalled() {
        try {
            getPackageManager().getApplicationInfo(GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    public boolean isGooglePlayMarketInstalled() {
        return true;
    }

    public boolean isBaiduMapsInstalled() {
        try {
            getPackageManager().getApplicationInfo("com.baidu.BaiduMap", 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    /* access modifiers changed from: package-private */
    public void __________mark_variable_init() {
    }

    /* access modifiers changed from: package-private */
    public void __________mark_resource() {
    }

    /* access modifiers changed from: package-private */
    public void initResources() {
        this.gMaxMemory = Runtime.getRuntime().maxMemory();
        this.mainList = new ArrayList<>();
    }

    /* access modifiers changed from: package-private */
    public void __________mark_ADs() {
    }

    /* access modifiers changed from: package-private */
    public void sendMessageToRequestFirstAD() {
        Message m = this.customHandler.obtainMessage();
        m.what = MESSAGE_WHAT_Load_First_AD;
        this.customHandler.sendMessageDelayed(m, 500);
    }

    /* access modifiers changed from: package-private */
    public void sendMessageToRequestAnotherAD() {
    }

    /* access modifiers changed from: package-private */
    public void sendMessageToProtectIfNoAdEventResponse() {
    }

    /* access modifiers changed from: package-private */
    public void sendMessageToFastReRequestAD() {
    }

    /* access modifiers changed from: package-private */
    public void sendMessageToAfterFewTimeAndReRequestAD() {
    }

    /* access modifiers changed from: private */
    public void create_admobAD() {
        // Ads removed
    }

    @SuppressLint({"NewApi"})
    private void create_admobAD_old() {
    }

    @SuppressLint({"NewApi"})
    private void create_admobAD_new() {
        // Ads removed
    }

    @SuppressLint({"NewApi"})
    private void create_adhubAD() {
    }

    private void create_amazonAD() {
    }

    private void destroy_admobAD() {
        destroy_admobAD_new();
    }

    private void destroy_admobAD_old() {
    }

    private void destroy_admobAD_new() {
        this.admobAdState = 0;
    }

    private void destroy_adhubAD() {
    }

    private void destroy_amazonAD() {
    }

    private void create_ADs() {
        sendMessageToRequestFirstAD();
        sendMessageToProtectIfNoAdEventResponse();
    }

    private void destroy_ADs() {
        destroy_admobAD();
    }

    /* access modifiers changed from: private */
    public void load_First_ADs() {
        if (this.which_publish_market == WHICH_PUBLISH_MARKET.NORMAL || this.which_publish_market == WHICH_PUBLISH_MARKET.GOOGLE) {
            create_admobAD();
        } else if (this.which_publish_market == WHICH_PUBLISH_MARKET.SAMSUNG) {
            create_admobAD();
        } else if (this.which_publish_market == WHICH_PUBLISH_MARKET.AMAZON) {
            create_admobAD();
        }
    }

    /* access modifiers changed from: private */
    public void reRequest_ADs() {
    }

    /* access modifiers changed from: private */
    public void dateTimeMilliUpdate_ADs() {
        this.dtMiliPre_ADs = System.currentTimeMillis();
    }

    private boolean checkIfNeedLoadNewAd() {
        this.dtMiliCur_ADs = System.currentTimeMillis();
        if (Math.abs(this.dtMiliCur_ADs - this.dtMiliPre_ADs) / 1000 > 120) {
            return true;
        }
        return false;
    }

    /* access modifiers changed from: package-private */
    public void __________mark_warn_error_message() {
    }

    /* access modifiers changed from: package-private */
    public void alert(String message) {
        AlertDialog.Builder bld = new AlertDialog.Builder(this);
        bld.setMessage(message);
        bld.setNeutralButton("OK", (DialogInterface.OnClickListener) null);
        bld.create().show();
    }

    /* access modifiers changed from: package-private */
    public void __________mark_network() {
    }

    public Boolean checkNetworkAvailable() {
        NetworkInfo info = ((ConnectivityManager) getSystemService("connectivity")).getActiveNetworkInfo();
        if (info == null || !info.isConnected()) {
            return false;
        }
        if (!info.isAvailable()) {
            return false;
        }
        return true;
    }

    /* access modifiers changed from: package-private */
    public void __________mark_layout() {
    }

    private void findViews() {
        this.layout_ad = (LinearLayout) findViewById(R.id.layout_ad);
        destroy_ADs();
        create_ADs();
        this.layout_root = (FrameLayout) findViewById(R.id.layout_root);
        this.btn_tab0 = (Button) findViewById(R.id.btn_tab0);
        this.btn_tab1 = (Button) findViewById(R.id.btn_tab1);
        this.btn_tab2 = (Button) findViewById(R.id.btn_tab2);
        this.layout_main = (FrameLayout) findViewById(R.id.layout_main);
        this.layout_dummy = (FrameLayout) findViewById(R.id.layout_dummy);
        this.layout_content0 = (LinearLayout) findViewById(R.id.layout_content0);
        this.layout_content1 = (FrameLayout) findViewById(R.id.layout_content1);
        this.layout_content2 = (LinearLayout) findViewById(R.id.layout_content2);
        this.submenu_toolbar_func0 = (LinearLayout) findViewById(R.id.submenu_toolbar_func0);
        this.submenu_toolbar_func1 = (LinearLayout) findViewById(R.id.submenu_toolbar_func1);
        this.content_x_dummyLine_top = (LinearLayout) findViewById(R.id.content_x_dummyLine_top);
        this.content0_container = (FrameLayout) findViewById(R.id.content0_container);
        this.content0_viewPager = (ImageViewPager) findViewById(R.id.content0_viewPager);
        this.btn_content0_normal_full_screen = (Button) findViewById(R.id.btn_content0_normal_full_screen);
        this.btn_content0_normal_full_screen.getBackground().setAlpha(170);
        this.content1_container = (FrameLayout) findViewById(R.id.content1_container);
        this.content1_tv_no_gps_info = (TextView) findViewById(R.id.content1_tv_no_gps_info);
        this.content1_ll_edit_poi = (LinearLayout) findViewById(R.id.content1_ll_edit_poi);
        this.btn_content1_normal_full_screen = (Button) findViewById(R.id.btn_content1_normal_full_screen);
        this.btn_content1_normal_full_screen.getBackground().setAlpha(170);
        this.content1_sp_map_type = (Spinner) findViewById(R.id.content1_sp_map_type);
        this.content1_sp_map_type.getBackground().setAlpha(170);
        this.content1_sp_map_type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> adapterView, View view, int pos, long id) {
                MainActivity.this.m_mapTypeSelect = pos;
                if (MainActivity.this.which_map != WHICH_MAP.GOOGLE_MAP_ANDROID_V2 && MainActivity.this.which_map != WHICH_MAP.GOOGLE_MAP_JS_V3 && MainActivity.this.which_map != WHICH_MAP.BAIDU_MAP_ANDROID && MainActivity.this.which_map != WHICH_MAP.AMAZON_MAP_ANDROID && MainActivity.this.which_map == WHICH_MAP.NOKIA_MAP_JS) {
                    MainActivity.this.mapNokiaJavascript.setMapTypeEx(pos);
                }
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        this.content2_info_FolderName = (TextView) findViewById(R.id.content2_info_FolderName);
        this.content2_info_FileName = (TextView) findViewById(R.id.content2_info_FileName);
        this.content2_info_FileSize = (TextView) findViewById(R.id.content2_info_FileSize);
        this.content2_info_ImageWidth = (TextView) findViewById(R.id.content2_info_ImageWidth);
        this.content2_info_ImageHeight = (TextView) findViewById(R.id.content2_info_ImageHeight);
        this.content2_info_FileModifiedTime = (TextView) findViewById(R.id.content2_info_FileModifiedTime);
        this.content2_info_ImageCaptureTime = (TextView) findViewById(R.id.content2_info_ImageCaptureTime);
        this.content2_info_Latitude = (TextView) findViewById(R.id.content2_info_Latitude);
        this.content2_info_Longitude = (TextView) findViewById(R.id.content2_info_Longitude);
        this.content2_info_Altitude = (TextView) findViewById(R.id.content2_info_Altitude);
        this.content2_info_Make = (TextView) findViewById(R.id.content2_info_Make);
        this.content2_info_Model = (TextView) findViewById(R.id.content2_info_Model);
        this.content2_info_Flash = (TextView) findViewById(R.id.content2_info_Flash);
        this.content2_info_FocalLength = (TextView) findViewById(R.id.content2_info_FocalLength);
        this.content2_info_Aperture = (TextView) findViewById(R.id.content2_info_Aperture);
        this.content2_info_ExposureTime = (TextView) findViewById(R.id.content2_info_ExposureTime);
        this.content2_info_WhiteBalance = (TextView) findViewById(R.id.content2_info_WhiteBalance);
        this.content2_info_ISO = (TextView) findViewById(R.id.content2_info_ISO);
        this.content2_info_Orientation = (TextView) findViewById(R.id.content2_info_Orientation);
        this.btn_toolbar_switch_MainUpDown = (Button) findViewById(R.id.btn_toolbar_switch_MainUpDown);
        this.btn_toolbar_photo_filter_left = (Button) findViewById(R.id.btn_toolbar_photo_filter_left);
        this.btn_toolbar_photo_filter_middle = (LinearLayout) findViewById(R.id.btn_toolbar_photo_filter_middle);
        this.btn_toolbar_photo_filter_right = (Button) findViewById(R.id.btn_toolbar_photo_filter_right);
        this.tv_toolbar_photo_filter_jpeg = (TextView) findViewById(R.id.tv_toolbar_photo_filter_jpeg);
        this.tv_toolbar_photo_filter_gps = (TextView) findViewById(R.id.tv_toolbar_photo_filter_gps);
        this.tv_toolbar_photo_filter_folder_name = (TextView) findViewById(R.id.tv_toolbar_photo_filter_folder_name);
        this.btn_toolbar_google_map = (Button) findViewById(R.id.btn_toolbar_google_map);
        this.btn_toolbar_camera_take_picture = (Button) findViewById(R.id.btn_toolbar_camera_take_picture);
        this.btn_toolbar_tv_file_num = (TextView) findViewById(R.id.btn_toolbar_tv_file_num);
        this.btn_toolbar_share_file = (Button) findViewById(R.id.btn_toolbar_share_file);
        this.btn_toolbar_delete_file = (Button) findViewById(R.id.btn_toolbar_delete_file);
        this.btn_toolbar_option_menu = (Button) findViewById(R.id.btn_toolbar_option_menu);
        this.btn_toolbar_file_menu = (Button) findViewById(R.id.btn_toolbar_file_menu);
        this.gridView = (GridView) findViewById(R.id.gridView);
        this.layout_main.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            public boolean onPreDraw() {
                if (!MainActivity.this.hasMeasuredLayout.booleanValue()) {
                    if (MainActivity.this.m_viewMode == 1) {
                        MainActivity.this.btn_toolbar_switch_MainUpDown.setBackgroundDrawable(MainActivity.this.getResources().getDrawable(R.drawable.switch_button_dn_normal));
                    } else {
                        MainActivity.this.btn_toolbar_switch_MainUpDown.setBackgroundDrawable(MainActivity.this.getResources().getDrawable(R.drawable.switch_button_up_normal));
                    }
                    MainActivity.this.content1_width = MainActivity.this.layout_content1.getWidth();
                    MainActivity.this.content1_height = MainActivity.this.layout_content1.getHeight();
                    MainActivity.this.content1_marginTop = MainActivity.this.layout_ad.getHeight() + MainActivity.this.btn_tab0.getHeight() + MainActivity.this.content_x_dummyLine_top.getHeight();
                    MainActivity.this.mainLayout_width = MainActivity.this.layout_main.getWidth();
                    MainActivity.this.mainLayout_height = MainActivity.this.displayMetrics.heightPixels - MainActivity.this.layout_ad.getHeight();
                    MainActivity.this.dummyLayout_height = MainActivity.this.layout_dummy.getHeight();
                    MainActivity.this.main_y_anim_shift = MainActivity.this.mainLayout_height - MainActivity.this.dummyLayout_height;
                    FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) MainActivity.this.layout_main.getLayoutParams();
                    params.width = MainActivity.this.mainLayout_width;
                    if (MainActivity.this.m_viewMode == 1) {
                        params.height = MainActivity.this.mainLayout_height;
                        params.topMargin = 0;
                        params.bottomMargin = 0;
                        params.gravity = 80;
                    } else {
                        params.height = MainActivity.this.dummyLayout_height;
                        params.topMargin = MainActivity.this.main_y_anim_shift;
                        params.bottomMargin = 0;
                        params.gravity = 80;
                    }
                    MainActivity.this.layout_main.setLayoutParams(params);
                    FrameLayout.LayoutParams params2 = (FrameLayout.LayoutParams) MainActivity.this.content0_container.getLayoutParams();
                    params2.width = MainActivity.this.content1_width;
                    params2.height = MainActivity.this.content1_height;
                    params2.topMargin = MainActivity.this.content1_marginTop;
                    params2.bottomMargin = 0;
                    params2.gravity = 48;
                    MainActivity.this.content0_container.setLayoutParams(params2);
                    FrameLayout.LayoutParams params22 = (FrameLayout.LayoutParams) MainActivity.this.content1_container.getLayoutParams();
                    params22.width = MainActivity.this.content1_width;
                    params22.height = MainActivity.this.content1_height;
                    params22.topMargin = MainActivity.this.content1_marginTop;
                    params22.bottomMargin = 0;
                    params22.gravity = 48;
                    MainActivity.this.content1_container.setLayoutParams(params22);
                    MainActivity.this.hasMeasuredLayout = true;
                }
                return true;
            }
        });
        this.btn_tab0.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return MainActivity.this.tabBtnOnTouch(0, v, event);
            }
        });
        this.btn_tab1.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return MainActivity.this.tabBtnOnTouch(1, v, event);
            }
        });
        this.btn_tab2.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return MainActivity.this.tabBtnOnTouch(2, v, event);
            }
        });
        this.btn_toolbar_switch_MainUpDown.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (MainActivity.this.m_curFilePosition != -1) {
                    MainActivity.this.gridView.setSelection(MainActivity.this.m_curFilePosition);
                }
                return MainActivity.this.layoutMain_switch_UpDownBtnOnTouch(view, motionEvent);
            }
        });
        this.btn_toolbar_photo_filter_left.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return MainActivity.this.layoutMain_photo_filter(v, event);
            }
        });
        this.btn_toolbar_photo_filter_middle.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return MainActivity.this.layoutMain_photo_filter(v, event);
            }
        });
        this.btn_toolbar_photo_filter_right.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return MainActivity.this.layoutMain_photo_filter(v, event);
            }
        });
        this.btn_toolbar_google_map.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return MainActivity.this.layoutMain_google_map(v, event);
            }
        });
        this.btn_toolbar_camera_take_picture.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return MainActivity.this.layoutMain_camera_take_picture(v, event);
            }
        });
        this.submenu_toolbar_func0.setVisibility(0);
        this.submenu_toolbar_func1.setVisibility(4);
        this.btn_toolbar_tv_file_num.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return MainActivity.this.layoutMain_file_num(v, event);
            }
        });
        this.btn_toolbar_share_file.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return MainActivity.this.layoutMain_share_file(v, event);
            }
        });
        this.btn_toolbar_delete_file.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return MainActivity.this.layoutMain_delete_file(v, event);
            }
        });
        this.btn_toolbar_option_menu.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return MainActivity.this.layoutMain_option_menu(v, event);
            }
        });
        this.btn_toolbar_file_menu.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return MainActivity.this.layoutMain_file_menu(v, event);
            }
        });
        this.btn_content0_normal_full_screen.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return MainActivity.this.content0_normal_full_screen_switch(v, event);
            }
        });
        this.btn_content1_normal_full_screen.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return MainActivity.this.content1_normal_full_screen_switch(v, event);
            }
        });
        this.content1_ll_edit_poi.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return MainActivity.this.content1_edit_poi(v, event);
            }
        });
    }

    /* access modifiers changed from: package-private */
    public void update_sub_menu_func1_button_ui() {
        int selectedFileCount = 0;
        Boolean bHaveNotJpegFile = false;
        for (int i = 0; i < this.mainList.size(); i++) {
            String selModeStr = this.imageList_forSel.get(i);
            if (selModeStr != "0") {
                selectedFileCount++;
                if (selModeStr == "-2") {
                    bHaveNotJpegFile = true;
                }
            }
        }
        if (this.mainList.size() != this.imageList_forSel.size()) {
            Toast.makeText(this, "list size count fail!", 1).show();
            this.gIsFinished = true;
            finish();
        }
        this.btn_toolbar_tv_file_num.setText(String.valueOf(String.valueOf(selectedFileCount)) + "\n" + "/" + String.valueOf(this.mainList.size()));
        if (selectedFileCount == 0) {
            this.btn_toolbar_share_file.setEnabled(false);
            this.btn_toolbar_delete_file.setEnabled(false);
            this.btn_toolbar_file_menu.setEnabled(false);
            this.btn_toolbar_share_file.setBackgroundDrawable(getResources().getDrawable(R.drawable.sharefile_button_disable));
            this.btn_toolbar_delete_file.setBackgroundDrawable(getResources().getDrawable(R.drawable.delete_button_disable));
            this.btn_toolbar_file_menu.setBackgroundDrawable(getResources().getDrawable(R.drawable.filemenu_button_disable));
        } else if (selectedFileCount == 1) {
            this.btn_toolbar_share_file.setEnabled(true);
            this.btn_toolbar_delete_file.setEnabled(true);
            this.btn_toolbar_file_menu.setEnabled(true);
            this.btn_toolbar_share_file.setBackgroundDrawable(getResources().getDrawable(R.drawable.sharefile_button_normal));
            this.btn_toolbar_delete_file.setBackgroundDrawable(getResources().getDrawable(R.drawable.delete_button_normal));
            this.btn_toolbar_file_menu.setBackgroundDrawable(getResources().getDrawable(R.drawable.filemenu_button_normal));
        } else if (selectedFileCount > 1 && bHaveNotJpegFile.booleanValue()) {
            this.btn_toolbar_share_file.setEnabled(true);
            this.btn_toolbar_delete_file.setEnabled(true);
            this.btn_toolbar_file_menu.setEnabled(false);
            this.btn_toolbar_share_file.setBackgroundDrawable(getResources().getDrawable(R.drawable.sharefile_button_normal));
            this.btn_toolbar_delete_file.setBackgroundDrawable(getResources().getDrawable(R.drawable.delete_button_normal));
            this.btn_toolbar_file_menu.setBackgroundDrawable(getResources().getDrawable(R.drawable.filemenu_button_disable));
        }
    }

    /* access modifiers changed from: package-private */
    public void __________mark_tab_button() {
    }

    public boolean tabBtnOnTouch(int number, View view, MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            case 0:
                if (number != 0) {
                    if (number != 1) {
                        if (number == 2) {
                            tabBar_btnClick(2);
                            break;
                        }
                    } else {
                        tabBar_btnClick(1);
                        break;
                    }
                } else {
                    tabBar_btnClick(0);
                    break;
                }
                break;
        }
        return false;
    }

    /* access modifiers changed from: package-private */
    public void tabBar_btnClick(int number) {
        this.m_pageNumber = number;
        content_x_uiUpdate_and_process();
    }

    /* access modifiers changed from: package-private */
    public void content_x_uiUpdate_and_process() {
        if (this.m_viewMode != 1) {
            content_x_uiUpdate(this.m_pageNumber);
            if (this.m_curFilePosition != -1) {
                content_x_process(this.m_pageNumber);
                return;
            }
            this.content0_container.setVisibility(4);
            this.content1_container.setVisibility(4);
            this.layout_content2.setVisibility(4);
            Toast.makeText(this, R.string.PhotoNotFound, 0).show();
        }
    }

    /* access modifiers changed from: package-private */
    public void content_x_uiUpdate(int number) {
        if (number == 0 || number == 2) {
            if (!(this.which_map == WHICH_MAP.GOOGLE_MAP_ANDROID_V2 || this.which_map == WHICH_MAP.GOOGLE_MAP_JS_V3 || this.which_map == WHICH_MAP.BAIDU_MAP_ANDROID || this.which_map == WHICH_MAP.AMAZON_MAP_ANDROID || this.which_map != WHICH_MAP.NOKIA_MAP_JS)) {
                this.mapNokiaJavascript.setMapVisible(false);
            }
            this.content1_sp_map_type.setVisibility(4);
            this.btn_content1_normal_full_screen.setVisibility(4);
        }
        this.content1_tv_no_gps_info.setVisibility(4);
        this.content1_ll_edit_poi.setVisibility(4);
        this.btn_tab0.setBackgroundDrawable(getResources().getDrawable(R.drawable.btn_tab_normal));
        this.btn_tab1.setBackgroundDrawable(getResources().getDrawable(R.drawable.btn_tab_normal));
        this.btn_tab2.setBackgroundDrawable(getResources().getDrawable(R.drawable.btn_tab_normal));
        this.content0_container.setVisibility(4);
        this.content1_container.setVisibility(4);
        this.layout_content2.setVisibility(4);
        if (number == 0) {
            this.btn_tab0.setBackgroundDrawable(getResources().getDrawable(R.drawable.btn_tab_press));
            this.content0_container.setVisibility(0);
        } else if (number == 1) {
            this.btn_tab1.setBackgroundDrawable(getResources().getDrawable(R.drawable.btn_tab_press));
            this.content1_container.setVisibility(0);
        } else if (number == 2) {
            this.btn_tab2.setBackgroundDrawable(getResources().getDrawable(R.drawable.btn_tab_press));
            this.layout_content2.setVisibility(0);
        }
    }

    /* access modifiers changed from: package-private */
    public void content_x_process(int number) {
        if (number == 0) {
            content_0_process();
        } else if (number == 1) {
            content_1_process();
        } else if (number == 2) {
            content_2_process();
        }
    }

    /* access modifiers changed from: package-private */
    public void __________mark_content_0() {
    }

    /* access modifiers changed from: package-private */
    public void content_0_process() {
        if (this.content0_pageAdapter == null) {
            this.content0_pageAdapter = new ImagePagerAdapter(this, (ImagePagerAdapter) null);
            this.content0_viewPager.setPageMargin(convertDip2Pixels(this, 10));
            this.content0_viewPager.setAdapter(this.content0_pageAdapter);
            this.content0_viewPager.setOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
                public void onPageSelected(int position) {
                    MainActivity.this.myOnPageSelectedLogic(position);
                }
            });
            this.content0_viewPager.setCurrentItem(this.m_curFilePosition);
            if (this.m_curFilePosition == 0) {
                myOnPageSelectedLogic(0);
                return;
            }
            return;
        }
        this.content0_viewPager.setCurrentItem(this.m_curFilePosition);
    }

    /* access modifiers changed from: package-private */
    public void myOnPageSelectedLogic(int position) {
        TouchImageView tiv;
        TouchImageView tiv2;
        this.m_curFilePosition = position;
        this.m_curFileName = (String) this.mainList.get(position).get("data");
        if (this.mainList.get(this.m_curFilePosition).get("latitude") == null) {
            this.m_isGoogleMapEnable = false;
            this.btn_toolbar_google_map.setBackgroundDrawable(getResources().getDrawable(R.drawable.google_map_disable));
        } else {
            this.m_isGoogleMapEnable = true;
            this.btn_toolbar_google_map.setBackgroundDrawable(getResources().getDrawable(R.drawable.google_map_normal));
        }
        int leftPosition = this.m_curFilePosition - 1;
        int rightPosition = this.m_curFilePosition + 1;
        if (leftPosition >= 0 && (tiv2 = (TouchImageView) this.content0_viewPager.findViewWithTag(String.valueOf(leftPosition))) != null) {
            tiv2.setTo1X();
            Bitmap tmpBigBitmap = tiv2.getBigBitmap();
            if (tmpBigBitmap != null) {
                tiv2.setImageBitmap(tiv2.getSmallBitmap());
                if (!tmpBigBitmap.isRecycled()) {
                    tmpBigBitmap.recycle();
                }
                tiv2.setBigBitmap((Bitmap) null);
                tiv2.setBigBitmapNeedLoaded(false);
            }
        }
        if (rightPosition < this.mainList.size() && (tiv = (TouchImageView) this.content0_viewPager.findViewWithTag(String.valueOf(rightPosition))) != null) {
            tiv.setTo1X();
            Bitmap tmpBigBitmap2 = tiv.getBigBitmap();
            if (tmpBigBitmap2 != null) {
                tiv.setImageBitmap(tiv.getSmallBitmap());
                if (!tmpBigBitmap2.isRecycled()) {
                    tmpBigBitmap2.recycle();
                }
                tiv.setBigBitmap((Bitmap) null);
                tiv.setBigBitmapNeedLoaded(false);
            }
        }
        if (!(this.bigBmp_forPosAtask == null || this.bigBmp_forPosAtask.aTask == null)) {
            this.bigBmp_forPosAtask.aTask.cancel(true);
            this.bigBmp_forPosAtask = null;
        }
        Message m = this.customHandler.obtainMessage();
        m.what = 256;
        m.arg1 = position;
        m.arg2 = 1;
        this.customHandler.sendMessageDelayed(m, 300);
        this.adapter.notifyDataSetChanged();
        this.gridView.clearFocus();
        this.gridView.post(new Runnable() {
            public void run() {
                int first = MainActivity.this.gridView.getFirstVisiblePosition();
                int last = MainActivity.this.gridView.getLastVisiblePosition();
                if (MainActivity.this.m_curFilePosition < first || MainActivity.this.m_curFilePosition > last) {
                    MainActivity.this.gridView.setSelection(MainActivity.this.m_curFilePosition);
                }
            }
        });
    }

    public static int convertDip2Pixels(Context context, int dip) {
        return (int) TypedValue.applyDimension(1, (float) dip, context.getResources().getDisplayMetrics());
    }

    private class ImagePagerAdapter extends PagerAdapter {
        private ImagePagerAdapter() {
        }

        /* synthetic */ ImagePagerAdapter(MainActivity mainActivity, ImagePagerAdapter imagePagerAdapter) {
            this();
        }

        public int getCount() {
            return MainActivity.this.mainList.size();
        }

        public boolean isViewFromObject(View view, Object object) {
            return view == ((TouchImageView) object);
        }

        public Object instantiateItem(ViewGroup container, int position) {
            TouchImageView imageView = new TouchImageView(MainActivity.this);
            imageView.setTag(String.valueOf(position));
            imageView.setImageViewPager(MainActivity.this.content0_viewPager);
            MainActivity.this.content_0_process_decode_smallBitmap_async(position, imageView);
            ((ViewPager) container).addView(imageView, 0);
            return imageView;
        }

        public void destroyItem(ViewGroup container, int position, Object object) {
            int i = 0;
            while (true) {
                if (i >= MainActivity.this.list_forPosAtask.size()) {
                    break;
                }
                PosATask posAtask = MainActivity.this.list_forPosAtask.get(i);
                if (posAtask.position == position) {
                    if (posAtask.aTask != null) {
                        posAtask.aTask.cancel(true);
                    }
                    MainActivity.this.list_forPosAtask.remove(i);
                } else {
                    i++;
                }
            }
            Bitmap tmpSmallBitmap = ((TouchImageView) object).getSmallBitmap();
            if (tmpSmallBitmap != null && !tmpSmallBitmap.isRecycled()) {
                tmpSmallBitmap.recycle();
            }
            Bitmap tmpBigBitmap = ((TouchImageView) object).getBigBitmap();
            if (tmpBigBitmap != null && !tmpBigBitmap.isRecycled()) {
                tmpBigBitmap.recycle();
            }
            ((ViewPager) container).removeView((TouchImageView) object);
        }
    }

    public void content_0_process_decode_smallBitmap_async(int position, TouchImageView touchImageView) {
        loadSmallBitmap(position, (String) this.mainList.get(position).get("data"), touchImageView, Integer.valueOf((String) this.mainList.get(position).get("orientation")).intValue());
    }

    public void content_0_process_decode_bigBitmap_async(int position, TouchImageView touchImageView) {
        loadBigBitmap(position, (String) this.mainList.get(position).get("data"), touchImageView, Integer.valueOf((String) this.mainList.get(position).get("orientation")).intValue());
    }

    /* access modifiers changed from: package-private */
    public void __________mark_decode_jpeg_async() {
    }

    public void loadSmallBitmap(int position, String filepath, TouchImageView imageView, int image_orientation) {
        SmallBitmapWorkerTask task = new SmallBitmapWorkerTask(imageView, image_orientation);
        boolean bFindPos = false;
        int i = 0;
        while (true) {
            if (i >= this.list_forPosAtask.size()) {
                break;
            } else if (this.list_forPosAtask.get(i).position == position) {
                bFindPos = true;
                break;
            } else {
                i++;
            }
        }
        if (!bFindPos) {
            this.list_forPosAtask.add(new PosATask(position, task));
        }
        task.execute(new String[]{filepath});
    }

    public void loadBigBitmap(int position, String filepath, TouchImageView imageView, int image_orientation) {
        BigBitmapWorkerTask task = new BigBitmapWorkerTask(imageView, image_orientation);
        this.bigBmp_forPosAtask = new PosATask(position, task);
        task.execute(new String[]{filepath});
    }

    class SmallBitmapWorkerTask extends AsyncTask<String, Void, Bitmap> {
        private String data = "";
        private final WeakReference<TouchImageView> imageViewReference;
        private int image_orientation;
        int realPhotoHeight = 100;
        int realPhotoWidth = 100;

        public SmallBitmapWorkerTask(TouchImageView imageView, int image_orientation2) {
            this.imageViewReference = new WeakReference<>(imageView);
            this.image_orientation = image_orientation2;
        }

        /* access modifiers changed from: protected */
        public Bitmap doInBackground(String... params) {
            this.data = params[0];
            if (isCancelled()) {
                return null;
            }
            return decodeSmallBitmapFromFilepath(this.data, this.image_orientation);
        }

        /* access modifiers changed from: protected */
        public void onPostExecute(Bitmap bitmap) {
            TouchImageView imageView;
            if (this.imageViewReference != null && bitmap != null && (imageView = (TouchImageView) this.imageViewReference.get()) != null) {
                imageView.setRealPhotoWidth(this.realPhotoWidth);
                imageView.setRealPhotoHeight(this.realPhotoHeight);
                imageView.setSmallBitmap(bitmap);
                imageView.setImageBitmap(bitmap);
            }
        }

        public Bitmap decodeSmallBitmapFromFilepath(String filepath, int image_orientation2) {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(filepath, options);
            this.realPhotoWidth = options.outWidth;
            this.realPhotoHeight = options.outHeight;
            if (MainActivity.this.gMaxMemory >= 133169152) {
                options.inSampleSize = MainActivity.this.calculateInSampleSize_MaxSize(2, AccessibilityEventCompat.TYPE_TOUCH_INTERACTION_START, options.outWidth, options.outHeight);
            } else if (MainActivity.this.gMaxMemory >= 66060288) {
                options.inSampleSize = MainActivity.this.calculateInSampleSize_MaxSize(2, AccessibilityEventCompat.TYPE_TOUCH_INTERACTION_START, options.outWidth, options.outHeight);
            } else if (MainActivity.this.gMaxMemory >= 32505856) {
                options.inSampleSize = MainActivity.this.calculateInSampleSize_MaxSize(2, AccessibilityEventCompat.TYPE_GESTURE_DETECTION_END, options.outWidth, options.outHeight);
            } else if (MainActivity.this.gMaxMemory >= 15728640) {
                options.inSampleSize = MainActivity.this.calculateInSampleSize_MaxSize(2, AccessibilityEventCompat.TYPE_GESTURE_DETECTION_END, options.outWidth, options.outHeight);
            } else if (MainActivity.this.gMaxMemory >= 7340032) {
                options.inSampleSize = MainActivity.this.calculateInSampleSize_MaxSize(2, AccessibilityEventCompat.TYPE_GESTURE_DETECTION_END, options.outWidth, options.outHeight);
            } else {
                options.inSampleSize = MainActivity.this.calculateInSampleSize_MaxSize(2, AccessibilityEventCompat.TYPE_GESTURE_DETECTION_END, options.outWidth, options.outHeight);
            }
            options.inJustDecodeBounds = false;
            options.inPreferredConfig = Bitmap.Config.RGB_565;
            Bitmap bitmap = BitmapFactory.decodeFile(filepath, options);
            if (bitmap != null && image_orientation2 > 0) {
                Matrix matrix = new Matrix();
                matrix.postRotate((float) image_orientation2);
                Bitmap tmpBitmap = bitmap;
                bitmap = Bitmap.createBitmap(tmpBitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
                if (!tmpBitmap.isRecycled()) {
                    tmpBitmap.recycle();
                }
            }
            return bitmap;
        }
    }

    class BigBitmapWorkerTask extends AsyncTask<String, Void, Bitmap> {
        private String data = "";
        private final WeakReference<TouchImageView> imageViewReference;
        private int image_orientation;

        public BigBitmapWorkerTask(TouchImageView imageView, int image_orientation2) {
            this.imageViewReference = new WeakReference<>(imageView);
            this.image_orientation = image_orientation2;
        }

        /* access modifiers changed from: protected */
        public Bitmap doInBackground(String... params) {
            this.data = params[0];
            synchronized (MainActivity.this.decodeSyncObj) {
                if (isCancelled()) {
                    return null;
                }
                Bitmap bitmap = decodeBigBitmapFromFilepath(this.data, this.image_orientation);
                return bitmap;
            }
        }

        /* access modifiers changed from: protected */
        public void onPostExecute(Bitmap bitmap) {
            TouchImageView imageView;
            if (this.imageViewReference != null && bitmap != null && (imageView = (TouchImageView) this.imageViewReference.get()) != null) {
                if (imageView.getBigBitmapNeedLoaded()) {
                    imageView.setBigBitmap(bitmap);
                    imageView.setImageBitmap(bitmap);
                    imageView.setBigBitmapNeedLoaded(false);
                } else if (bitmap != null && !bitmap.isRecycled()) {
                    bitmap.recycle();
                }
            }
        }

        public Bitmap decodeBigBitmapFromFilepath(String filepath, int image_orientation2) {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(filepath, options);
            if (MainActivity.this.gMaxMemory >= 133169152) {
                options.inSampleSize = MainActivity.this.calculateInSampleSize_MaxSize(2, GravityCompat.RELATIVE_LAYOUT_DIRECTION, options.outWidth, options.outHeight);
            } else if (MainActivity.this.gMaxMemory >= 66060288) {
                options.inSampleSize = MainActivity.this.calculateInSampleSize_MaxSize(2, GravityCompat.RELATIVE_LAYOUT_DIRECTION, options.outWidth, options.outHeight);
            } else if (MainActivity.this.gMaxMemory >= 32505856) {
                options.inSampleSize = MainActivity.this.calculateInSampleSize_MaxSize(2, 4194304, options.outWidth, options.outHeight);
            } else if (MainActivity.this.gMaxMemory >= 15728640) {
                options.inSampleSize = MainActivity.this.calculateInSampleSize_MaxSize(2, AccessibilityEventCompat.TYPE_TOUCH_INTERACTION_END, options.outWidth, options.outHeight);
            } else if (MainActivity.this.gMaxMemory >= 7340032) {
                options.inSampleSize = MainActivity.this.calculateInSampleSize_MaxSize(2, AccessibilityEventCompat.TYPE_TOUCH_INTERACTION_START, options.outWidth, options.outHeight);
            } else {
                options.inSampleSize = MainActivity.this.calculateInSampleSize_MaxSize(2, AccessibilityEventCompat.TYPE_GESTURE_DETECTION_END, options.outWidth, options.outHeight);
            }
            options.inJustDecodeBounds = false;
            options.inPreferredConfig = Bitmap.Config.RGB_565;
            Bitmap bitmap = BitmapFactory.decodeFile(filepath, options);
            if (bitmap != null && image_orientation2 > 0) {
                Matrix matrix = new Matrix();
                matrix.postRotate((float) image_orientation2);
                Bitmap tmpBitmap = bitmap;
                bitmap = Bitmap.createBitmap(tmpBitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
                if (!tmpBitmap.isRecycled()) {
                    tmpBitmap.recycle();
                }
            }
            return bitmap;
        }
    }

    public int calculateInSampleSize_MaxSize(int bytesPerPixel, int wantedMemorySize, int imgWidth, int imgHeight) {
        long totMemorySize = (long) (imgWidth * imgHeight * bytesPerPixel);
        if (totMemorySize <= ((long) (wantedMemorySize * 1))) {
            return 1;
        }
        if (totMemorySize <= ((long) (wantedMemorySize * 4))) {
            return 2;
        }
        if (totMemorySize <= ((long) (wantedMemorySize * 16))) {
            return 4;
        }
        if (totMemorySize <= ((long) (wantedMemorySize * 64))) {
            return 8;
        }
        if (totMemorySize <= ((long) (wantedMemorySize * 256))) {
            return 16;
        }
        return 32;
    }

    /* access modifiers changed from: package-private */
    public void __________mark_content_1() {
    }

    /* access modifiers changed from: package-private */
    public void content_1_process() {
        ExifInterface exif;
        boolean bShowMap = false;
        GeoDegree gDegree = null;
        try {
            if (!(this.m_curFileName == null || (exif = new ExifInterface(this.m_curFileName)) == null || exif.getAttribute("GPSLatitude") == null)) {
                GeoDegree gDegree2 = new GeoDegree(exif);
                if (gDegree2 != null) {
                    try {
                        if (!(this.which_map == WHICH_MAP.GOOGLE_MAP_ANDROID_V2 || this.which_map == WHICH_MAP.GOOGLE_MAP_JS_V3 || this.which_map == WHICH_MAP.BAIDU_MAP_ANDROID || this.which_map == WHICH_MAP.AMAZON_MAP_ANDROID || this.which_map != WHICH_MAP.NOKIA_MAP_JS || !this.mapNokiaJavascript.isMapReadyForUse())) {
                            bShowMap = true;
                            gDegree = gDegree2;
                        }
                    } catch (IOException e) {
                        e = e;
                        GeoDegree geoDegree = gDegree2;
                        e.printStackTrace();
                    }
                }
                gDegree = gDegree2;
            }
            if (bShowMap) {
                if (!(this.which_map == WHICH_MAP.GOOGLE_MAP_ANDROID_V2 || this.which_map == WHICH_MAP.GOOGLE_MAP_JS_V3 || this.which_map == WHICH_MAP.BAIDU_MAP_ANDROID || this.which_map == WHICH_MAP.AMAZON_MAP_ANDROID || this.which_map != WHICH_MAP.NOKIA_MAP_JS)) {
                    this.mapNokiaJavascript.setMapVisible(true);
                    this.content1_sp_map_type.setVisibility(4);
                    this.btn_content1_normal_full_screen.setVisibility(4);
                }
                this.content1_tv_no_gps_info.setVisibility(4);
                this.content1_ll_edit_poi.setVisibility(4);
                this.content1_sp_map_type.setSelection(this.m_mapTypeSelect);
                if (!checkNetworkAvailable().booleanValue()) {
                    Toast.makeText(this, getString(R.string.NetworkNeedEnable), 1).show();
                } else if (this.which_map != WHICH_MAP.GOOGLE_MAP_ANDROID_V2 && this.which_map != WHICH_MAP.GOOGLE_MAP_JS_V3 && this.which_map != WHICH_MAP.BAIDU_MAP_ANDROID && this.which_map != WHICH_MAP.AMAZON_MAP_ANDROID && this.which_map == WHICH_MAP.NOKIA_MAP_JS) {
                    this.mapNokiaJavascript.setLatitudeLongitude((double) gDegree.Latitude.floatValue(), (double) gDegree.Longitude.floatValue());
                    this.mapNokiaJavascript.setUpMapIfNeeded();
                    this.mapNokiaJavascript.onResetMap();
                }
            } else {
                if (!(this.which_map == WHICH_MAP.GOOGLE_MAP_ANDROID_V2 || this.which_map == WHICH_MAP.GOOGLE_MAP_JS_V3 || this.which_map == WHICH_MAP.BAIDU_MAP_ANDROID || this.which_map == WHICH_MAP.AMAZON_MAP_ANDROID || this.which_map != WHICH_MAP.NOKIA_MAP_JS)) {
                    this.mapNokiaJavascript.setMapVisible(false);
                }
                this.content1_sp_map_type.setVisibility(4);
                this.btn_content1_normal_full_screen.setVisibility(4);
                this.content1_tv_no_gps_info.setVisibility(0);
                Boolean bNotJpeg = true;
                String lastExt = this.m_curFileName.substring(this.m_curFileName.lastIndexOf(46) + 1);
                if (lastExt.equalsIgnoreCase("jpg") || lastExt.equalsIgnoreCase("jpeg")) {
                    bNotJpeg = false;
                }
                if (bNotJpeg.booleanValue()) {
                    this.content1_ll_edit_poi.setVisibility(4);
                } else {
                    this.content1_ll_edit_poi.setVisibility(0);
                }
            }
        } catch (IOException e2) {
            e = e2;
            e.printStackTrace();
        }
    }

    /* access modifiers changed from: package-private */
    public void __________mark_content_2() {
    }

    /* access modifiers changed from: package-private */
    public void content_2_process() {
        String str_fullPathName = this.m_curFileName;
        int posOfPathEnd = str_fullPathName.lastIndexOf(47);
        this.content2_info_FolderName.setText(str_fullPathName.substring(0, posOfPathEnd));
        this.content2_info_FileName.setText(str_fullPathName.substring(posOfPathEnd + 1));
        File file = new File(this.m_curFileName);
        long length = file.length();
        if (length > 1024) {
            this.content2_info_FileSize.setText(String.format("%d KB", new Object[]{Long.valueOf(length / 1024)}));
        } else {
            this.content2_info_FileSize.setText(String.format("%d Bytes", new Object[]{Long.valueOf(length)}));
        }
        this.content2_info_ImageWidth.setText("-");
        this.content2_info_ImageHeight.setText("-");
        this.content2_info_FileModifiedTime.setText("-");
        this.content2_info_ImageCaptureTime.setText("-");
        this.content2_info_Latitude.setText("-");
        this.content2_info_Longitude.setText("-");
        this.content2_info_Altitude.setText("-");
        this.content2_info_Make.setText("-");
        this.content2_info_Model.setText("-");
        this.content2_info_Flash.setText("-");
        this.content2_info_FocalLength.setText("-");
        this.content2_info_Aperture.setText("-");
        this.content2_info_ExposureTime.setText("-");
        this.content2_info_WhiteBalance.setText("-");
        this.content2_info_ISO.setText("-");
        this.content2_info_Orientation.setText("-");
        BitmapFactory.Options opt = new BitmapFactory.Options();
        opt.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(this.m_curFileName, opt);
        if (opt.outWidth >= 0) {
            this.content2_info_ImageWidth.setText(String.valueOf(String.valueOf(opt.outWidth)) + " " + getString(R.string.Pixels));
        }
        if (opt.outHeight >= 0) {
            this.content2_info_ImageHeight.setText(String.valueOf(String.valueOf(opt.outHeight)) + " " + getString(R.string.Pixels));
        }
        this.content2_info_FileModifiedTime.setText(new Date(file.lastModified()).toLocaleString());
        String lastExt = this.m_curFileName.substring(this.m_curFileName.lastIndexOf(46) + 1);
        if (lastExt.equalsIgnoreCase("jpg") || lastExt.equalsIgnoreCase("jpeg")) {
            try {
                ExifInterface exif = new ExifInterface(this.m_curFileName);
                if (exif != null) {
                    String tagMake = exif.getAttribute("Make");
                    if (tagMake != null) {
                        this.content2_info_Make.setText(tagMake);
                    }
                    String tagModel = exif.getAttribute("Model");
                    if (tagModel != null) {
                        this.content2_info_Model.setText(tagModel);
                    }
                    String tagDateTime = exif.getAttribute("DateTime");
                    if (tagDateTime != null) {
                        this.content2_info_ImageCaptureTime.setText(tagDateTime);
                    }
                    if (exif.getAttribute("GPSLatitude") != null) {
                        GeoDegree gDegree = new GeoDegree(exif);
                        MyLatLng curLatLng = new MyLatLng((double) gDegree.Latitude.floatValue(), (double) gDegree.Longitude.floatValue());
                        this.content2_info_Latitude.setText(String.valueOf(HelpFuncs.getFloatValueDotN(curLatLng.latitude, 6)));
                        this.content2_info_Longitude.setText(String.valueOf(HelpFuncs.getFloatValueDotN(curLatLng.longitude, 6)));
                        if (gDegree.isAltitudeNull.booleanValue()) {
                            this.content2_info_Altitude.setText(gDegree.strAltitude);
                        } else {
                            this.content2_info_Altitude.setText(String.valueOf(String.valueOf(gDegree.Altitude)) + "m");
                        }
                    }
                    String tagFlash = exif.getAttribute("Flash");
                    if (tagFlash != null) {
                        int iFlash = Integer.valueOf(tagFlash).intValue();
                        if (iFlash == 0) {
                            this.content2_info_Flash.setText(getString(R.string.FlashTag_0000));
                        } else if (iFlash == 1) {
                            this.content2_info_Flash.setText(getString(R.string.FlashTag_0001));
                        } else if (iFlash == 5) {
                            this.content2_info_Flash.setText(getString(R.string.FlashTag_0005));
                        } else if (iFlash == 7) {
                            this.content2_info_Flash.setText(getString(R.string.FlashTag_0007));
                        } else if (iFlash == 9) {
                            this.content2_info_Flash.setText(getString(R.string.FlashTag_0009));
                        } else if (iFlash == 13) {
                            this.content2_info_Flash.setText(getString(R.string.FlashTag_000D));
                        } else if (iFlash == 15) {
                            this.content2_info_Flash.setText(getString(R.string.FlashTag_000F));
                        } else if (iFlash == 16) {
                            this.content2_info_Flash.setText(getString(R.string.FlashTag_0010));
                        } else if (iFlash == 24) {
                            this.content2_info_Flash.setText(getString(R.string.FlashTag_0018));
                        } else if (iFlash == 25) {
                            this.content2_info_Flash.setText(getString(R.string.FlashTag_0019));
                        } else if (iFlash == 29) {
                            this.content2_info_Flash.setText(getString(R.string.FlashTag_001D));
                        } else if (iFlash == 31) {
                            this.content2_info_Flash.setText(getString(R.string.FlashTag_001F));
                        } else if (iFlash == 32) {
                            this.content2_info_Flash.setText(getString(R.string.FlashTag_0020));
                        } else if (iFlash == 65) {
                            this.content2_info_Flash.setText(getString(R.string.FlashTag_0041));
                        } else if (iFlash == 69) {
                            this.content2_info_Flash.setText(getString(R.string.FlashTag_0045));
                        } else if (iFlash == 71) {
                            this.content2_info_Flash.setText(getString(R.string.FlashTag_0047));
                        } else if (iFlash == 73) {
                            this.content2_info_Flash.setText(getString(R.string.FlashTag_0049));
                        } else if (iFlash == 77) {
                            this.content2_info_Flash.setText(getString(R.string.FlashTag_004D));
                        } else if (iFlash == 79) {
                            this.content2_info_Flash.setText(getString(R.string.FlashTag_004F));
                        } else if (iFlash == 89) {
                            this.content2_info_Flash.setText(getString(R.string.FlashTag_0059));
                        } else if (iFlash == 93) {
                            this.content2_info_Flash.setText(getString(R.string.FlashTag_005D));
                        } else if (iFlash == 95) {
                            this.content2_info_Flash.setText(getString(R.string.FlashTag_005F));
                        }
                    }
                    String stringFocalLengthPercentage = exif.getAttribute("FocalLength");
                    if (stringFocalLengthPercentage != null) {
                        try {
                            String[] stringFocalLegnth = stringFocalLengthPercentage.split("/", 2);
                            this.content2_info_FocalLength.setText(String.valueOf(String.valueOf(Float.valueOf(new Float(stringFocalLegnth[0]).floatValue() / new Float(stringFocalLegnth[1]).floatValue()))) + " mm");
                        } catch (NumberFormatException e) {
                        }
                    }
                    String tagAperture = exif.getAttribute("FNumber");
                    if (tagAperture != null) {
                        this.content2_info_Aperture.setText(tagAperture);
                    }
                    String tagExposureTime = exif.getAttribute("ExposureTime");
                    if (tagExposureTime != null) {
                        this.content2_info_ExposureTime.setText(String.valueOf(tagExposureTime) + " sec");
                        try {
                            Float fExposureTime = Float.valueOf(Float.parseFloat(tagExposureTime));
                            if (fExposureTime.floatValue() > 0.0f && ((double) fExposureTime.floatValue()) <= 0.01d) {
                                this.content2_info_ExposureTime.setText(String.valueOf(tagExposureTime) + "  or  1/" + String.valueOf(Math.round(1.0f / fExposureTime.floatValue())) + " sec");
                            } else if (((double) fExposureTime.floatValue()) > 0.01d && ((double) fExposureTime.floatValue()) <= 0.1d) {
                                this.content2_info_ExposureTime.setText(String.valueOf(tagExposureTime) + "  or  10/" + String.valueOf(Math.round(10.0f / fExposureTime.floatValue())) + " sec");
                            } else if (((double) fExposureTime.floatValue()) > 0.1d && fExposureTime.floatValue() <= 1.0f) {
                                this.content2_info_ExposureTime.setText(String.valueOf(tagExposureTime) + "  or  100/" + String.valueOf(Math.round(100.0f / fExposureTime.floatValue())) + " sec");
                            }
                        } catch (NumberFormatException e2) {
                        }
                    }
                    String tagWhiteBalance = exif.getAttribute("WhiteBalance");
                    if (tagWhiteBalance != null) {
                        int iWhiteBalance = Integer.valueOf(tagWhiteBalance).intValue();
                        if (iWhiteBalance == 0) {
                            this.content2_info_WhiteBalance.setText(getString(R.string.AutoWhiteBalance));
                        } else if (iWhiteBalance == 1) {
                            this.content2_info_WhiteBalance.setText(getString(R.string.ManualWhiteBalance));
                        } else {
                            this.content2_info_WhiteBalance.setText(getString(R.string.Reserved));
                        }
                    }
                    String tagISO = exif.getAttribute("ISOSpeedRatings");
                    if (tagISO != null) {
                        this.content2_info_ISO.setText(tagISO);
                    }
                    String tagOrientation = exif.getAttribute("Orientation");
                    if (tagOrientation != null) {
                        int iOrientation = Integer.valueOf(tagOrientation).intValue();
                        if (iOrientation == 1) {
                            this.content2_info_Orientation.setText(String.valueOf(getString(R.string.Top)) + ", " + getString(R.string.Left) + " (" + tagOrientation + ")");
                        } else if (iOrientation == 2) {
                            this.content2_info_Orientation.setText(String.valueOf(getString(R.string.Top)) + ", " + getString(R.string.Right) + " (" + tagOrientation + ")");
                        } else if (iOrientation == 3) {
                            this.content2_info_Orientation.setText(String.valueOf(getString(R.string.Bottom)) + ", " + getString(R.string.Right) + " (" + tagOrientation + ")");
                        } else if (iOrientation == 4) {
                            this.content2_info_Orientation.setText(String.valueOf(getString(R.string.Bottom)) + ", " + getString(R.string.Left) + " (" + tagOrientation + ")");
                        } else if (iOrientation == 5) {
                            this.content2_info_Orientation.setText(String.valueOf(getString(R.string.Left)) + ", " + getString(R.string.Top) + " (" + tagOrientation + ")");
                        } else if (iOrientation == 6) {
                            this.content2_info_Orientation.setText(String.valueOf(getString(R.string.Right)) + ", " + getString(R.string.Top) + " (" + tagOrientation + ")");
                        } else if (iOrientation == 7) {
                            this.content2_info_Orientation.setText(String.valueOf(getString(R.string.Right)) + ", " + getString(R.string.Bottom) + " (" + tagOrientation + ")");
                        } else if (iOrientation == 8) {
                            this.content2_info_Orientation.setText(String.valueOf(getString(R.string.Left)) + ", " + getString(R.string.Bottom) + " (" + tagOrientation + ")");
                        }
                    }
                } else {
                    this.content2_info_ImageCaptureTime.setText("-");
                    this.content2_info_Latitude.setText("-");
                    this.content2_info_Longitude.setText("-");
                    this.content2_info_Altitude.setText("-");
                    this.content2_info_Make.setText("-");
                    this.content2_info_Model.setText("-");
                    this.content2_info_Flash.setText("-");
                    this.content2_info_FocalLength.setText("-");
                    this.content2_info_Aperture.setText("-");
                    this.content2_info_ExposureTime.setText("-");
                    this.content2_info_WhiteBalance.setText("-");
                    this.content2_info_ISO.setText("-");
                    this.content2_info_Orientation.setText("-");
                }
            } catch (IOException e3) {
                e3.printStackTrace();
                Toast.makeText(this, "Error!", 1).show();
                this.content2_info_ImageCaptureTime.setText("-");
                this.content2_info_Latitude.setText("-");
                this.content2_info_Longitude.setText("-");
                this.content2_info_Altitude.setText("-");
                this.content2_info_Make.setText("-");
                this.content2_info_Model.setText("-");
                this.content2_info_Flash.setText("-");
                this.content2_info_FocalLength.setText("-");
                this.content2_info_Aperture.setText("-");
                this.content2_info_ExposureTime.setText("-");
                this.content2_info_WhiteBalance.setText("-");
                this.content2_info_ISO.setText("-");
                this.content2_info_Orientation.setText("-");
            }
        }
    }

    private void ShowExif(ExifInterface exif) {
        String myAttribute = String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf(String.valueOf("Exif information ---\n") + getTagString("DateTime", exif)) + getTagString("Flash", exif)) + getTagString("GPSLatitude", exif)) + getTagString("GPSLatitudeRef", exif)) + getTagString("GPSLongitude", exif)) + getTagString("GPSLongitudeRef", exif)) + getTagString("ImageWidth", exif)) + getTagString("ImageLength", exif)) + getTagString("Make", exif)) + getTagString("Model", exif)) + getTagString("Orientation", exif)) + getTagString("WhiteBalance", exif);
    }

    private void WriteExif(ExifInterface exif) {
        exif.setAttribute("DateTime", "20100705");
        exif.setAttribute("Flash", "YES");
        exif.setAttribute("GPSLatitude", "L01");
        exif.setAttribute("GPSLatitudeRef", "R01");
        exif.setAttribute("GPSLongitude", "L02");
        exif.setAttribute("GPSLongitudeRef", "R02");
        exif.setAttribute("ImageWidth", "800px");
        exif.setAttribute("ImageLength", "600px");
        exif.setAttribute("Make", "David Tai");
        exif.setAttribute("Model", "Asus Phone");
        exif.setAttribute("Orientation", "no");
        exif.setAttribute("WhiteBalance", "AUTO");
    }

    private String getTagString(String tag, ExifInterface exif) {
        return String.valueOf(tag) + " : " + exif.getAttribute(tag) + "\n";
    }

    /* access modifiers changed from: package-private */
    public void __________mark_content_main() {
    }

    private static boolean checkFsWritable() {
        File directory = new File(String.valueOf(Environment.getExternalStorageDirectory().toString()) + "/DCIM");
        if (directory.isDirectory() || directory.mkdirs()) {
            return directory.canWrite();
        }
        return false;
    }

    public boolean hasStorage(boolean requireWriteAccess) {
        String state = Environment.getExternalStorageState();
        if ("mounted".equals(state)) {
            if (requireWriteAccess) {
                return checkFsWritable();
            }
            return true;
        } else if (requireWriteAccess || !"mounted_ro".equals(state)) {
            return false;
        } else {
            return true;
        }
    }

    public boolean isMediaScannerScanning() {
        boolean result = false;
        Cursor cursor = getContentResolver().query(MediaStore.getMediaScannerUri(), new String[]{"volume"}, (String) null, (String[]) null, (String) null);
        if (cursor != null) {
            if (cursor.getCount() >= 1) {
                result = true;
            }
            cursor.close();
        }
        return result;
    }

    /* access modifiers changed from: package-private */
    public Boolean getMediaData() {
        String sortGroup;
        String[] projection = {"_id", "_data", "_display_name", "date_modified", "latitude", "orientation"};
        String selectBucketId = "bucket_id='" + this.m_bucketId + "'";
        String selectGroup = null;
        String sortGroup2 = null;
        if (this.m_mimeMode == 0 && this.m_gpsMode == 0 && this.m_folderMode == 0) {
            selectGroup = null;
        } else {
            Boolean bFirstAlreadyAdded = false;
            if (this.m_mimeMode != 0) {
                if (!bFirstAlreadyAdded.booleanValue()) {
                    selectGroup = "mime_type='image/jpeg'";
                    bFirstAlreadyAdded = true;
                } else {
                    selectGroup = String.valueOf(String.valueOf((Object) null) + " AND ") + "mime_type='image/jpeg'";
                }
            }
            if (this.m_gpsMode != 0) {
                if (!bFirstAlreadyAdded.booleanValue()) {
                    selectGroup = "latitude<>'null'";
                    bFirstAlreadyAdded = true;
                } else {
                    selectGroup = String.valueOf(String.valueOf(selectGroup) + " AND ") + "latitude<>'null'";
                }
            }
            if (this.m_folderMode != 0) {
                if (!bFirstAlreadyAdded.booleanValue()) {
                    selectGroup = selectBucketId;
                } else {
                    selectGroup = String.valueOf(String.valueOf(selectGroup) + " AND ") + selectBucketId;
                }
            }
        }
        if (this.m_sortMode < 0 && this.m_sortMode > 1) {
            this.m_sortMode = 0;
        }
        if (this.m_sortBy < 0 && this.m_sortBy > 3) {
            this.m_sortBy = 0;
        }
        if (this.m_sortMode == 0) {
            if (this.m_sortBy == 0) {
                sortGroup2 = "date_added DESC";
            } else if (this.m_sortBy == 1) {
                sortGroup2 = "date_modified DESC";
            } else if (this.m_sortBy == 2) {
                sortGroup2 = "_display_name DESC";
            } else if (this.m_sortBy == 3) {
                sortGroup2 = "_data DESC";
            }
        } else if (this.m_sortMode == 1) {
            if (this.m_sortBy == 0) {
                sortGroup2 = "date_added ASC";
            } else if (this.m_sortBy == 1) {
                sortGroup2 = "date_modified ASC";
            } else if (this.m_sortBy == 2) {
                sortGroup2 = "_display_name ASC";
            } else if (this.m_sortBy == 3) {
                sortGroup2 = "_data ASC";
            }
        }
        Cursor cursor = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, selectGroup, (String[]) null, sortGroup2);
        if (!this.isNeedProcessINTENT_action_view.booleanValue() && ((cursor == null || cursor.getCount() == 0) && this.m_folderMode != 0)) {
            String selectGroup2 = null;
            this.m_folderMode = 0;
            this.m_bucketId = "";
            this.m_bucketName = "";
            if (this.m_mimeMode == 0 && this.m_gpsMode == 0 && this.m_folderMode == 0) {
                selectGroup2 = null;
            } else {
                Boolean bFirstAlreadyAdded2 = false;
                if (this.m_mimeMode != 0) {
                    if (!bFirstAlreadyAdded2.booleanValue()) {
                        selectGroup2 = "mime_type='image/jpeg'";
                        bFirstAlreadyAdded2 = true;
                    } else {
                        selectGroup2 = String.valueOf(String.valueOf((Object) null) + " AND ") + "mime_type='image/jpeg'";
                    }
                }
                if (this.m_gpsMode != 0) {
                    if (!bFirstAlreadyAdded2.booleanValue()) {
                        selectGroup2 = "latitude<>'null'";
                        bFirstAlreadyAdded2 = true;
                    } else {
                        selectGroup2 = String.valueOf(String.valueOf(selectGroup2) + " AND ") + "latitude<>'null'";
                    }
                }
                if (this.m_folderMode != 0) {
                    if (!bFirstAlreadyAdded2.booleanValue()) {
                        selectGroup2 = selectBucketId;
                    } else {
                        selectGroup2 = String.valueOf(String.valueOf(selectGroup2) + " AND ") + selectBucketId;
                    }
                }
            }
            if (this.m_sortMode == 0) {
                sortGroup = "date_modified DESC";
            } else {
                sortGroup = "date_modified ASC";
            }
            cursor = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, selectGroup2, (String[]) null, sortGroup);
        }
        if (cursor == null) {
            return false;
        }
        getColumnData(cursor);
        cursor.close();
        return true;
    }

    private void getColumnData(Cursor cur) {
        if (this.mainList.size() > 0) {
            this.mainList.clear();
        }
        if (cur.getCount() > 0 && cur.moveToFirst()) {
            int index_id = cur.getColumnIndex("_id");
            int index_data = cur.getColumnIndex("_data");
            int index_display_name = cur.getColumnIndex("_display_name");
            int index_date_modified = cur.getColumnIndex("date_modified");
            int index_latitude = cur.getColumnIndex("latitude");
            int index_orientation = cur.getColumnIndex("orientation");
            do {
                int image_id = cur.getInt(index_id);
                String image_data = cur.getString(index_data);
                String image_display_name = cur.getString(index_display_name);
                String image_date_modified = cur.getString(index_date_modified);
                String image_latitude = cur.getString(index_latitude);
                int image_orientation = cur.getInt(index_orientation);
                HashMap<String, String> hash = new HashMap<>();
                hash.put("id", new StringBuilder(String.valueOf(image_id)).toString());
                hash.put("data", image_data);
                hash.put("display_name", image_display_name);
                hash.put("date_modified", image_date_modified);
                hash.put("latitude", image_latitude);
                hash.put("orientation", new StringBuilder(String.valueOf(image_orientation)).toString());
                if (!this.isFileSelectModeEnabled.booleanValue()) {
                    this.imageList_forSel.add("0");
                }
                this.mainList.add(hash);
            } while (cur.moveToNext());
        }
    }

    /* access modifiers changed from: package-private */
    public void getCurrentData() {
        Boolean bFind = false;
        int mainListSize = this.mainList.size();
        if (mainListSize > 0 && this.m_curFilePosition == -1) {
            this.m_curFilePosition = 0;
        }
        if (mainListSize <= 0) {
            this.m_curFilePosition = -1;
            this.m_curFileName = "";
        } else if (mainListSize > this.m_curFilePosition) {
            if (!this.m_curFileName.equals((String) this.mainList.get(this.m_curFilePosition).get("data"))) {
                if (!bFind.booleanValue()) {
                    int searchSize = 0;
                    int searchPosition = this.m_curFilePosition - 1;
                    while (true) {
                        if (searchSize >= 10000 || searchPosition < 0) {
                            break;
                        }
                        if (this.m_curFileName.equals((String) this.mainList.get(searchPosition).get("data"))) {
                            bFind = true;
                            this.m_curFilePosition = searchPosition;
                            break;
                        }
                        searchSize++;
                        searchPosition--;
                    }
                }
                if (!bFind.booleanValue()) {
                    int searchSize2 = 0;
                    int searchPosition2 = this.m_curFilePosition + 1;
                    while (true) {
                        if (searchSize2 >= 10000 || searchPosition2 >= mainListSize) {
                            break;
                        }
                        if (this.m_curFileName.equals((String) this.mainList.get(searchPosition2).get("data"))) {
                            bFind = true;
                            this.m_curFilePosition = searchPosition2;
                            break;
                        }
                        searchSize2++;
                        searchPosition2++;
                    }
                }
                if (!bFind.booleanValue()) {
                    this.m_curFilePosition = 0;
                    this.m_curFileName = (String) this.mainList.get(this.m_curFilePosition).get("data");
                }
            }
        } else if (mainListSize <= this.m_curFilePosition) {
            if (!bFind.booleanValue()) {
                int searchSize3 = 0;
                int searchPosition3 = mainListSize - 1;
                while (true) {
                    if (searchSize3 >= 10000 || searchPosition3 < 0) {
                        break;
                    }
                    if (this.m_curFileName.equals((String) this.mainList.get(searchPosition3).get("data"))) {
                        bFind = true;
                        this.m_curFilePosition = searchPosition3;
                        break;
                    }
                    searchSize3++;
                    searchPosition3--;
                }
            }
            if (!bFind.booleanValue()) {
                this.m_curFilePosition = 0;
                this.m_curFileName = (String) this.mainList.get(0).get("data");
            }
        } else {
            this.m_curFilePosition = 0;
            this.m_curFileName = (String) this.mainList.get(0).get("data");
        }
    }

    /* access modifiers changed from: package-private */
    public void initialGridView() {
        this.gridView.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case 0:
                        MainActivity.this.isLongItemSelected = false;
                        break;
                }
                return false;
            }
        });
        this.gridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            public boolean onItemLongClick(AdapterView<?> adapterView, View v, int position, long id) {
                if (!MainActivity.this.isFileSelectModeEnabled.booleanValue()) {
                    MainActivity.this.isFileSelectModeEnabled = true;
                    for (int i = 0; i < MainActivity.this.mainList.size(); i++) {
                        MainActivity.this.imageList_forSel.set(i, "0");
                    }
                    MainActivity.this.isLongItemSelected = true;
                    Boolean bNotJpeg = true;
                    String displayName = (String) MainActivity.this.mainList.get(position).get("display_name");
                    String lastExt = displayName.substring(displayName.lastIndexOf(46) + 1);
                    if (lastExt.equalsIgnoreCase("jpg") || lastExt.equalsIgnoreCase("jpeg")) {
                        bNotJpeg = false;
                    }
                    if (bNotJpeg.booleanValue()) {
                        MainActivity.this.imageList_forSel.set(position, "-2");
                    } else {
                        MainActivity.this.imageList_forSel.set(position, "1");
                    }
                    MainActivity.this.submenu_toolbar_func1.setVisibility(0);
                    MainActivity.this.submenu_toolbar_func0.setVisibility(4);
                    MainActivity.this.update_sub_menu_func1_button_ui();
                } else {
                    MainActivity.this.isLongItemSelected = true;
                    if (MainActivity.this.imageList_forSel.get(position) != "0") {
                        MainActivity.this.imageList_forSel.set(position, "0");
                    } else {
                        Boolean bNotJpeg2 = true;
                        String displayName2 = (String) MainActivity.this.mainList.get(position).get("display_name");
                        String lastExt2 = displayName2.substring(displayName2.lastIndexOf(46) + 1);
                        if (lastExt2.equalsIgnoreCase("jpg") || lastExt2.equalsIgnoreCase("jpeg")) {
                            bNotJpeg2 = false;
                        }
                        if (bNotJpeg2.booleanValue()) {
                            MainActivity.this.imageList_forSel.set(position, "-2");
                        } else {
                            MainActivity.this.imageList_forSel.set(position, "1");
                        }
                    }
                    MainActivity.this.update_sub_menu_func1_button_ui();
                }
                MainActivity.this.adapter.notifyDataSetChanged();
                return false;
            }
        });
        this.gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View v, int position, long id) {
                if (MainActivity.this.isFileSelectModeEnabled.booleanValue() && !MainActivity.this.isLongItemSelected.booleanValue()) {
                    if (MainActivity.this.imageList_forSel.get(position) != "0") {
                        MainActivity.this.imageList_forSel.set(position, "0");
                    } else {
                        Boolean bNotJpeg = true;
                        String displayName = (String) MainActivity.this.mainList.get(position).get("display_name");
                        String lastExt = displayName.substring(displayName.lastIndexOf(46) + 1);
                        if (lastExt.equalsIgnoreCase("jpg") || lastExt.equalsIgnoreCase("jpeg")) {
                            bNotJpeg = false;
                        }
                        if (bNotJpeg.booleanValue()) {
                            MainActivity.this.imageList_forSel.set(position, "-2");
                        } else {
                            MainActivity.this.imageList_forSel.set(position, "1");
                        }
                    }
                    MainActivity.this.update_sub_menu_func1_button_ui();
                }
                if (MainActivity.this.mainList.get(position).get("latitude") == null) {
                    MainActivity.this.m_isGoogleMapEnable = false;
                    MainActivity.this.btn_toolbar_google_map.setBackgroundDrawable(MainActivity.this.getResources().getDrawable(R.drawable.google_map_disable));
                } else {
                    MainActivity.this.m_isGoogleMapEnable = true;
                    MainActivity.this.btn_toolbar_google_map.setBackgroundDrawable(MainActivity.this.getResources().getDrawable(R.drawable.google_map_normal));
                }
                if (MainActivity.this.m_curFileViewHolder != null) {
                    MainActivity.this.m_curFileViewHolder.imageView.setBackgroundColor(-7829368);
                }
                ViewHolder viewHolder = (ViewHolder) v.getTag();
                viewHolder.imageView.setBackgroundColor(-1);
                MainActivity.this.m_curFileViewHolder = viewHolder;
                MainActivity.this.m_curFilePosition = position;
                MainActivity.this.m_curFileName = (String) MainActivity.this.mainList.get(position).get("data");
                MainActivity.this.content_x_uiUpdate_and_process();
                MainActivity.this.adapter.notifyDataSetChanged();
            }
        });
        this.gridView.setOnScrollListener(new AbsListView.OnScrollListener() {
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
            }

            public void onScrollStateChanged(AbsListView view, int scrollState) {
            }
        });
        this.adapter = new ImageAdapter(this, this);
        this.gridView.setAdapter(this.adapter);
        if (this.m_curFilePosition != -1) {
            this.gridView.setSelection(this.m_curFilePosition);
        }
    }

    public class MemoryCache {
        private HashMap<String, SoftReference<Bitmap>> cache = new HashMap<>();

        public MemoryCache() {
        }

        public Bitmap get(String id) {
            if (!this.cache.containsKey(id)) {
                return null;
            }
            return this.cache.get(id).get();
        }

        public void put(String id, Bitmap bitmap) {
            this.cache.put(id, new SoftReference(bitmap));
        }

        public void clear() {
            this.cache.clear();
        }
    }

    public class ImageLoader {
        /* access modifiers changed from: private */
        public Map<ImageView, String> imageViews = Collections.synchronizedMap(new WeakHashMap());
        MemoryCache memoryCache;
        PhotosLoader photoLoaderThread = new PhotosLoader();
        PhotosQueue photosQueue = new PhotosQueue();
        final int stub_id = R.drawable.gray_16x16;

        public ImageLoader(Context context) {
            this.memoryCache = new MemoryCache();
            this.photoLoaderThread.setPriority(4);
        }

        public void DisplayImage(String url, Activity activity, ImageView imageView) {
            this.imageViews.put(imageView, url);
            Bitmap bitmap = this.memoryCache.get(url);
            if (bitmap != null) {
                imageView.setImageBitmap(bitmap);
                return;
            }
            queuePhoto(url, activity, imageView);
            imageView.setImageResource(R.drawable.gray_16x16);
        }

        private void queuePhoto(String url, Activity activity, ImageView imageView) {
            synchronized (this.photosQueue.photosToLoad) {
                this.photosQueue.Clean(imageView);
                this.photosQueue.photosToLoad.push(new PhotoToLoad(url, imageView));
                this.photosQueue.photosToLoad.notifyAll();
            }
            if (this.photoLoaderThread.getState() == Thread.State.NEW) {
                this.photoLoaderThread.start();
            }
        }

        /* access modifiers changed from: private */
        public Bitmap getBitmap(String url) {
            int image_orientation;
            int position = Integer.valueOf(url).intValue();
            Bitmap bmThumbnail = MediaStore.Images.Thumbnails.getThumbnail(MainActivity.this.getContentResolver(), (long) Integer.valueOf((String) MainActivity.this.mainList.get(position).get("id")).intValue(), 3, (BitmapFactory.Options) null);
            if (bmThumbnail == null || (image_orientation = Integer.valueOf((String) MainActivity.this.mainList.get(position).get("orientation")).intValue()) <= 0) {
                return bmThumbnail;
            }
            Matrix matrix = new Matrix();
            matrix.postRotate((float) image_orientation);
            return Bitmap.createBitmap(bmThumbnail, 0, 0, bmThumbnail.getWidth(), bmThumbnail.getHeight(), matrix, true);
        }

        private class PhotoToLoad {
            public ImageView imageView;
            public String url;

            public PhotoToLoad(String u, ImageView i) {
                this.url = u;
                this.imageView = i;
            }
        }

        public void stopThread() {
            this.photoLoaderThread.interrupt();
        }

        class PhotosQueue {
            /* access modifiers changed from: private */
            public Stack<PhotoToLoad> photosToLoad = new Stack<>();

            PhotosQueue() {
            }

            public void Clean(ImageView image) {
                for (int j = 0; j < this.photosToLoad.size(); j++) {
                    if (((PhotoToLoad) this.photosToLoad.get(j)).imageView == image) {
                        this.photosToLoad.remove(j);
                        return;
                    }
                }
            }
        }

        class PhotosLoader extends Thread {
            PhotosLoader() {
            }

            /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v10, resolved type: java.lang.Object} */
            /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v0, resolved type: com.jkfantasy.photopoinokia.MainActivity$ImageLoader$PhotoToLoad} */
            /* JADX WARNING: Multi-variable type inference failed */
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public void run() {
                /*
                    r9 = this;
                L_0x0000:
                    r5 = 0
                    r4 = 0
                    com.jkfantasy.photopoinokia.MainActivity$ImageLoader r7 = com.jkfantasy.photopoinokia.MainActivity.ImageLoader.this     // Catch:{ InterruptedException -> 0x007f }
                    com.jkfantasy.photopoinokia.MainActivity$ImageLoader$PhotosQueue r7 = r7.photosQueue     // Catch:{ InterruptedException -> 0x007f }
                    java.util.Stack r8 = r7.photosToLoad     // Catch:{ InterruptedException -> 0x007f }
                    monitor-enter(r8)     // Catch:{ InterruptedException -> 0x007f }
                    com.jkfantasy.photopoinokia.MainActivity$ImageLoader r7 = com.jkfantasy.photopoinokia.MainActivity.ImageLoader.this     // Catch:{ all -> 0x007c }
                    com.jkfantasy.photopoinokia.MainActivity$ImageLoader$PhotosQueue r7 = r7.photosQueue     // Catch:{ all -> 0x007c }
                    java.util.Stack r7 = r7.photosToLoad     // Catch:{ all -> 0x007c }
                    int r5 = r7.size()     // Catch:{ all -> 0x007c }
                    if (r5 != 0) goto L_0x006b
                    com.jkfantasy.photopoinokia.MainActivity$ImageLoader r7 = com.jkfantasy.photopoinokia.MainActivity.ImageLoader.this     // Catch:{ all -> 0x007c }
                    com.jkfantasy.photopoinokia.MainActivity$ImageLoader$PhotosQueue r7 = r7.photosQueue     // Catch:{ all -> 0x007c }
                    java.util.Stack r7 = r7.photosToLoad     // Catch:{ all -> 0x007c }
                    r7.wait()     // Catch:{ all -> 0x007c }
                L_0x0024:
                    monitor-exit(r8)     // Catch:{ all -> 0x007c }
                    if (r5 == 0) goto L_0x0064
                    com.jkfantasy.photopoinokia.MainActivity$ImageLoader r7 = com.jkfantasy.photopoinokia.MainActivity.ImageLoader.this     // Catch:{ InterruptedException -> 0x007f }
                    java.lang.String r8 = r4.url     // Catch:{ InterruptedException -> 0x007f }
                    android.graphics.Bitmap r3 = r7.getBitmap(r8)     // Catch:{ InterruptedException -> 0x007f }
                    com.jkfantasy.photopoinokia.MainActivity$ImageLoader r7 = com.jkfantasy.photopoinokia.MainActivity.ImageLoader.this     // Catch:{ InterruptedException -> 0x007f }
                    com.jkfantasy.photopoinokia.MainActivity$MemoryCache r7 = r7.memoryCache     // Catch:{ InterruptedException -> 0x007f }
                    java.lang.String r8 = r4.url     // Catch:{ InterruptedException -> 0x007f }
                    r7.put(r8, r3)     // Catch:{ InterruptedException -> 0x007f }
                    com.jkfantasy.photopoinokia.MainActivity$ImageLoader r7 = com.jkfantasy.photopoinokia.MainActivity.ImageLoader.this     // Catch:{ InterruptedException -> 0x007f }
                    java.util.Map r7 = r7.imageViews     // Catch:{ InterruptedException -> 0x007f }
                    android.widget.ImageView r8 = r4.imageView     // Catch:{ InterruptedException -> 0x007f }
                    java.lang.Object r6 = r7.get(r8)     // Catch:{ InterruptedException -> 0x007f }
                    java.lang.String r6 = (java.lang.String) r6     // Catch:{ InterruptedException -> 0x007f }
                    if (r6 == 0) goto L_0x0064
                    java.lang.String r7 = r4.url     // Catch:{ InterruptedException -> 0x007f }
                    boolean r7 = r6.equals(r7)     // Catch:{ InterruptedException -> 0x007f }
                    if (r7 == 0) goto L_0x0064
                    com.jkfantasy.photopoinokia.MainActivity$ImageLoader$BitmapDisplayer r2 = new com.jkfantasy.photopoinokia.MainActivity$ImageLoader$BitmapDisplayer     // Catch:{ InterruptedException -> 0x007f }
                    com.jkfantasy.photopoinokia.MainActivity$ImageLoader r7 = com.jkfantasy.photopoinokia.MainActivity.ImageLoader.this     // Catch:{ InterruptedException -> 0x007f }
                    android.widget.ImageView r8 = r4.imageView     // Catch:{ InterruptedException -> 0x007f }
                    r2.<init>(r3, r8)     // Catch:{ InterruptedException -> 0x007f }
                    android.widget.ImageView r7 = r4.imageView     // Catch:{ InterruptedException -> 0x007f }
                    android.content.Context r1 = r7.getContext()     // Catch:{ InterruptedException -> 0x007f }
                    android.app.Activity r1 = (android.app.Activity) r1     // Catch:{ InterruptedException -> 0x007f }
                    r1.runOnUiThread(r2)     // Catch:{ InterruptedException -> 0x007f }
                L_0x0064:
                    boolean r7 = java.lang.Thread.interrupted()     // Catch:{ InterruptedException -> 0x007f }
                    if (r7 == 0) goto L_0x0000
                L_0x006a:
                    return
                L_0x006b:
                    com.jkfantasy.photopoinokia.MainActivity$ImageLoader r7 = com.jkfantasy.photopoinokia.MainActivity.ImageLoader.this     // Catch:{ all -> 0x007c }
                    com.jkfantasy.photopoinokia.MainActivity$ImageLoader$PhotosQueue r7 = r7.photosQueue     // Catch:{ all -> 0x007c }
                    java.util.Stack r7 = r7.photosToLoad     // Catch:{ all -> 0x007c }
                    java.lang.Object r7 = r7.pop()     // Catch:{ all -> 0x007c }
                    r0 = r7
                    com.jkfantasy.photopoinokia.MainActivity$ImageLoader$PhotoToLoad r0 = (com.jkfantasy.photopoinokia.MainActivity.ImageLoader.PhotoToLoad) r0     // Catch:{ all -> 0x007c }
                    r4 = r0
                    goto L_0x0024
                L_0x007c:
                    r7 = move-exception
                    monitor-exit(r8)     // Catch:{ all -> 0x007c }
                    throw r7     // Catch:{ InterruptedException -> 0x007f }
                L_0x007f:
                    r7 = move-exception
                    goto L_0x006a
                */
                throw new UnsupportedOperationException("Method not decompiled: com.jkfantasy.photopoinokia.MainActivity.ImageLoader.PhotosLoader.run():void");
            }
        }

        class BitmapDisplayer implements Runnable {
            Bitmap bitmap;
            ImageView imageView;

            public BitmapDisplayer(Bitmap b, ImageView i) {
                this.bitmap = b;
                this.imageView = i;
            }

            public void run() {
                if (this.bitmap != null) {
                    this.imageView.setImageBitmap(this.bitmap);
                } else {
                    this.imageView.setImageResource(R.drawable.gray_16x16);
                }
            }
        }

        public void clearCache() {
            this.memoryCache.clear();
        }
    }

    class ImageAdapter extends BaseAdapter {
        private Activity activity;
        private Context context;
        public ImageLoader imageLoader;

        public ImageAdapter(Context context2, Activity a) {
            this.context = context2;
            this.activity = a;
            this.imageLoader = new ImageLoader(this.activity.getApplicationContext());
        }

        public int getCount() {
            return MainActivity.this.mainList.size();
        }

        public Object getItem(int position) {
            return Integer.valueOf(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        /* JADX WARNING: Removed duplicated region for block: B:17:0x02fc  */
        /* JADX WARNING: Removed duplicated region for block: B:20:0x0327  */
        /* JADX WARNING: Removed duplicated region for block: B:23:0x0344  */
        /* JADX WARNING: Removed duplicated region for block: B:39:0x03f5  */
        /* JADX WARNING: Removed duplicated region for block: B:41:0x042d  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public android.view.View getView(int r25, android.view.View r26, android.view.ViewGroup r27) {
            /*
                r24 = this;
                if (r26 != 0) goto L_0x0394
                android.widget.FrameLayout r11 = new android.widget.FrameLayout
                r0 = r24
                android.content.Context r0 = r0.context
                r20 = r0
                r0 = r20
                r11.<init>(r0)
                android.widget.AbsListView$LayoutParams r10 = new android.widget.AbsListView$LayoutParams
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r20 = r0
                r0 = r20
                int r0 = r0.iv_width
                r20 = r0
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r21 = r0
                r0 = r21
                int r0 = r0.ic_width
                r21 = r0
                int r20 = r20 + r21
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r21 = r0
                r0 = r21
                int r0 = r0.iv_width
                r21 = r0
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r22 = r0
                r0 = r22
                int r0 = r0.ic_width
                r22 = r0
                int r21 = r21 + r22
                r0 = r20
                r1 = r21
                r10.<init>(r0, r1)
                r11.setLayoutParams(r10)
                android.widget.ImageView r4 = new android.widget.ImageView
                r0 = r24
                android.content.Context r0 = r0.context
                r20 = r0
                r0 = r20
                r4.<init>(r0)
                android.widget.FrameLayout$LayoutParams r5 = new android.widget.FrameLayout$LayoutParams
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r20 = r0
                r0 = r20
                int r0 = r0.ic_width
                r20 = r0
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r21 = r0
                r0 = r21
                int r0 = r0.ic_width
                r21 = r0
                r0 = r20
                r1 = r21
                r5.<init>(r0, r1)
                r20 = 0
                r0 = r20
                r5.leftMargin = r0
                r20 = 0
                r0 = r20
                r5.topMargin = r0
                r20 = 48
                r0 = r20
                r5.gravity = r0
                r4.setLayoutParams(r5)
                android.widget.ImageView r12 = new android.widget.ImageView
                r0 = r24
                android.content.Context r0 = r0.context
                r20 = r0
                r0 = r20
                r12.<init>(r0)
                android.widget.FrameLayout$LayoutParams r13 = new android.widget.FrameLayout$LayoutParams
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r20 = r0
                r0 = r20
                int r0 = r0.ic_width
                r20 = r0
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r21 = r0
                r0 = r21
                int r0 = r0.ic_width
                r21 = r0
                r0 = r20
                r1 = r21
                r13.<init>(r0, r1)
                r20 = 0
                r0 = r20
                r13.leftMargin = r0
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r20 = r0
                r0 = r20
                int r0 = r0.ic_width
                r20 = r0
                r0 = r20
                r13.topMargin = r0
                r20 = 48
                r0 = r20
                r13.gravity = r0
                r12.setLayoutParams(r13)
                android.widget.ImageView r14 = new android.widget.ImageView
                r0 = r24
                android.content.Context r0 = r0.context
                r20 = r0
                r0 = r20
                r14.<init>(r0)
                android.widget.FrameLayout$LayoutParams r15 = new android.widget.FrameLayout$LayoutParams
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r20 = r0
                r0 = r20
                int r0 = r0.iv_width
                r20 = r0
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r21 = r0
                r0 = r21
                int r0 = r0.iv_width
                r21 = r0
                r0 = r20
                r1 = r21
                r15.<init>(r0, r1)
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r20 = r0
                r0 = r20
                int r0 = r0.ic_width
                r20 = r0
                r0 = r20
                r15.leftMargin = r0
                r20 = 0
                r0 = r20
                r15.topMargin = r0
                r20 = 5
                r0 = r20
                r15.gravity = r0
                r14.setLayoutParams(r15)
                android.widget.ImageView$ScaleType r20 = android.widget.ImageView.ScaleType.CENTER_CROP
                r0 = r20
                r14.setScaleType(r0)
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r20 = r0
                r0 = r20
                int r0 = r0.iv_padding
                r20 = r0
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r21 = r0
                r0 = r21
                int r0 = r0.iv_padding
                r21 = r0
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r22 = r0
                r0 = r22
                int r0 = r0.iv_padding
                r22 = r0
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r23 = r0
                r0 = r23
                int r0 = r0.iv_padding
                r23 = r0
                r0 = r20
                r1 = r21
                r2 = r22
                r3 = r23
                r14.setPadding(r0, r1, r2, r3)
                android.widget.TextView r9 = new android.widget.TextView
                r0 = r24
                android.content.Context r0 = r0.context
                r20 = r0
                r0 = r20
                r9.<init>(r0)
                android.widget.FrameLayout$LayoutParams r18 = new android.widget.FrameLayout$LayoutParams
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r20 = r0
                r0 = r20
                int r0 = r0.iv_width
                r20 = r0
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r21 = r0
                r0 = r21
                int r0 = r0.ic_width
                r21 = r0
                r0 = r18
                r1 = r20
                r2 = r21
                r0.<init>(r1, r2)
                r20 = 0
                r0 = r20
                r1 = r18
                r1.rightMargin = r0
                r20 = 0
                r0 = r20
                r1 = r18
                r1.bottomMargin = r0
                r20 = 85
                r0 = r20
                r1 = r18
                r1.gravity = r0
                r0 = r18
                r9.setLayoutParams(r0)
                r20 = 1094713344(0x41400000, float:12.0)
                r0 = r20
                r9.setTextSize(r0)
                r20 = 1
                r0 = r20
                r9.setSingleLine(r0)
                android.text.TextUtils$TruncateAt r20 = android.text.TextUtils.TruncateAt.END
                r0 = r20
                r9.setEllipsize(r0)
                r20 = -256(0xffffffffffffff00, float:NaN)
                r0 = r20
                r9.setTextColor(r0)
                android.widget.ImageView r16 = new android.widget.ImageView
                r0 = r24
                android.content.Context r0 = r0.context
                r20 = r0
                r0 = r16
                r1 = r20
                r0.<init>(r1)
                android.widget.FrameLayout$LayoutParams r17 = new android.widget.FrameLayout$LayoutParams
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r20 = r0
                r0 = r20
                int r0 = r0.ic_width
                r20 = r0
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r21 = r0
                r0 = r21
                int r0 = r0.ic_width
                r21 = r0
                r0 = r17
                r1 = r20
                r2 = r21
                r0.<init>(r1, r2)
                r20 = 0
                r0 = r20
                r1 = r17
                r1.rightMargin = r0
                r20 = 0
                r0 = r20
                r1 = r17
                r1.topMargin = r0
                r20 = 53
                r0 = r20
                r1 = r17
                r1.gravity = r0
                r16.setLayoutParams(r17)
                r11.addView(r4)
                r11.addView(r12)
                r11.addView(r14)
                r11.addView(r9)
                r0 = r16
                r11.addView(r0)
                com.jkfantasy.photopoinokia.MainActivity$ViewHolder r19 = new com.jkfantasy.photopoinokia.MainActivity$ViewHolder
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r20 = r0
                r19.<init>()
                r0 = r19
                r0.gpsIcon = r12
                r0 = r19
                r0.cameraIcon = r4
                r0 = r19
                r0.imageView = r14
                r0 = r19
                r0.filenameView = r9
                r0 = r16
                r1 = r19
                r1.selectIcon = r0
                r26 = r11
                r0 = r26
                r1 = r19
                r0.setTag(r1)
            L_0x025f:
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r20 = r0
                r0 = r20
                int r0 = r0.m_curFilePosition
                r20 = r0
                r0 = r25
                r1 = r20
                if (r0 != r1) goto L_0x03b8
                r0 = r19
                android.widget.ImageView r0 = r0.imageView
                r20 = r0
                r21 = -1
                r20.setBackgroundColor(r21)
                if (r25 != 0) goto L_0x039c
                int r20 = r27.getChildCount()
                r0 = r20
                r1 = r25
                if (r0 != r1) goto L_0x02a2
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r20 = r0
                r21 = 0
                r0 = r21
                r1 = r20
                r1.m_curFileViewHolder = r0
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r20 = r0
                r0 = r19
                r1 = r20
                r1.m_curFileViewHolder = r0
            L_0x02a2:
                android.media.ExifInterface r7 = new android.media.ExifInterface     // Catch:{ IOException -> 0x03e2 }
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this     // Catch:{ IOException -> 0x03e2 }
                r20 = r0
                r0 = r20
                java.util.ArrayList<java.util.HashMap<java.lang.String, java.lang.String>> r0 = r0.mainList     // Catch:{ IOException -> 0x03e2 }
                r20 = r0
                r0 = r20
                r1 = r25
                java.lang.Object r20 = r0.get(r1)     // Catch:{ IOException -> 0x03e2 }
                java.util.HashMap r20 = (java.util.HashMap) r20     // Catch:{ IOException -> 0x03e2 }
                java.lang.String r21 = "data"
                java.lang.Object r20 = r20.get(r21)     // Catch:{ IOException -> 0x03e2 }
                java.lang.String r20 = (java.lang.String) r20     // Catch:{ IOException -> 0x03e2 }
                r0 = r20
                r7.<init>(r0)     // Catch:{ IOException -> 0x03e2 }
                if (r7 == 0) goto L_0x03e8
                java.lang.String r20 = "Make"
                r0 = r20
                java.lang.String r20 = r7.getAttribute(r0)     // Catch:{ IOException -> 0x03e2 }
                if (r20 != 0) goto L_0x03c6
                r0 = r19
                android.widget.ImageView r0 = r0.cameraIcon     // Catch:{ IOException -> 0x03e2 }
                r20 = r0
                r21 = 0
                r20.setBackgroundColor(r21)     // Catch:{ IOException -> 0x03e2 }
            L_0x02de:
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r20 = r0
                r0 = r20
                java.util.ArrayList<java.util.HashMap<java.lang.String, java.lang.String>> r0 = r0.mainList
                r20 = r0
                r0 = r20
                r1 = r25
                java.lang.Object r20 = r0.get(r1)
                java.util.HashMap r20 = (java.util.HashMap) r20
                java.lang.String r21 = "latitude"
                java.lang.Object r20 = r20.get(r21)
                if (r20 != 0) goto L_0x03f5
                r0 = r19
                android.widget.ImageView r0 = r0.gpsIcon
                r20 = r0
                r21 = 0
                r20.setBackgroundColor(r21)
            L_0x0307:
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r20 = r0
                r0 = r20
                java.util.ArrayList<java.util.HashMap<java.lang.String, java.lang.String>> r0 = r0.mainList
                r20 = r0
                r0 = r20
                r1 = r25
                java.lang.Object r20 = r0.get(r1)
                java.util.HashMap r20 = (java.util.HashMap) r20
                java.lang.String r21 = "display_name"
                java.lang.Object r8 = r20.get(r21)
                java.lang.String r8 = (java.lang.String) r8
                if (r8 == 0) goto L_0x0332
                r0 = r19
                android.widget.TextView r0 = r0.filenameView
                r20 = r0
                r0 = r20
                r0.setText(r8)
            L_0x0332:
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r20 = r0
                r0 = r20
                java.lang.Boolean r0 = r0.isFileSelectModeEnabled
                r20 = r0
                boolean r20 = r20.booleanValue()
                if (r20 == 0) goto L_0x042d
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r20 = r0
                r0 = r20
                java.util.List<java.lang.String> r0 = r0.imageList_forSel
                r20 = r0
                r0 = r20
                r1 = r25
                java.lang.Object r20 = r0.get(r1)
                java.lang.String r21 = "0"
                r0 = r20
                r1 = r21
                if (r0 == r1) goto L_0x0411
                r0 = r19
                android.widget.ImageView r0 = r0.selectIcon
                r20 = r0
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r21 = r0
                android.content.res.Resources r21 = r21.getResources()
                r22 = 2130837526(0x7f020016, float:1.7280009E38)
                android.graphics.drawable.Drawable r21 = r21.getDrawable(r22)
                r20.setBackgroundDrawable(r21)
            L_0x037a:
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity$ImageLoader r0 = r0.imageLoader
                r20 = r0
                java.lang.String r21 = java.lang.String.valueOf(r25)
                r0 = r24
                android.app.Activity r0 = r0.activity
                r22 = r0
                r0 = r19
                android.widget.ImageView r0 = r0.imageView
                r23 = r0
                r20.DisplayImage(r21, r22, r23)
                return r26
            L_0x0394:
                java.lang.Object r19 = r26.getTag()
                com.jkfantasy.photopoinokia.MainActivity$ViewHolder r19 = (com.jkfantasy.photopoinokia.MainActivity.ViewHolder) r19
                goto L_0x025f
            L_0x039c:
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r20 = r0
                r21 = 0
                r0 = r21
                r1 = r20
                r1.m_curFileViewHolder = r0
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r20 = r0
                r0 = r19
                r1 = r20
                r1.m_curFileViewHolder = r0
                goto L_0x02a2
            L_0x03b8:
                r0 = r19
                android.widget.ImageView r0 = r0.imageView
                r20 = r0
                r21 = -7829368(0xffffffffff888888, float:NaN)
                r20.setBackgroundColor(r21)
                goto L_0x02a2
            L_0x03c6:
                r0 = r19
                android.widget.ImageView r0 = r0.cameraIcon     // Catch:{ IOException -> 0x03e2 }
                r20 = r0
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this     // Catch:{ IOException -> 0x03e2 }
                r21 = r0
                android.content.res.Resources r21 = r21.getResources()     // Catch:{ IOException -> 0x03e2 }
                r22 = 2130837522(0x7f020012, float:1.728E38)
                android.graphics.drawable.Drawable r21 = r21.getDrawable(r22)     // Catch:{ IOException -> 0x03e2 }
                r20.setBackgroundDrawable(r21)     // Catch:{ IOException -> 0x03e2 }
                goto L_0x02de
            L_0x03e2:
                r6 = move-exception
                r6.printStackTrace()
                goto L_0x02de
            L_0x03e8:
                r0 = r19
                android.widget.ImageView r0 = r0.cameraIcon     // Catch:{ IOException -> 0x03e2 }
                r20 = r0
                r21 = 0
                r20.setBackgroundColor(r21)     // Catch:{ IOException -> 0x03e2 }
                goto L_0x02de
            L_0x03f5:
                r0 = r19
                android.widget.ImageView r0 = r0.gpsIcon
                r20 = r0
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r21 = r0
                android.content.res.Resources r21 = r21.getResources()
                r22 = 2130837570(0x7f020042, float:1.7280098E38)
                android.graphics.drawable.Drawable r21 = r21.getDrawable(r22)
                r20.setBackgroundDrawable(r21)
                goto L_0x0307
            L_0x0411:
                r0 = r19
                android.widget.ImageView r0 = r0.selectIcon
                r20 = r0
                r0 = r24
                com.jkfantasy.photopoinokia.MainActivity r0 = com.jkfantasy.photopoinokia.MainActivity.this
                r21 = r0
                android.content.res.Resources r21 = r21.getResources()
                r22 = 2130837525(0x7f020015, float:1.7280007E38)
                android.graphics.drawable.Drawable r21 = r21.getDrawable(r22)
                r20.setBackgroundDrawable(r21)
                goto L_0x037a
            L_0x042d:
                r0 = r19
                android.widget.ImageView r0 = r0.selectIcon
                r20 = r0
                r21 = 0
                r20.setBackgroundColor(r21)
                goto L_0x037a
            */
            throw new UnsupportedOperationException("Method not decompiled: com.jkfantasy.photopoinokia.MainActivity.ImageAdapter.getView(int, android.view.View, android.view.ViewGroup):android.view.View");
        }
    }

    public boolean layoutMain_switch_UpDownBtnOnTouch(View view, MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            case 0:
                if (this.m_viewMode != 1) {
                    this.btn_toolbar_switch_MainUpDown.setBackgroundDrawable(getResources().getDrawable(R.drawable.switch_button_up_press));
                    break;
                } else {
                    this.btn_toolbar_switch_MainUpDown.setBackgroundDrawable(getResources().getDrawable(R.drawable.switch_button_dn_press));
                    break;
                }
            case 1:
                if (this.m_viewMode == 1) {
                    this.m_viewMode = 0;
                } else {
                    this.m_viewMode = 1;
                }
                if (this.m_viewMode == 1) {
                    this.btn_toolbar_switch_MainUpDown.setBackgroundDrawable(getResources().getDrawable(R.drawable.switch_button_dn_normal));
                } else {
                    this.btn_toolbar_switch_MainUpDown.setBackgroundDrawable(getResources().getDrawable(R.drawable.switch_button_up_normal));
                }
                if (this.m_viewMode == 1) {
                    this.content0_container.setVisibility(4);
                    this.content1_container.setVisibility(4);
                } else {
                    this.content0_container.setVisibility(0);
                    this.content1_container.setVisibility(0);
                    content_x_uiUpdate_and_process();
                }
                FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) this.layout_main.getLayoutParams();
                params.width = this.mainLayout_width;
                if (this.m_viewMode == 1) {
                    params.height = this.mainLayout_height;
                    params.topMargin = 0;
                    params.bottomMargin = 0;
                    params.gravity = 80;
                } else {
                    params.height = this.dummyLayout_height;
                    params.topMargin = this.main_y_anim_shift;
                    params.bottomMargin = 0;
                    params.gravity = 80;
                }
                this.layout_main.setLayoutParams(params);
                break;
        }
        return false;
    }

    public boolean layoutMain_photo_filter(View view, MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            case 0:
                this.btn_toolbar_photo_filter_left.setBackgroundDrawable(getResources().getDrawable(R.drawable.photo_filter_left_press));
                this.btn_toolbar_photo_filter_middle.setBackgroundDrawable(getResources().getDrawable(R.drawable.photo_filter_middle_press));
                this.btn_toolbar_photo_filter_right.setBackgroundDrawable(getResources().getDrawable(R.drawable.photo_filter_right_press));
                return false;
            case 1:
                this.btn_toolbar_photo_filter_left.setBackgroundDrawable(getResources().getDrawable(R.drawable.photo_filter_left_normal));
                this.btn_toolbar_photo_filter_middle.setBackgroundDrawable(getResources().getDrawable(R.drawable.photo_filter_middle_normal));
                this.btn_toolbar_photo_filter_right.setBackgroundDrawable(getResources().getDrawable(R.drawable.photo_filter_right_normal));
                Intent intent = new Intent();
                intent.setClass(this, PhotoFilterPage.class);
                startActivityForResult(intent, 1);
                return false;
            default:
                return false;
        }
    }

    public boolean layoutMain_google_map(View view, MotionEvent motionEvent) {
        ExifInterface exif;
        switch (motionEvent.getAction()) {
            case 0:
                if (!this.m_isGoogleMapEnable.booleanValue()) {
                    return false;
                }
                this.btn_toolbar_google_map.setBackgroundDrawable(getResources().getDrawable(R.drawable.google_map_press));
                return false;
            case 1:
                if (this.m_isGoogleMapEnable.booleanValue()) {
                    this.btn_toolbar_google_map.setBackgroundDrawable(getResources().getDrawable(R.drawable.google_map_normal));
                }
                this.mLatInSelPhoto = 0.0d;
                this.mLonInSelPhoto = 0.0d;
                try {
                    if (this.m_curFileName == null || (exif = new ExifInterface(this.m_curFileName)) == null || exif.getAttribute("GPSLatitude") == null) {
                        return false;
                    }
                    GeoDegree gDegree = new GeoDegree(exif);
                    this.mLatInSelPhoto = (double) gDegree.Latitude.floatValue();
                    this.mLonInSelPhoto = (double) gDegree.Longitude.floatValue();
                    boolean useWebMAP = false;
                    boolean isAlreadyInstallMapApp = false;
                    if (this.which_map == WHICH_MAP.GOOGLE_MAP_ANDROID_V2) {
                        isAlreadyInstallMapApp = this.gIsInstalledGoogleMap;
                    } else if (this.which_map == WHICH_MAP.GOOGLE_MAP_JS_V3) {
                        isAlreadyInstallMapApp = this.gIsInstalledGoogleMap;
                    } else if (this.which_map == WHICH_MAP.BAIDU_MAP_ANDROID) {
                        isAlreadyInstallMapApp = this.gIsInstalledBaiduMap;
                    } else if (this.which_map == WHICH_MAP.AMAZON_MAP_ANDROID) {
                        isAlreadyInstallMapApp = this.gIsInstalledAmazonMap;
                    } else if (this.which_map == WHICH_MAP.NOKIA_MAP_JS) {
                        isAlreadyInstallMapApp = this.gIsInstalledNokiaMap;
                    }
                    if (!isAlreadyInstallMapApp) {
                        useWebMAP = true;
                    } else if (isIntentAvailable(this, "android.intent.action.VIEW")) {
                        if (!checkNetworkAvailable().booleanValue()) {
                            Toast.makeText(this, getString(R.string.NetworkNeedEnable), 1).show();
                        }
                        List<ResolveInfo> resolveInfos = getPackageManager().queryIntentActivities(new Intent("android.intent.action.VIEW", Uri.parse("geo:" + this.mLatInSelPhoto + "," + this.mLonInSelPhoto + "?q=" + this.mLatInSelPhoto + "," + this.mLonInSelPhoto + "(" + getString(R.string.POI) + ":" + getString(R.string.PhotoPosition) + ")")), 0);
                        boolean isIntentSafe = resolveInfos.size() > 0;
                        if (isIntentSafe) {
                            this.mapPkgItemAry.clear();
                            this.mbIsGeo_GoogleMapInclude = false;
                            this.mbIsGeo_GoogleEarthInclude = false;
                            this.mbIsGeo_OtherAppsInclude = false;
                            for (int i = 0; i < resolveInfos.size(); i++) {
                                String resolvePackageName = resolveInfos.get(i).activityInfo.packageName;
                                if (resolvePackageName.compareTo("com.google.android.apps.maps") == 0) {
                                    this.mbIsGeo_GoogleMapInclude = true;
                                    MapPkgItem mapPkgItem = new MapPkgItem();
                                    mapPkgItem.setPackageName(resolvePackageName);
                                    mapPkgItem.setAppName(getAppTitle(resolvePackageName));
                                    mapPkgItem.setClassName(getAppClassName(resolvePackageName));
                                    this.mapPkgItemAry.add(mapPkgItem);
                                } else if (resolvePackageName.compareTo("com.google.earth") == 0) {
                                    this.mbIsGeo_GoogleEarthInclude = true;
                                    MapPkgItem mapPkgItem2 = new MapPkgItem();
                                    mapPkgItem2.setPackageName(resolvePackageName);
                                    mapPkgItem2.setAppName(getAppTitle(resolvePackageName));
                                    mapPkgItem2.setClassName(getAppClassName(resolvePackageName));
                                    this.mapPkgItemAry.add(mapPkgItem2);
                                } else {
                                    this.mbIsGeo_OtherAppsInclude = true;
                                }
                            }
                        }
                        if (this.mbIsGeo_OtherAppsInclude) {
                            MapPkgItem mapPkgItem3 = new MapPkgItem();
                            mapPkgItem3.setPackageName("othermap.jkfantasy.com");
                            mapPkgItem3.setAppName("othermap.jkfantasy.com");
                            mapPkgItem3.setClassName("othermap.jkfantasy.com");
                            this.mapPkgItemAry.add(mapPkgItem3);
                        }
                        if (this.mbIsGeo_GoogleEarthInclude) {
                            writeKmlFileToSd("<?xml version=\"1.0\" encoding=\"UTF-8\"?><kml xmlns=\"http://earth.google.com/kml/2.0\"><Document><Placemark><name>" + getString(R.string.PhotoPosition) + "</name>" + "<Point>" + "<coordinates>" + this.mLonInSelPhoto + "," + this.mLatInSelPhoto + ",0</coordinates>" + "</Point>" + "</Placemark>" + "</Document>" + "</kml>");
                        }
                        if (!isIntentSafe) {
                            useWebMAP = true;
                        } else if (resolveInfos.size() == 1) {
                            if (this.mbIsGeo_GoogleMapInclude) {
                                startActivity(new Intent("android.intent.action.VIEW", Uri.parse("geo:" + this.mLatInSelPhoto + "," + this.mLonInSelPhoto + "?q=" + this.mLatInSelPhoto + "," + this.mLonInSelPhoto + "(" + getString(R.string.POI) + ":" + getString(R.string.PhotoPosition) + ")")));
                            } else if (this.mbIsGeo_GoogleEarthInclude) {
                                File file = new File(getKmlFileFullPathName());
                                Intent intent2 = new Intent("android.intent.action.VIEW");
                                intent2.setDataAndType(Uri.fromFile(file), "application/vnd.google-earth.kml+xml");
                                intent2.putExtra("com.google.earth.EXTRA.tour_feature_id", "my_track");
                                startActivity(intent2);
                            } else if (this.mbIsGeo_OtherAppsInclude) {
                                startActivity(new Intent("android.intent.action.VIEW", Uri.parse("geo:" + this.mLatInSelPhoto + "," + this.mLonInSelPhoto + "?q=" + this.mLatInSelPhoto + "," + this.mLonInSelPhoto + "(" + getString(R.string.POI) + ":" + getString(R.string.PhotoPosition) + ")")));
                            } else {
                                useWebMAP = true;
                            }
                        } else if (!this.mbIsGeo_GoogleEarthInclude) {
                            startActivity(new Intent("android.intent.action.VIEW", Uri.parse("geo:" + this.mLatInSelPhoto + "," + this.mLonInSelPhoto + "?q=" + this.mLatInSelPhoto + "," + this.mLonInSelPhoto + "(" + getString(R.string.POI) + ":" + getString(R.string.PhotoPosition) + ")")));
                        } else {
                            this.launchMapsDialog = new Dialog(this);
                            this.launchMapsDialog.setContentView(R.layout.launch_maps_dialog);
                            this.launchMapsDialog.setCancelable(true);
                            this.launchMapsDialog.setTitle(getString(R.string.title_launch_maps_dlg));
                            this.launchMapsListView = (ListView) this.launchMapsDialog.findViewById(R.id.launch_maps_lv);
                            this.launchMapsListAdapter = new LaunchMapsListAdapter(this, this);
                            this.launchMapsListView.setAdapter(this.launchMapsListAdapter);
                            this.launchMapsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                public void onItemClick(AdapterView<?> adapterView, View v, int position, long id) {
                                    LaunchMapsViewHolder launchMapsViewHolder = (LaunchMapsViewHolder) v.getTag();
                                    MapPkgItem mapPkgItem = MainActivity.this.mapPkgItemAry.get(position);
                                    String resolvePackageName = mapPkgItem.getPackageName();
                                    String resolveClassName = mapPkgItem.getClassName();
                                    Log.e("MainActivity", "packageName = " + resolvePackageName);
                                    Log.e("MainActivity", "className = " + resolveClassName);
                                    if (resolvePackageName.compareTo("com.google.android.apps.maps") == 0) {
                                        Intent intent2 = new Intent("android.intent.action.VIEW", Uri.parse("geo:" + MainActivity.this.mLatInSelPhoto + "," + MainActivity.this.mLonInSelPhoto + "?q=" + MainActivity.this.mLatInSelPhoto + "," + MainActivity.this.mLonInSelPhoto + "(" + MainActivity.this.getString(R.string.POI) + ":" + MainActivity.this.getString(R.string.PhotoPosition) + ")"));
                                        intent2.setClassName(resolvePackageName, resolveClassName);
                                        MainActivity.this.startActivity(intent2);
                                    } else if (resolvePackageName.compareTo("com.google.earth") == 0) {
                                        File file = new File(MainActivity.this.getKmlFileFullPathName());
                                        Intent intent22 = new Intent("android.intent.action.VIEW");
                                        intent22.setClassName(resolvePackageName, resolveClassName);
                                        intent22.setDataAndType(Uri.fromFile(file), "application/vnd.google-earth.kml+xml");
                                        intent22.putExtra("com.google.earth.EXTRA.tour_feature_id", "my_track");
                                        MainActivity.this.startActivity(intent22);
                                    } else {
                                        MainActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("geo:" + MainActivity.this.mLatInSelPhoto + "," + MainActivity.this.mLonInSelPhoto + "?q=" + MainActivity.this.mLatInSelPhoto + "," + MainActivity.this.mLonInSelPhoto + "(" + MainActivity.this.getString(R.string.POI) + ":" + MainActivity.this.getString(R.string.PhotoPosition) + ")")));
                                    }
                                    MainActivity.this.launchMapsDialog.dismiss();
                                }
                            });
                            this.launchMapsDialog.show();
                        }
                    } else {
                        useWebMAP = true;
                    }
                    if (!useWebMAP) {
                        return false;
                    }
                    String startmaps = null;
                    if (this.which_map == WHICH_MAP.GOOGLE_MAP_ANDROID_V2) {
                        startmaps = "http://maps.google.com/maps?ll=" + this.mLatInSelPhoto + "," + this.mLonInSelPhoto + "&z=" + String.valueOf((int) this.m_mapZoomLevel);
                    } else if (this.which_map == WHICH_MAP.GOOGLE_MAP_JS_V3) {
                        startmaps = "http://maps.google.com/maps?ll=" + this.mLatInSelPhoto + "," + this.mLonInSelPhoto + "&z=" + String.valueOf((int) this.m_mapZoomLevel);
                    } else if (this.which_map == WHICH_MAP.BAIDU_MAP_ANDROID) {
                        startmaps = "http://mo.baidu.com/map/easy.html";
                    } else if (this.which_map != WHICH_MAP.AMAZON_MAP_ANDROID) {
                        int i2 = WHICH_MAP.NOKIA_MAP_JS;
                    }
                    startActivity(new Intent("android.intent.action.VIEW", Uri.parse(startmaps)));
                    return false;
                } catch (IOException e) {
                    e.printStackTrace();
                    return false;
                }
            default:
                return false;
        }
    }

    public boolean layoutMain_camera_take_picture(View view, MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            case 0:
                this.btn_toolbar_camera_take_picture.setBackgroundDrawable(getResources().getDrawable(R.drawable.camera_take_picture_press));
                break;
            case 1:
                this.btn_toolbar_camera_take_picture.setBackgroundDrawable(getResources().getDrawable(R.drawable.camera_take_picture_normal));
                if (!isIntentAvailable(this, "android.media.action.IMAGE_CAPTURE")) {
                    Toast.makeText(this, "No Camera APP", 0).show();
                    break;
                } else {
                    startActivityForResult(new Intent("android.media.action.IMAGE_CAPTURE"), 3);
                    break;
                }
        }
        return false;
    }

    public boolean layoutMain_file_num(View view, MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            case 0:
                CharSequence[] colors = {getString(R.string.file_deselect_all), getString(R.string.file_select_all)};
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setCancelable(true).setNegativeButton(getString(R.string.Cancel), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
                builder.setItems(colors, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            for (int i = 0; i < MainActivity.this.mainList.size(); i++) {
                                MainActivity.this.imageList_forSel.set(i, "0");
                            }
                        } else if (which == 1) {
                            for (int i2 = 0; i2 < MainActivity.this.mainList.size(); i2++) {
                                Boolean bNotJpeg = true;
                                String displayName = (String) MainActivity.this.mainList.get(i2).get("display_name");
                                String lastExt = displayName.substring(displayName.lastIndexOf(46) + 1);
                                if (lastExt.equalsIgnoreCase("jpg") || lastExt.equalsIgnoreCase("jpeg")) {
                                    bNotJpeg = false;
                                }
                                if (bNotJpeg.booleanValue()) {
                                    MainActivity.this.imageList_forSel.set(i2, "-2");
                                } else {
                                    MainActivity.this.imageList_forSel.set(i2, "1");
                                }
                            }
                        }
                        if (which == 0 || which == 1) {
                            MainActivity.this.update_sub_menu_func1_button_ui();
                            MainActivity.this.adapter.notifyDataSetChanged();
                        }
                    }
                });
                builder.show();
                break;
        }
        return false;
    }

    public boolean layoutMain_share_file(View view, MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            case 0:
                this.btn_toolbar_share_file.setBackgroundDrawable(getResources().getDrawable(R.drawable.sharefile_button_press));
                return false;
            case 1:
                this.btn_toolbar_share_file.setBackgroundDrawable(getResources().getDrawable(R.drawable.sharefile_button_normal));
                sharePhotos();
                return false;
            default:
                return false;
        }
    }

    public boolean layoutMain_delete_file(View view, MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            case 0:
                this.btn_toolbar_delete_file.setBackgroundDrawable(getResources().getDrawable(R.drawable.delete_button_press));
                return false;
            case 1:
                this.btn_toolbar_delete_file.setBackgroundDrawable(getResources().getDrawable(R.drawable.delete_button_normal));
                deletePhotos();
                return false;
            default:
                return false;
        }
    }

    public boolean layoutMain_option_menu(View view, MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            case 0:
                this.btn_toolbar_option_menu.setBackgroundDrawable(getResources().getDrawable(R.drawable.optionmenu_button_press));
                return false;
            case 1:
                this.btn_toolbar_option_menu.setBackgroundDrawable(getResources().getDrawable(R.drawable.optionmenu_button_normal));
                openOptionsMenu();
                return false;
            default:
                return false;
        }
    }

    public boolean layoutMain_file_menu(View view, MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            case 0:
                this.btn_toolbar_file_menu.setBackgroundDrawable(getResources().getDrawable(R.drawable.filemenu_button_press));
                return false;
            case 1:
                this.btn_toolbar_file_menu.setBackgroundDrawable(getResources().getDrawable(R.drawable.filemenu_button_normal));
                openOptionsMenu();
                return false;
            default:
                return false;
        }
    }

    public boolean content0_normal_full_screen_switch(View view, MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            case 0:
                if (this.gIs_content0_full_screen.booleanValue()) {
                    this.btn_content0_normal_full_screen.setBackgroundDrawable(getResources().getDrawable(R.drawable.to_normal_screen_press));
                } else {
                    this.btn_content0_normal_full_screen.setBackgroundDrawable(getResources().getDrawable(R.drawable.to_full_screen_press));
                }
                this.btn_content0_normal_full_screen.getBackground().setAlpha(170);
                break;
            case 1:
                TouchImageView tiv = (TouchImageView) this.content0_viewPager.findViewWithTag(String.valueOf(this.m_curFilePosition));
                if (tiv != null) {
                    tiv.setTo1X();
                }
                if (this.content0_container.getHeight() == this.content1_height) {
                    this.gIs_content0_full_screen = true;
                    FrameLayout.LayoutParams params2 = (FrameLayout.LayoutParams) this.content0_container.getLayoutParams();
                    params2.width = this.displayMetrics.widthPixels;
                    params2.height = this.displayMetrics.heightPixels;
                    params2.topMargin = 0;
                    this.content0_container.setLayoutParams(params2);
                } else {
                    this.gIs_content0_full_screen = false;
                    FrameLayout.LayoutParams params22 = (FrameLayout.LayoutParams) this.content0_container.getLayoutParams();
                    params22.width = this.content1_width;
                    params22.height = this.content1_height;
                    params22.topMargin = this.content1_marginTop;
                    this.content0_container.setLayoutParams(params22);
                }
                if (this.gIs_content0_full_screen.booleanValue()) {
                    this.btn_content0_normal_full_screen.setBackgroundDrawable(getResources().getDrawable(R.drawable.to_normal_screen_normal));
                } else {
                    this.btn_content0_normal_full_screen.setBackgroundDrawable(getResources().getDrawable(R.drawable.to_full_screen_normal));
                }
                this.btn_content0_normal_full_screen.getBackground().setAlpha(170);
                break;
        }
        return false;
    }

    public void content1_normal_full_screen_swicth() {
        if (this.content1_container.getHeight() == this.content1_height) {
            this.gIs_content1_full_screen = true;
            FrameLayout.LayoutParams params2 = (FrameLayout.LayoutParams) this.content1_container.getLayoutParams();
            params2.width = this.displayMetrics.widthPixels;
            params2.height = this.displayMetrics.heightPixels;
            params2.topMargin = 0;
            this.content1_container.setLayoutParams(params2);
            if (!(this.which_map == WHICH_MAP.GOOGLE_MAP_ANDROID_V2 || this.which_map == WHICH_MAP.GOOGLE_MAP_JS_V3 || this.which_map == WHICH_MAP.BAIDU_MAP_ANDROID || this.which_map == WHICH_MAP.AMAZON_MAP_ANDROID || this.which_map != WHICH_MAP.NOKIA_MAP_JS)) {
                this.mapNokiaJavascript.setGotoFullScreenImage(false);
            }
        } else {
            this.gIs_content1_full_screen = false;
            FrameLayout.LayoutParams params22 = (FrameLayout.LayoutParams) this.content1_container.getLayoutParams();
            params22.width = this.content1_width;
            params22.height = this.content1_height;
            params22.topMargin = this.content1_marginTop;
            this.content1_container.setLayoutParams(params22);
            if (!(this.which_map == WHICH_MAP.GOOGLE_MAP_ANDROID_V2 || this.which_map == WHICH_MAP.GOOGLE_MAP_JS_V3 || this.which_map == WHICH_MAP.BAIDU_MAP_ANDROID || this.which_map == WHICH_MAP.AMAZON_MAP_ANDROID || this.which_map != WHICH_MAP.NOKIA_MAP_JS)) {
                this.mapNokiaJavascript.setGotoFullScreenImage(true);
            }
        }
        if (this.gIs_content1_full_screen.booleanValue()) {
            this.btn_content1_normal_full_screen.setBackgroundDrawable(getResources().getDrawable(R.drawable.to_normal_screen_normal));
        } else {
            this.btn_content1_normal_full_screen.setBackgroundDrawable(getResources().getDrawable(R.drawable.to_full_screen_normal));
        }
        this.btn_content1_normal_full_screen.getBackground().setAlpha(170);
    }

    public void content1_display_place_popup_window() {
        this.placeDialog = new Dialog(this);
        this.placeDialog.setContentView(R.layout.placelist_dialog);
        this.placeDialog.setCancelable(true);
        this.placeDialog.setTitle(getString(R.string.title_place_list_dlg));
        this.placeListView = (ListView) this.placeDialog.findViewById(R.id.place_lv);
        this.placeListAdapter = new PlaceListAdapter(this, this);
        this.placeListView.setAdapter(this.placeListAdapter);
        this.placeListView.setSelection(this.m_mapPlaceCmpIndex);
        this.placeListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View v, int position, long id) {
                ((PlaceViewHolder) v.getTag()).ll_root.setBackgroundDrawable(MainActivity.this.getResources().getDrawable(R.drawable.ll_place_item_select));
                if (!(MainActivity.this.which_map == WHICH_MAP.GOOGLE_MAP_ANDROID_V2 || MainActivity.this.which_map == WHICH_MAP.GOOGLE_MAP_JS_V3 || MainActivity.this.which_map == WHICH_MAP.BAIDU_MAP_ANDROID || MainActivity.this.which_map == WHICH_MAP.AMAZON_MAP_ANDROID || MainActivity.this.which_map != WHICH_MAP.NOKIA_MAP_JS)) {
                    MainActivity.this.mapNokiaJavascript.setPlacePosition(position);
                }
                MainActivity.this.placeDialog.dismiss();
            }
        });
        this.placeDialog.show();
    }

    private class PlaceViewHolder {
        LinearLayout ll_root;
        TextView tv_addr;
        TextView tv_name;

        private PlaceViewHolder() {
        }

        /* synthetic */ PlaceViewHolder(MainActivity mainActivity, PlaceViewHolder placeViewHolder) {
            this();
        }
    }

    private class PlaceListAdapter extends BaseAdapter {
        private Activity activity;
        private LayoutInflater layoutInflater;

        public PlaceListAdapter(Context context, Activity a) {
            this.activity = a;
            this.layoutInflater = (LayoutInflater) context.getSystemService("layout_inflater");
        }

        public int getCount() {
            if (MainActivity.this.which_map == WHICH_MAP.GOOGLE_MAP_ANDROID_V2 || MainActivity.this.which_map == WHICH_MAP.GOOGLE_MAP_JS_V3 || MainActivity.this.which_map == WHICH_MAP.BAIDU_MAP_ANDROID || MainActivity.this.which_map == WHICH_MAP.AMAZON_MAP_ANDROID || MainActivity.this.which_map != WHICH_MAP.NOKIA_MAP_JS) {
                return 0;
            }
            return MainActivity.this.mapNokiaJavascript.mPlaceList.size();
        }

        public Object getItem(int position) {
            return Integer.valueOf(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            PlaceViewHolder viewHolder;
            if (convertView == null) {
                convertView = this.layoutInflater.inflate(R.layout.placelist_lv_item, (ViewGroup) null);
                viewHolder = new PlaceViewHolder(MainActivity.this, (PlaceViewHolder) null);
                viewHolder.ll_root = (LinearLayout) convertView.findViewById(R.id.ll_root);
                viewHolder.tv_name = (TextView) convertView.findViewById(R.id.place_item_name);
                viewHolder.tv_addr = (TextView) convertView.findViewById(R.id.place_item_addr);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (PlaceViewHolder) convertView.getTag();
            }
            if (!(MainActivity.this.which_map == WHICH_MAP.GOOGLE_MAP_ANDROID_V2 || MainActivity.this.which_map == WHICH_MAP.GOOGLE_MAP_JS_V3 || MainActivity.this.which_map == WHICH_MAP.BAIDU_MAP_ANDROID || MainActivity.this.which_map == WHICH_MAP.AMAZON_MAP_ANDROID || MainActivity.this.which_map != WHICH_MAP.NOKIA_MAP_JS)) {
                viewHolder.tv_name.setText((CharSequence) MainActivity.this.mapNokiaJavascript.mPlaceList.get(position).get("name"));
                viewHolder.tv_addr.setText((CharSequence) MainActivity.this.mapNokiaJavascript.mPlaceList.get(position).get("addr"));
            }
            if (position == MainActivity.this.m_mapPlaceCmpIndex) {
                viewHolder.ll_root.setBackgroundDrawable(MainActivity.this.getResources().getDrawable(R.drawable.ll_place_item_select));
            } else {
                viewHolder.ll_root.setBackgroundDrawable(MainActivity.this.getResources().getDrawable(R.drawable.ll_place_item_not_select));
            }
            return convertView;
        }
    }

    public void content1_onResetMap() {
        if (this.which_map != WHICH_MAP.GOOGLE_MAP_ANDROID_V2 && this.which_map != WHICH_MAP.GOOGLE_MAP_JS_V3 && this.which_map != WHICH_MAP.BAIDU_MAP_ANDROID && this.which_map != WHICH_MAP.AMAZON_MAP_ANDROID && this.which_map == WHICH_MAP.NOKIA_MAP_JS) {
            this.mapNokiaJavascript.onResetMap();
        }
    }

    public boolean content1_normal_full_screen_switch(View view, MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            case 0:
                if (this.gIs_content1_full_screen.booleanValue()) {
                    this.btn_content1_normal_full_screen.setBackgroundDrawable(getResources().getDrawable(R.drawable.to_normal_screen_press));
                } else {
                    this.btn_content1_normal_full_screen.setBackgroundDrawable(getResources().getDrawable(R.drawable.to_full_screen_press));
                }
                this.btn_content1_normal_full_screen.getBackground().setAlpha(170);
                return false;
            case 1:
                content1_normal_full_screen_swicth();
                return false;
            default:
                return false;
        }
    }

    public boolean content1_edit_poi(View view, MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            case 0:
                this.content1_ll_edit_poi.setBackgroundDrawable(getResources().getDrawable(R.drawable.edit_poi_bg_press));
                return false;
            case 1:
                this.content1_ll_edit_poi.setBackgroundDrawable(getResources().getDrawable(R.drawable.edit_poi_bg_normal));
                editPoiPhoto_curSel();
                return false;
            default:
                return false;
        }
    }

    public void sharePhotos() {
        Intent intent = new Intent();
        intent.setAction("android.intent.action.SEND_MULTIPLE");
        intent.putExtra("android.intent.extra.SUBJECT", "Here are some files.");
        intent.setType("image/jpeg");
        ArrayList<Uri> files = new ArrayList<>();
        if (!this.isFileSelectModeEnabled.booleanValue()) {
            files.add(Uri.fromFile(new File((String) this.mainList.get(this.m_curFilePosition).get("data"))));
            intent.putParcelableArrayListExtra("android.intent.extra.STREAM", files);
            startActivity(intent);
            return;
        }
        int max_selected_file_count = 0;
        for (int i = 0; i < this.mainList.size(); i++) {
            if (this.imageList_forSel.get(i) != "0") {
                max_selected_file_count++;
            }
        }
        if (max_selected_file_count > 20) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(getString(R.string.SharePhotoExceedMaxFilesNuma)).setCancelable(false).setNegativeButton(getString(R.string.EditPoiOK), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.cancel();
                }
            });
            builder.create().show();
            return;
        }
        for (int i2 = 0; i2 < this.mainList.size(); i2++) {
            if (this.imageList_forSel.get(i2) != "0") {
                files.add(Uri.fromFile(new File((String) this.mainList.get(i2).get("data"))));
            }
        }
        intent.putParcelableArrayListExtra("android.intent.extra.STREAM", files);
        startActivity(intent);
    }

    public void deletePhotos() {
        String message;
        int max_delete_file_count = 0;
        if (!this.isFileSelectModeEnabled.booleanValue()) {
            max_delete_file_count = 1;
        } else {
            for (int i = 0; i < this.mainList.size(); i++) {
                if (this.imageList_forSel.get(i) != "0") {
                    max_delete_file_count++;
                }
            }
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        if (max_delete_file_count == 1) {
            message = String.valueOf(getString(R.string.deletefile_prefix)) + " " + String.valueOf(max_delete_file_count) + " " + getString(R.string.deletefile_end1);
        } else {
            message = String.valueOf(getString(R.string.deletefile_prefix)) + " " + String.valueOf(max_delete_file_count) + " " + getString(R.string.deletefile_endN);
        }
        builder.setMessage(message).setCancelable(false).setPositiveButton(getString(R.string.YES), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                if (!MainActivity.this.isFileSelectModeEnabled.booleanValue()) {
                    if (new File((String) MainActivity.this.mainList.get(MainActivity.this.m_curFilePosition).get("data")).delete()) {
                        MainActivity.this.getContentResolver().delete(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "_id=" + ((String) MainActivity.this.mainList.get(MainActivity.this.m_curFilePosition).get("id")), (String[]) null);
                    }
                    MainActivity.this.general_refresh_view_func();
                    return;
                }
                MainActivity.this.asyncTaskToDeletePhotos();
            }
        }).setNegativeButton(getString(R.string.NO), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }
        });
        builder.create().show();
    }

    public void renamePhoto() {
        String selectFullname;
        if (!this.isFileSelectModeEnabled.booleanValue()) {
            selectFullname = (String) this.mainList.get(this.m_curFilePosition).get("data");
        } else {
            int position = 0;
            int i = 0;
            while (true) {
                if (i >= this.mainList.size()) {
                    break;
                } else if (this.imageList_forSel.get(i) != "0") {
                    position = i;
                    break;
                } else {
                    i++;
                }
            }
            selectFullname = (String) this.mainList.get(position).get("data");
        }
        int lastSlashPos = selectFullname.lastIndexOf(47);
        int lastDotPos = selectFullname.lastIndexOf(46);
        this.renamePathOnly = selectFullname.substring(0, lastSlashPos);
        this.renameNameOnly = selectFullname.substring(lastSlashPos + 1, lastDotPos);
        this.renameExtOnly = selectFullname.substring(lastDotPos + 1);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.photo_rename));
        final EditText editText = new EditText(this);
        editText.setText(this.renameNameOnly);
        builder.setView(editText);
        int filenameMaxLength = (((259 - this.renamePathOnly.length()) - 1) - 1) - this.renameExtOnly.length();
        if (filenameMaxLength < 1) {
            filenameMaxLength = 1;
        }
        if (filenameMaxLength > 255) {
            filenameMaxLength = MotionEventCompat.ACTION_MASK;
        }
        editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(filenameMaxLength), new InputFilter() {
            public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
                if (end > start) {
                    char[] acceptedChars = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '$', '\'', '-', '_', '@', '~', '`', '!', '(', ')', '{', '}', '^', '#', '&', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '+', ',', ';', '=', '[', ']'};
                    int index = start;
                    while (index < end) {
                        if (String.valueOf(source.charAt(index)).getBytes().length != 1 || new String(acceptedChars).contains(String.valueOf(source.charAt(index)))) {
                            index++;
                        } else {
                            Toast.makeText(MainActivity.this, MainActivity.this.getString(R.string.invalid_character), 0).show();
                            return "";
                        }
                    }
                }
                return null;
            }
        }});
        editText.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) {
                String editStr = s.toString();
                if (editStr.length() == 0 || editStr.compareToIgnoreCase(MainActivity.this.renameNameOnly) == 0) {
                    MainActivity.this.renameDialog.getButton(-1).setEnabled(false);
                } else {
                    MainActivity.this.renameDialog.getButton(-1).setEnabled(true);
                }
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
        });
        builder.setPositiveButton(getString(R.string.Confirm), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                String toNameOnly = editText.getText().toString();
                String toFullname = String.valueOf(MainActivity.this.renamePathOnly) + "/" + toNameOnly + "." + MainActivity.this.renameExtOnly;
                if (Boolean.valueOf(new File(String.valueOf(MainActivity.this.renamePathOnly) + "/" + MainActivity.this.renameNameOnly + "." + MainActivity.this.renameExtOnly).renameTo(new File(toFullname))).booleanValue()) {
                    ContentValues values = new ContentValues();
                    values.put("_data", toFullname);
                    values.put("_display_name", String.valueOf(toNameOnly) + "." + MainActivity.this.renameExtOnly);
                    if (!MainActivity.this.isFileSelectModeEnabled.booleanValue()) {
                        MainActivity.this.getContentResolver().update(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values, "_id=" + ((String) MainActivity.this.mainList.get(MainActivity.this.m_curFilePosition).get("id")), (String[]) null);
                    } else {
                        int position = 0;
                        int i = 0;
                        while (true) {
                            if (i >= MainActivity.this.mainList.size()) {
                                break;
                            } else if (MainActivity.this.imageList_forSel.get(i) != "0") {
                                position = i;
                                break;
                            } else {
                                i++;
                            }
                        }
                        MainActivity.this.getContentResolver().update(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values, "_id=" + ((String) MainActivity.this.mainList.get(position).get("id")), (String[]) null);
                    }
                    MainActivity.this.m_curFileName = toFullname;
                }
                MainActivity.this.general_refresh_view_func();
            }
        });
        builder.setNegativeButton(getString(R.string.Cancel), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
            }
        });
        this.renameDialog = builder.create();
        this.renameDialog.show();
        this.renameDialog.getButton(-1).setEnabled(false);
    }

    public void editPoiPhoto_curSel() {
        MyApplication app = (MyApplication) getApplication();
        app.editPoiList.clear();
        HashMap<String, String> hash = new HashMap<>();
        hash.put("id", (String) this.mainList.get(this.m_curFilePosition).get("id"));
        hash.put("data", (String) this.mainList.get(this.m_curFilePosition).get("data"));
        hash.put("display_name", (String) this.mainList.get(this.m_curFilePosition).get("display_name"));
        hash.put("date_modified", (String) this.mainList.get(this.m_curFilePosition).get("date_modified"));
        hash.put("latitude", (String) this.mainList.get(this.m_curFilePosition).get("latitude"));
        hash.put("orientation", new StringBuilder(String.valueOf((String) this.mainList.get(this.m_curFilePosition).get("orientation"))).toString());
        app.editPoiList.add(hash);
        Intent intent = new Intent();
        intent.setClass(this, EditPoiPage.class);
        startActivity(intent);
    }

    public void editPoiPhotos() {
        MyApplication app = (MyApplication) getApplication();
        app.editPoiList.clear();
        int max_selected_file_count = 0;
        for (int i = 0; i < this.mainList.size(); i++) {
            if (this.imageList_forSel.get(i) != "0") {
                max_selected_file_count++;
            }
        }
        if (max_selected_file_count > 20) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(getString(R.string.EditPoiExceedMaxFilesNuma)).setCancelable(false).setNegativeButton(getString(R.string.EditPoiOK), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.cancel();
                }
            });
            builder.create().show();
            return;
        }
        for (int i2 = 0; i2 < this.mainList.size(); i2++) {
            if (this.imageList_forSel.get(i2) != "0") {
                HashMap<String, String> hash = new HashMap<>();
                hash.put("id", (String) this.mainList.get(i2).get("id"));
                hash.put("data", (String) this.mainList.get(i2).get("data"));
                hash.put("display_name", (String) this.mainList.get(i2).get("display_name"));
                hash.put("date_modified", (String) this.mainList.get(i2).get("date_modified"));
                hash.put("latitude", (String) this.mainList.get(i2).get("latitude"));
                hash.put("orientation", new StringBuilder(String.valueOf((String) this.mainList.get(i2).get("orientation"))).toString());
                app.editPoiList.add(hash);
            }
        }
        Intent intent = new Intent();
        intent.setClass(this, EditPoiPage.class);
        startActivity(intent);
    }

    @SuppressLint({"NewApi"})
    public void rotateLeftPhotos() {
        String degreeStr;
        if (!this.isFileSelectModeEnabled.booleanValue()) {
            try {
                ExifInterface exif = new ExifInterface((String) this.mainList.get(this.m_curFilePosition).get("data"));
                String tagNextOrient = getLeftOrientationNumber(exif.getAttribute("Orientation"));
                exif.setAttribute("Orientation", tagNextOrient);
                exif.saveAttributes();
                if (Integer.valueOf(tagNextOrient).intValue() == 1) {
                    degreeStr = "0";
                } else if (Integer.valueOf(tagNextOrient).intValue() == 6) {
                    degreeStr = "90";
                } else if (Integer.valueOf(tagNextOrient).intValue() == 3) {
                    degreeStr = "180";
                } else if (Integer.valueOf(tagNextOrient).intValue() == 8) {
                    degreeStr = "270";
                } else {
                    degreeStr = "0";
                }
                ContentValues values = new ContentValues();
                values.put("orientation", degreeStr);
                getContentResolver().update(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values, "_id=" + ((String) this.mainList.get(this.m_curFilePosition).get("id")), (String[]) null);
            } catch (IOException e) {
                e.printStackTrace();
            }
            general_refresh_view_func();
            return;
        }
        asyncTaskToRotateLeftPhotos();
    }

    @SuppressLint({"NewApi"})
    public void rotateRightPhotos() {
        String degreeStr;
        if (!this.isFileSelectModeEnabled.booleanValue()) {
            try {
                ExifInterface exif = new ExifInterface((String) this.mainList.get(this.m_curFilePosition).get("data"));
                String tagNextOrient = getRightOrientationNumber(exif.getAttribute("Orientation"));
                exif.setAttribute("Orientation", tagNextOrient);
                exif.saveAttributes();
                if (Integer.valueOf(tagNextOrient).intValue() == 1) {
                    degreeStr = "0";
                } else if (Integer.valueOf(tagNextOrient).intValue() == 6) {
                    degreeStr = "90";
                } else if (Integer.valueOf(tagNextOrient).intValue() == 3) {
                    degreeStr = "180";
                } else if (Integer.valueOf(tagNextOrient).intValue() == 8) {
                    degreeStr = "270";
                } else {
                    degreeStr = "0";
                }
                ContentValues values = new ContentValues();
                values.put("orientation", degreeStr);
                getContentResolver().update(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values, "_id=" + ((String) this.mainList.get(this.m_curFilePosition).get("id")), (String[]) null);
            } catch (IOException e) {
                e.printStackTrace();
            }
            general_refresh_view_func();
            return;
        }
        asyncTaskToRotateRightPhotos();
    }

    @SuppressLint({"NewApi"})
    public void asyncTaskToDeletePhotos() {
        this.isAsyncTaskDialogOn = true;
        this.isAsyncTaskDirtyWork = true;
        PhotoProcessAsyncTask fileProcessAyncTask = new PhotoProcessAsyncTask();
        fileProcessAyncTask.setMainActivity(this);
        fileProcessAyncTask.setProcessMode(0);
        if (Build.VERSION.SDK_INT >= 11) {
            fileProcessAyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
        } else {
            fileProcessAyncTask.execute(new Void[0]);
        }
    }

    public void sortPhotos() {
        this.sortDialog = new Dialog(this);
        this.sortDialog.requestWindowFeature(1);
        this.sortDialog.setContentView(R.layout.sort_dialog);
        RadioGroup rg_sort_ascend_descend = (RadioGroup) this.sortDialog.findViewById(R.id.rg_sort_ascend_descend);
        RadioGroup rg_sort_name_date = (RadioGroup) this.sortDialog.findViewById(R.id.rg_sort_name_date);
        Button bt_sort_yes = (Button) this.sortDialog.findViewById(R.id.bt_sort_yes);
        Button bt_sort_no = (Button) this.sortDialog.findViewById(R.id.bt_sort_no);
        if (this.m_sortMode == 0) {
            rg_sort_ascend_descend.check(R.id.rb_descend);
        } else if (this.m_sortMode == 1) {
            rg_sort_ascend_descend.check(R.id.rb_ascend);
        } else {
            this.m_sortMode = 0;
            rg_sort_ascend_descend.check(R.id.rb_descend);
        }
        if (this.m_sortBy == 0) {
            rg_sort_name_date.check(R.id.rb_add_time);
        } else if (this.m_sortBy == 1) {
            rg_sort_name_date.check(R.id.rb_modified_time);
        } else if (this.m_sortBy == 2) {
            rg_sort_name_date.check(R.id.rb_display_file_name);
        } else if (this.m_sortBy == 3) {
            rg_sort_name_date.check(R.id.rb_display_full_path_name);
        } else {
            this.m_sortBy = 0;
            rg_sort_name_date.check(R.id.rb_add_time);
        }
        rg_sort_ascend_descend.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.rb_descend) {
                    MainActivity.this.m_sortMode = 0;
                } else if (checkedId == R.id.rb_ascend) {
                    MainActivity.this.m_sortMode = 1;
                } else {
                    MainActivity.this.m_sortMode = 0;
                }
            }
        });
        rg_sort_name_date.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.rb_add_time) {
                    MainActivity.this.m_sortBy = 0;
                } else if (checkedId == R.id.rb_modified_time) {
                    MainActivity.this.m_sortBy = 1;
                } else if (checkedId == R.id.rb_display_file_name) {
                    MainActivity.this.m_sortBy = 2;
                } else if (checkedId == R.id.rb_display_full_path_name) {
                    MainActivity.this.m_sortBy = 3;
                } else {
                    MainActivity.this.m_sortBy = 0;
                }
            }
        });
        bt_sort_yes.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                MainActivity.this.general_refresh_view_func();
                MainActivity.this.sortDialog.dismiss();
            }
        });
        bt_sort_no.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                MainActivity.this.sortDialog.dismiss();
            }
        });
        this.sortDialog.setCancelable(true);
        this.sortDialog.setTitle(getString(R.string.sort_dialog_title));
        this.sortDialog.show();
    }

    public void setasPhoto() {
        String selectFullname;
        if (!this.isFileSelectModeEnabled.booleanValue()) {
            selectFullname = (String) this.mainList.get(this.m_curFilePosition).get("data");
        } else {
            int position = 0;
            int i = 0;
            while (true) {
                if (i >= this.mainList.size()) {
                    break;
                } else if (this.imageList_forSel.get(i) != "0") {
                    position = i;
                    break;
                } else {
                    i++;
                }
            }
            selectFullname = (String) this.mainList.get(position).get("data");
        }
        File file = new File(selectFullname);
        Uri uri = Uri.fromFile(file);
        try {
            URL url = file.toURL();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        Intent intent = new Intent("android.intent.action.ATTACH_DATA");
        intent.setDataAndType(uri, "image/*");
        intent.putExtra("mimeType", "image/*");
        startActivity(intent);
    }

    @SuppressLint({"NewApi"})
    public void asyncTaskToRotateLeftPhotos() {
        this.isAsyncTaskDialogOn = true;
        this.isAsyncTaskDirtyWork = true;
        PhotoProcessAsyncTask fileProcessAyncTask = new PhotoProcessAsyncTask();
        fileProcessAyncTask.setMainActivity(this);
        fileProcessAyncTask.setProcessMode(1);
        if (Build.VERSION.SDK_INT >= 11) {
            fileProcessAyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
        } else {
            fileProcessAyncTask.execute(new Void[0]);
        }
    }

    @SuppressLint({"NewApi"})
    public void asyncTaskToRotateRightPhotos() {
        this.isAsyncTaskDialogOn = true;
        this.isAsyncTaskDirtyWork = true;
        PhotoProcessAsyncTask fileProcessAyncTask = new PhotoProcessAsyncTask();
        fileProcessAyncTask.setMainActivity(this);
        fileProcessAyncTask.setProcessMode(2);
        if (Build.VERSION.SDK_INT >= 11) {
            fileProcessAyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
        } else {
            fileProcessAyncTask.execute(new Void[0]);
        }
    }

    public String getMimeType(String url) {
        String extension = MimeTypeMap.getFileExtensionFromUrl(url);
        if (extension != null) {
            return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public String getLeftOrientationNumber(String curNumber) {
        int number = Integer.valueOf(curNumber).intValue();
        if (number == 1 || number == 0) {
            return "8";
        }
        if (number == 8) {
            return "3";
        }
        if (number == 3) {
            return "6";
        }
        if (number == 6) {
            return "1";
        }
        return "1";
    }

    /* access modifiers changed from: package-private */
    public String getRightOrientationNumber(String curNumber) {
        int number = Integer.valueOf(curNumber).intValue();
        if (number == 1 || number == 0) {
            return "6";
        }
        if (number == 6) {
            return "3";
        }
        if (number == 3) {
            return "8";
        }
        if (number == 8) {
            return "1";
        }
        return "1";
    }

    private void callMediaScanner(String[] paths) {
        MediaScannerConnection.scanFile(this, paths, (String[]) null, new MediaScannerConnection.OnScanCompletedListener() {
            public void onScanCompleted(String path, Uri uri) {
            }
        });
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == -1) {
            switch (requestCode) {
                case 3:
                    this.isNeedProcessRET_take_picture = true;
                    return;
                default:
                    return;
            }
        }
    }

    public boolean isIntentAvailable(Context context, String action) {
        return context.getPackageManager().queryIntentActivities(new Intent(action), 65536).size() > 0;
    }

    /* access modifiers changed from: package-private */
    public void __________mark_option_content() {
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.option_main_menu, menu);
        return true;
    }

    public boolean onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
        if (!this.isFileSelectModeEnabled.booleanValue()) {
            menu.findItem(R.id.menu_photo_share).setVisible(false);
            menu.findItem(R.id.menu_photo_delete).setVisible(false);
            menu.findItem(R.id.menu_photo_rename).setVisible(false);
            menu.findItem(R.id.menu_photo_edit_poi).setVisible(false);
            menu.findItem(R.id.menu_photo_rotate_left).setVisible(false);
            menu.findItem(R.id.menu_photo_rotate_right).setVisible(false);
            menu.findItem(R.id.menu_sorting_photos).setVisible(true);
            if (this.m_curFilePosition == -1) {
                menu.findItem(R.id.menu_photo_setas).setVisible(false);
            } else {
                menu.findItem(R.id.menu_photo_setas).setVisible(true);
            }
            menu.findItem(R.id.menu_goto_this_app_web).setVisible(true);
            menu.findItem(R.id.menu_my_app_category).setVisible(true);
            menu.findItem(R.id.menu_goto_my_apps_web).setVisible(true);
            menu.findItem(R.id.menu_about).setVisible(true);
        } else {
            menu.findItem(R.id.menu_photo_share).setVisible(false);
            menu.findItem(R.id.menu_photo_delete).setVisible(false);
            menu.findItem(R.id.menu_photo_rename).setVisible(true);
            menu.findItem(R.id.menu_photo_edit_poi).setVisible(true);
            menu.findItem(R.id.menu_photo_rotate_left).setVisible(true);
            menu.findItem(R.id.menu_photo_rotate_right).setVisible(true);
            menu.findItem(R.id.menu_sorting_photos).setVisible(false);
            menu.findItem(R.id.menu_photo_setas).setVisible(false);
            menu.findItem(R.id.menu_goto_this_app_web).setVisible(false);
            menu.findItem(R.id.menu_my_app_category).setVisible(false);
            menu.findItem(R.id.menu_goto_my_apps_web).setVisible(false);
            menu.findItem(R.id.menu_about).setVisible(false);
            int selectedFileCount = 0;
            Boolean bHaveNotJpegFile = false;
            for (int i = 0; i < this.mainList.size(); i++) {
                String selModeStr = this.imageList_forSel.get(i);
                if (selModeStr != "0") {
                    selectedFileCount++;
                    if (selModeStr == "-2") {
                        bHaveNotJpegFile = true;
                    }
                }
            }
            if (this.mainList.size() != this.imageList_forSel.size()) {
                Toast.makeText(this, "list size count fail!", 1).show();
                this.gIsFinished = true;
                finish();
            }
            if (selectedFileCount == 0) {
                menu.findItem(R.id.menu_photo_rename).setVisible(false);
                menu.findItem(R.id.menu_photo_edit_poi).setVisible(false);
                menu.findItem(R.id.menu_photo_rotate_left).setVisible(false);
                menu.findItem(R.id.menu_photo_rotate_right).setVisible(false);
            } else if (selectedFileCount > 1) {
                menu.findItem(R.id.menu_photo_rename).setVisible(false);
            }
            if (bHaveNotJpegFile.booleanValue()) {
                menu.findItem(R.id.menu_photo_edit_poi).setVisible(false);
                menu.findItem(R.id.menu_photo_rotate_left).setVisible(false);
                menu.findItem(R.id.menu_photo_rotate_right).setVisible(false);
            }
            if (selectedFileCount == 0) {
                return false;
            }
        }
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_photo_share:
                sharePhotos();
                return true;
            case R.id.menu_photo_delete:
                deletePhotos();
                return true;
            case R.id.menu_photo_rename:
                renamePhoto();
                return true;
            case R.id.menu_photo_edit_poi:
                editPoiPhotos();
                return true;
            case R.id.menu_photo_rotate_left:
                rotateLeftPhotos();
                return true;
            case R.id.menu_photo_rotate_right:
                rotateRightPhotos();
                return true;
            case R.id.menu_sorting_photos:
                sortPhotos();
                return true;
            case R.id.menu_photo_setas:
                setasPhoto();
                return true;
            case R.id.menu_my_app_category:
                showPromoteDialog();
                return true;
            case R.id.menu_goto_this_app_web:
                if (this.which_publish_market == WHICH_PUBLISH_MARKET.NORMAL || this.which_publish_market == WHICH_PUBLISH_MARKET.GOOGLE) {
                    startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=com.jkfantasy.photopoinokia")));
                    return true;
                } else if (this.which_publish_market == WHICH_PUBLISH_MARKET.SAMSUNG) {
                    Intent intent = new Intent();
                    if (this.which_map == WHICH_MAP.GOOGLE_MAP_ANDROID_V2) {
                        intent.setData(Uri.parse("samsungapps://ProductDetail/com.jkfantasy.photopoi"));
                    } else if (this.which_map == WHICH_MAP.GOOGLE_MAP_JS_V3) {
                        intent.setData(Uri.parse("samsungapps://ProductDetail/com.jkfantasy.photopoi"));
                    } else if (this.which_map == WHICH_MAP.BAIDU_MAP_ANDROID) {
                        intent.setData(Uri.parse("samsungapps://ProductDetail/com.jkfantasy.photopoibaidu"));
                    } else if (this.which_map == WHICH_MAP.AMAZON_MAP_ANDROID) {
                        intent.setData(Uri.parse("samsungapps://ProductDetail/com.jkfantasy.photopoiamazon"));
                    }
                    if (this.gBuildVerSDK > 11) {
                        intent.addFlags(335544352);
                    } else {
                        intent.addFlags(335544320);
                    }
                    startActivity(intent);
                    return true;
                } else if (this.which_publish_market != WHICH_PUBLISH_MARKET.AMAZON) {
                    return true;
                } else {
                    Intent goToAppstore = null;
                    if (this.which_map == WHICH_MAP.GOOGLE_MAP_ANDROID_V2) {
                        goToAppstore = new Intent("android.intent.action.VIEW", Uri.parse("amzn://apps/android?p=com.jkfantasy.photopoi"));
                    } else if (this.which_map == WHICH_MAP.GOOGLE_MAP_JS_V3) {
                        goToAppstore = new Intent("android.intent.action.VIEW", Uri.parse("amzn://apps/android?p=com.jkfantasy.photopoi"));
                    } else if (this.which_map == WHICH_MAP.BAIDU_MAP_ANDROID) {
                        goToAppstore = new Intent("android.intent.action.VIEW", Uri.parse("amzn://apps/android?p=com.jkfantasy.photopoibaidu"));
                    } else if (this.which_map == WHICH_MAP.AMAZON_MAP_ANDROID) {
                        goToAppstore = new Intent("android.intent.action.VIEW", Uri.parse("amzn://apps/android?p=com.jkfantasy.photopoiamazon"));
                    }
                    goToAppstore.addFlags(DriveFile.MODE_READ_ONLY);
                    startActivity(goToAppstore);
                    return true;
                }
            case R.id.menu_goto_my_apps_web:
                if (this.which_publish_market == WHICH_PUBLISH_MARKET.NORMAL || this.which_publish_market == WHICH_PUBLISH_MARKET.GOOGLE) {
                    startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://search?q=pub:JK.Fantasy")));
                    return true;
                } else if (this.which_publish_market == WHICH_PUBLISH_MARKET.SAMSUNG) {
                    Intent intent2 = new Intent();
                    intent2.setData(Uri.parse("samsungapps://SellerDetail/ielwefazcb"));
                    if (this.gBuildVerSDK > 11) {
                        intent2.addFlags(335544352);
                    } else {
                        intent2.addFlags(335544320);
                    }
                    startActivity(intent2);
                    return true;
                } else if (this.which_publish_market != WHICH_PUBLISH_MARKET.AMAZON) {
                    return true;
                } else {
                    Intent gotoMyAppsIntent = null;
                    if (this.which_map == WHICH_MAP.GOOGLE_MAP_ANDROID_V2) {
                        gotoMyAppsIntent = new Intent("android.intent.action.VIEW", Uri.parse("amzn://apps/android?p=com.jkfantasy.photopoi&showAll=1"));
                    } else if (this.which_map == WHICH_MAP.GOOGLE_MAP_JS_V3) {
                        gotoMyAppsIntent = new Intent("android.intent.action.VIEW", Uri.parse("amzn://apps/android?p=com.jkfantasy.photopoi&showAll=1"));
                    } else if (this.which_map == WHICH_MAP.BAIDU_MAP_ANDROID) {
                        gotoMyAppsIntent = new Intent("android.intent.action.VIEW", Uri.parse("amzn://apps/android?p=com.jkfantasy.photopoibaidu&showAll=1"));
                    } else if (this.which_map == WHICH_MAP.AMAZON_MAP_ANDROID) {
                        gotoMyAppsIntent = new Intent("android.intent.action.VIEW", Uri.parse("amzn://apps/android?p=com.jkfantasy.photopoiamazon&showAll=1"));
                    }
                    startActivity(gotoMyAppsIntent);
                    return true;
                }
            case R.id.menu_about:
                this.aboutDialog = new Dialog(this);
                this.aboutDialog.setContentView(R.layout.about_dialog);
                this.aboutDialog.setCancelable(true);
                this.aboutDialog.show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private Boolean isSamsungPhone() {
        if (this.manufactureStr.equalsIgnoreCase("samsung")) {
            return true;
        }
        return false;
    }

    public void showPromoteDialog() {
        if (this.gBuildVerSDK >= 16 && isSamsungPhone().booleanValue()) {
            this.mShowSketchCamera = true;
        }
        this.mPromoteDialog = new Dialog(this);
        this.mPromoteDialog.setContentView(R.layout.promote_dialog);
        this.mPromoteDialog.setCancelable(true);
        this.mPromoteDialog.setTitle(getString(R.string.my_app_catagory_tilte));
        this.mExpListView = (ExpandableListView) this.mPromoteDialog.findViewById(R.id.explv_promote_listview);
        this.mExpListDataHeader = new ArrayList();
        this.mExpListDataChild = new HashMap<>();
        this.mExpListDataHeader.add(getString(R.string.my_app_catagory_camera));
        this.mExpListDataHeader.add(getString(R.string.my_app_catagory_gadget));
        this.mExpListDataHeader.add(getString(R.string.my_app_catagory_travel_map_photo));
        this.mExpListDataHeader.add(getString(R.string.my_app_catagory_time_manage));
        List<PromoteItem> cameraAPPs = new ArrayList<>();
        if (this.mShowSketchCamera) {
            PromoteItem promoteItem = new PromoteItem();
            promoteItem.setAppName(getString(R.string.api_sketch_camera));
            promoteItem.setDrawableId(R.drawable.api_sketch_camera_64);
            promoteItem.setPackageName("com.jkfantasy.jkpcoloreffectcamera");
            cameraAPPs.add(promoteItem);
        }
        PromoteItem promoteItem2 = new PromoteItem();
        promoteItem2.setAppName(getString(R.string.api_mirror_camera));
        promoteItem2.setDrawableId(R.drawable.api_mirror_camera_64);
        promoteItem2.setPackageName("com.jkfantasy.camera.jkpmirrorcamera");
        cameraAPPs.add(promoteItem2);
        PromoteItem promoteItem3 = new PromoteItem();
        promoteItem3.setAppName(getString(R.string.api_magnifier_camera));
        promoteItem3.setDrawableId(R.drawable.api_magnifier_camera_64);
        promoteItem3.setPackageName("com.jkfantasy.camera.jkpmagnifiercamera");
        cameraAPPs.add(promoteItem3);
        PromoteItem promoteItem4 = new PromoteItem();
        promoteItem4.setAppName(getString(R.string.api_gps_map_camera));
        promoteItem4.setDrawableId(R.drawable.api_gps_map_camera_64);
        promoteItem4.setPackageName("com.jkfantasy.gpsmapcamera");
        cameraAPPs.add(promoteItem4);
        List<PromoteItem> gadgetAPPs = new ArrayList<>();
        PromoteItem promoteItem5 = new PromoteItem();
        promoteItem5.setAppName(getString(R.string.api_night_flash));
        promoteItem5.setDrawableId(R.drawable.api_night_flash_64);
        promoteItem5.setPackageName("com.jkfantasy.nightflash");
        gadgetAPPs.add(promoteItem5);
        PromoteItem promoteItem6 = new PromoteItem();
        promoteItem6.setAppName(getString(R.string.api_screen_light));
        promoteItem6.setDrawableId(R.drawable.api_screen_light_64);
        promoteItem6.setPackageName("com.jkfantasy.screen.jkpscreenlight");
        gadgetAPPs.add(promoteItem6);
        PromoteItem promoteItem7 = new PromoteItem();
        promoteItem7.setAppName(getString(R.string.api_meter_toolbox));
        promoteItem7.setDrawableId(R.drawable.api_meter_toolbox_64);
        promoteItem7.setPackageName("com.jkfantasy.meterbox");
        gadgetAPPs.add(promoteItem7);
        List<PromoteItem> travelMapPhotoAPPs = new ArrayList<>();
        PromoteItem promoteItem8 = new PromoteItem();
        promoteItem8.setAppName(getString(R.string.api_gps_photo_viewer_google));
        promoteItem8.setDrawableId(R.drawable.api_gps_photo_viewer_googlemap_64);
        promoteItem8.setPackageName("com.jkfantasy.photopoi");
        travelMapPhotoAPPs.add(promoteItem8);
        PromoteItem promoteItem9 = new PromoteItem();
        promoteItem9.setAppName(getString(R.string.api_gps_photo_viewer_here));
        promoteItem9.setDrawableId(R.drawable.api_gps_photo_viewer_heremap_64);
        promoteItem9.setPackageName("com.jkfantasy.photopoinokia");
        travelMapPhotoAPPs.add(promoteItem9);
        PromoteItem promoteItem10 = new PromoteItem();
        promoteItem10.setAppName(getString(R.string.api_gps_map_camera));
        promoteItem10.setDrawableId(R.drawable.api_gps_map_camera_64);
        promoteItem10.setPackageName("com.jkfantasy.gpsmapcamera");
        travelMapPhotoAPPs.add(promoteItem10);
        PromoteItem promoteItem11 = new PromoteItem();
        promoteItem11.setAppName(getString(R.string.api_weather_map));
        promoteItem11.setDrawableId(R.drawable.api_weather_map_64);
        promoteItem11.setPackageName("com.jkfantasy.map.weathermap");
        travelMapPhotoAPPs.add(promoteItem11);
        PromoteItem promoteItem12 = new PromoteItem();
        promoteItem12.setAppName(getString(R.string.api_i_am_here));
        promoteItem12.setDrawableId(R.drawable.api_i_am_here_64);
        promoteItem12.setPackageName("com.jkfantasy.cmonbaby");
        travelMapPhotoAPPs.add(promoteItem12);
        List<PromoteItem> timeMgrAPPs = new ArrayList<>();
        PromoteItem promoteItem13 = new PromoteItem();
        promoteItem13.setAppName(getString(R.string.api_phone_usage_time));
        promoteItem13.setDrawableId(R.drawable.api_phone_usage_time_64);
        promoteItem13.setPackageName("com.jkfantasy.tmgr.phoneusagetime");
        timeMgrAPPs.add(promoteItem13);
        PromoteItem promoteItem14 = new PromoteItem();
        promoteItem14.setAppName(getString(R.string.api_time_record_manager));
        promoteItem14.setDrawableId(R.drawable.api_time_record_manager_64);
        promoteItem14.setPackageName("com.jkfantasy.tmgr.timerecordmgr");
        timeMgrAPPs.add(promoteItem14);
        PromoteItem promoteItem15 = new PromoteItem();
        promoteItem15.setAppName(getString(R.string.api_tap_counter_manager));
        promoteItem15.setDrawableId(R.drawable.api_tap_counter_manager_64);
        promoteItem15.setPackageName("com.jkfantasy.tmgr.tapcountermgr");
        timeMgrAPPs.add(promoteItem15);
        this.mExpListDataChild.put(this.mExpListDataHeader.get(0), cameraAPPs);
        this.mExpListDataChild.put(this.mExpListDataHeader.get(1), gadgetAPPs);
        this.mExpListDataChild.put(this.mExpListDataHeader.get(2), travelMapPhotoAPPs);
        this.mExpListDataChild.put(this.mExpListDataHeader.get(3), timeMgrAPPs);
        this.mExpListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                MainActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + ((PromoteItem) MainActivity.this.mExpListDataChild.get(MainActivity.this.mExpListDataHeader.get(groupPosition)).get(childPosition)).getPackageName())));
                return false;
            }
        });
        this.mExpListAdapter = new PromoteExpandableListAdapter(this, this.mExpListDataHeader, this.mExpListDataChild);
        this.mExpListView.setAdapter(this.mExpListAdapter);
        this.mExpListView.expandGroup(2);
        this.mPromoteDialog.show();
    }

    /* access modifiers changed from: package-private */
    public void __________mark_on_complete() {
    }

    /* access modifiers changed from: package-private */
    public void initializeSettings() {
        if (this.isNeedProcessINTENT_action_view.booleanValue()) {
            this.m_viewMode = 0;
            this.m_pageNumber = 0;
            this.m_mimeMode = 0;
            this.m_gpsMode = 0;
            this.m_sortMode = 0;
            this.m_sortBy = 0;
            this.m_folderMode = 0;
            this.m_bucketId = "";
            this.m_bucketName = "";
            this.m_curFilePosition = 0;
            this.m_curFileName = "";
            this.m_mapZoomLevel = 15.0f;
            this.m_mapTypeSelect = 0;
            return;
        }
        this.settings = getSharedPreferences("JK.FinalFantasy_PoiPhoto_V1.0.0.ini", 0);
        this.settings_viewMode = this.settings.getInt("viewMode", 0);
        this.settings_pageNumber = this.settings.getInt("pageNumber", 0);
        this.settings_mimeMode = this.settings.getInt("mimeMode", 1);
        this.settings_gpsMode = this.settings.getInt("gpsMode", 0);
        this.settings_sortMode = this.settings.getInt("sortMode", 0);
        this.settings_sortBy = this.settings.getInt("sortBy", 0);
        this.settings_folderMode = this.settings.getInt("folderMode", 0);
        this.settings_bucketId = this.settings.getString("bucketId", "");
        this.settings_bucketName = this.settings.getString("bucketName", "");
        this.settings_curFilePosition = this.settings.getInt("curFilePosition", 0);
        this.settings_curFileName = this.settings.getString("curFileName", "");
        this.settings_mapZoomLevel = this.settings.getFloat("mapZoomLevel", 15.0f);
        this.settings_mapTypeSelect = this.settings.getInt("mapTypeSelect", 0);
        this.settings_mapLayerIndex = this.settings.getInt("mapLayerIndex", 0);
        this.settings_mapWeatherDegreeIsC = this.settings.getBoolean("mapWeatherDegreeIsC", false);
        this.settings_mapPlaceSearchValue = this.settings.getString("mapPlaceSearchValue", "");
        this.settings_mapPlaceCmpIndex = this.settings.getInt("mapPlaceCmpIndex", 0);
        this.settings_mapPlaceCmpString = this.settings.getString("mapPlaceCmpString", "");
        this.m_viewMode = this.settings_viewMode;
        this.m_pageNumber = this.settings_pageNumber;
        this.m_mimeMode = this.settings_mimeMode;
        this.m_gpsMode = this.settings_gpsMode;
        this.m_sortMode = this.settings_sortMode;
        this.m_sortBy = this.settings_sortBy;
        this.m_folderMode = this.settings_folderMode;
        this.m_bucketId = this.settings_bucketId;
        this.m_bucketName = this.settings_bucketName;
        this.m_curFilePosition = this.settings_curFilePosition;
        this.m_curFileName = this.settings_curFileName;
        this.m_mapZoomLevel = this.settings_mapZoomLevel;
        this.m_mapTypeSelect = this.settings_mapTypeSelect;
        this.m_mapLayerIndex = this.settings_mapLayerIndex;
        this.m_mapWeatherDegreeIsC = this.settings_mapWeatherDegreeIsC;
        this.m_mapPlaceSearchValue = this.settings_mapPlaceSearchValue;
        this.m_mapPlaceCmpIndex = this.settings_mapPlaceCmpIndex;
        this.m_mapPlaceCmpString = this.settings_mapPlaceCmpString;
    }

    /* access modifiers changed from: package-private */
    public void saveCurrentSettings() {
        if (!this.isNeedProcessINTENT_action_view.booleanValue()) {
            this.settings = getSharedPreferences("JK.FinalFantasy_PoiPhoto_V1.0.0.ini", 0);
            this.settings_viewMode = this.m_viewMode;
            this.settings_pageNumber = this.m_pageNumber;
            this.settings_mimeMode = this.m_mimeMode;
            this.settings_gpsMode = this.m_gpsMode;
            this.settings_sortMode = this.m_sortMode;
            this.settings_sortBy = this.m_sortBy;
            this.settings_folderMode = this.m_folderMode;
            this.settings_bucketId = this.m_bucketId;
            this.settings_bucketName = this.m_bucketName;
            this.settings_curFilePosition = this.m_curFilePosition;
            this.settings_curFileName = this.m_curFileName;
            this.settings_mapZoomLevel = this.m_mapZoomLevel;
            this.settings_mapTypeSelect = this.m_mapTypeSelect;
            this.settings_mapLayerIndex = this.m_mapLayerIndex;
            this.settings_mapWeatherDegreeIsC = this.m_mapWeatherDegreeIsC;
            this.settings_mapPlaceSearchValue = this.m_mapPlaceSearchValue;
            this.settings_mapPlaceCmpIndex = this.m_mapPlaceCmpIndex;
            this.settings_mapPlaceCmpString = this.m_mapPlaceCmpString;
            this.settings.edit().putInt("viewMode", this.settings_viewMode).putInt("pageNumber", this.settings_pageNumber).putInt("mimeMode", this.settings_mimeMode).putInt("gpsMode", this.settings_gpsMode).putInt("sortMode", this.settings_sortMode).putInt("sortBy", this.settings_sortBy).putInt("folderMode", this.settings_folderMode).putString("bucketId", this.settings_bucketId).putString("bucketName", this.settings_bucketName).putInt("curFilePosition", this.settings_curFilePosition).putString("curFileName", this.settings_curFileName).putFloat("mapZoomLevel", this.settings_mapZoomLevel).putInt("mapTypeSelect", this.settings_mapTypeSelect).putInt("mapLayerIndex", this.settings_mapLayerIndex).putBoolean("mapWeatherDegreeIsC", this.settings_mapWeatherDegreeIsC).putString("mapPlaceSearchValue", this.settings_mapPlaceSearchValue).putInt("mapPlaceCmpIndex", this.settings_mapPlaceCmpIndex).putString("mapPlaceCmpString", this.settings_mapPlaceCmpString).commit();
        }
    }

    /* access modifiers changed from: package-private */
    public void settingToKernel() {
    }

    /* access modifiers changed from: package-private */
    public void settingKernelToUI() {
        content_x_uiUpdate_and_process();
        if (this.m_curFilePosition == -1) {
            this.m_isGoogleMapEnable = false;
            this.btn_toolbar_google_map.setBackgroundDrawable(getResources().getDrawable(R.drawable.google_map_disable));
        } else if (this.mainList.get(this.m_curFilePosition).get("latitude") == null) {
            this.m_isGoogleMapEnable = false;
            this.btn_toolbar_google_map.setBackgroundDrawable(getResources().getDrawable(R.drawable.google_map_disable));
        } else {
            this.m_isGoogleMapEnable = true;
            this.btn_toolbar_google_map.setBackgroundDrawable(getResources().getDrawable(R.drawable.google_map_normal));
        }
        if (this.m_mimeMode == 0) {
            this.tv_toolbar_photo_filter_jpeg.setText("");
        } else {
            this.tv_toolbar_photo_filter_jpeg.setText("JPEG");
        }
        if (this.m_gpsMode == 0) {
            this.tv_toolbar_photo_filter_gps.setText("");
        } else if (this.m_gpsMode == 1) {
            this.tv_toolbar_photo_filter_gps.setText("GPS");
        }
        if (this.m_folderMode == 0) {
            this.tv_toolbar_photo_filter_folder_name.setText(getString(R.string.AllFolders));
        } else if (this.m_folderMode == 1) {
            this.tv_toolbar_photo_filter_folder_name.setText(this.m_bucketName);
        }
    }

    public boolean makeAppsdStorageDir() {
        File folder0 = new File(String.valueOf(Environment.getExternalStorageDirectory().toString()) + "/JK.Fantasy");
        if (!folder0.exists()) {
            folder0.mkdir();
        }
        File folder1 = new File(String.valueOf(Environment.getExternalStorageDirectory().toString()) + "/JK.Fantasy" + "/GpsPhotoViewer-HERE");
        if (folder1.exists()) {
            return true;
        }
        folder1.mkdir();
        return true;
    }

    public void writeKmlFileToSd(String data) {
        makeAppsdStorageDir();
        try {
            Writer writer = new BufferedWriter(new FileWriter(new File(String.valueOf(Environment.getExternalStorageDirectory().toString()) + "/JK.Fantasy" + "/GpsPhotoViewer-HERE" + "/poi.kml")));
            writer.write(data);
            writer.close();
        } catch (IOException e) {
        }
    }

    public String getKmlFileFullPathName() {
        return String.valueOf(Environment.getExternalStorageDirectory().toString()) + "/JK.Fantasy" + "/GpsPhotoViewer-HERE" + "/poi.kml";
    }

    public String getAppTitle(String packageName) {
        PackageManager lPackageManager = getPackageManager();
        ApplicationInfo lApplicationInfo = null;
        try {
            lApplicationInfo = lPackageManager.getApplicationInfo(packageName, 0);
        } catch (PackageManager.NameNotFoundException e) {
        }
        return (String) (lApplicationInfo != null ? lPackageManager.getApplicationLabel(lApplicationInfo) : "Unknown");
    }

    public Drawable getAppIcon(String packageName) {
        try {
            return getPackageManager().getApplicationIcon(packageName);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

    public String getAppClassName(String packageName) {
        return getPackageManager().getLaunchIntentForPackage(packageName).getComponent().getClassName();
    }

    public class MapPkgItem {
        String appName;
        String className;
        String packageName;

        public MapPkgItem() {
        }

        public void setAppName(String appName2) {
            this.appName = appName2;
        }

        public String getAppName() {
            return this.appName;
        }

        public void setPackageName(String packageName2) {
            this.packageName = packageName2;
        }

        public String getPackageName() {
            return this.packageName;
        }

        public void setClassName(String className2) {
            this.className = className2;
        }

        public String getClassName() {
            return this.className;
        }
    }

    private class LaunchMapsViewHolder {
        ImageView iv_list_item;
        LinearLayout ll_root;
        TextView tv_list_item;

        private LaunchMapsViewHolder() {
        }

        /* synthetic */ LaunchMapsViewHolder(MainActivity mainActivity, LaunchMapsViewHolder launchMapsViewHolder) {
            this();
        }
    }

    private class LaunchMapsListAdapter extends BaseAdapter {
        private Activity activity;
        private LayoutInflater layoutInflater;

        public LaunchMapsListAdapter(Context context, Activity a) {
            this.activity = a;
            this.layoutInflater = (LayoutInflater) context.getSystemService("layout_inflater");
        }

        public int getCount() {
            return MainActivity.this.mapPkgItemAry.size();
        }

        public Object getItem(int position) {
            return Integer.valueOf(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        @SuppressLint({"NewApi"})
        public View getView(int position, View convertView, ViewGroup parent) {
            LaunchMapsViewHolder viewHolder;
            if (convertView == null) {
                convertView = this.layoutInflater.inflate(R.layout.launch_maps_lv_item, (ViewGroup) null);
                viewHolder = new LaunchMapsViewHolder(MainActivity.this, (LaunchMapsViewHolder) null);
                viewHolder.ll_root = (LinearLayout) convertView.findViewById(R.id.ll_root);
                viewHolder.iv_list_item = (ImageView) convertView.findViewById(R.id.iv_list_item);
                viewHolder.tv_list_item = (TextView) convertView.findViewById(R.id.tv_list_item);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (LaunchMapsViewHolder) convertView.getTag();
            }
            MapPkgItem mapPkgItem = MainActivity.this.mapPkgItemAry.get(position);
            String packageName = mapPkgItem.getPackageName();
            String appName = mapPkgItem.getAppName();
            if (packageName.compareTo("othermap.jkfantasy.com") == 0) {
                Drawable appIcon = MainActivity.this.getResources().getDrawable(R.drawable.other_map_question_mark_64x64);
                if (MainActivity.this.gBuildVerSDK < 16) {
                    viewHolder.iv_list_item.setBackgroundDrawable(appIcon);
                } else {
                    viewHolder.iv_list_item.setBackground(appIcon);
                }
                viewHolder.tv_list_item.setText(MainActivity.this.getString(R.string.launch_maps_dlg_other_maps));
            } else {
                Drawable appIcon2 = MainActivity.this.getAppIcon(packageName);
                if (MainActivity.this.gBuildVerSDK < 16) {
                    viewHolder.iv_list_item.setBackgroundDrawable(appIcon2);
                } else {
                    viewHolder.iv_list_item.setBackground(appIcon2);
                }
                viewHolder.tv_list_item.setText(appName);
            }
            return convertView;
        }
    }
}
