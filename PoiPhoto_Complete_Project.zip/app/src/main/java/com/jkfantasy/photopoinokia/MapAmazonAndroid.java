package com.jkfantasy.photopoinokia;

public class MapAmazonAndroid {
}
