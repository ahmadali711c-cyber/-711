package com.jkfantasy.photopoinokia;

public class MapGoogleAndroidV2 {
}
