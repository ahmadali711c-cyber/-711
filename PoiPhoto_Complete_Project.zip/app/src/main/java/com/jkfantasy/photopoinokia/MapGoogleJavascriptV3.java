package com.jkfantasy.photopoinokia;

public class MapGoogleJavascriptV3 {
}
