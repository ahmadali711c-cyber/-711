package com.jkfantasy.photopoinokia;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import java.lang.Thread;
import java.lang.ref.SoftReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Stack;
import java.util.WeakHashMap;

public class PhotoFilterPage extends Activity {
    ImageTextAdapter adapter;
    AlertDialog alertDialog;
    LinearLayout btn_only_select_gps;
    LinearLayout btn_only_select_jpeg;
    Button btn_title_back;
    Button btn_title_confirm;
    CheckBox cb_only_select_gps;
    CheckBox cb_only_select_jpeg;
    Boolean isListViewInitialized = false;
    ListView lv_folder_filter;
    String m_bucketId = "";
    String m_bucketName = "";
    int m_curFolderPosition = 0;
    ViewHolder m_curFolderViewHolder = null;
    int m_folderMode = 0;
    int m_gpsMode = 0;
    Boolean m_isModified = false;
    Boolean m_isNeedSaveSettings = false;
    int m_mimeMode = 0;
    /* access modifiers changed from: private */
    public ArrayList<HashMap<String, String>> mainList;
    SharedPreferences settings;
    String settings_bucketId = "";
    String settings_bucketName = "";
    int settings_folderMode = 0;
    int settings_gpsMode = 0;
    int settings_mimeMode = 0;
    String total_photoNum_in_all_folders = "0";
    TextView tv_bucket_name;
    TextView tv_bucket_pre_path;
    TextView tv_only_select_gps;
    TextView tv_only_select_jpeg;

    private class ViewHolder {
        TextView countView;
        ImageView imageView;
        RadioButton radioButton;
        TextView textView;

        private ViewHolder() {
        }

        /* synthetic */ ViewHolder(PhotoFilterPage photoFilterPage, ViewHolder viewHolder) {
            this();
        }
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.photo_filter_page);
        initResources();
        findViews();
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
    }

    /* access modifiers changed from: protected */
    public void onRestart() {
        super.onRestart();
    }

    /* access modifiers changed from: package-private */
    public void general_refresh_view_func() {
        this.adapter.imageLoader.stopThread();
        try {
            this.adapter.imageLoader.photoLoaderThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        this.lv_folder_filter.setAdapter((ListAdapter) null);
        if (!getMediaData().booleanValue()) {
            Toast.makeText(this, getString(R.string.StorageIsPrepare), 1).show();
            finish();
            return;
        }
        getCurrentData();
        initialListView();
        settingKernelToUI();
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
        initializeSettings();
        if (!getMediaData().booleanValue()) {
            Toast.makeText(this, getString(R.string.StorageIsPrepare), 1).show();
            finish();
            return;
        }
        getCurrentData();
        initialListView();
        settingKernelToUI();
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        if (this.m_isNeedSaveSettings.booleanValue()) {
            saveCurrentSettings();
        }
        this.adapter.imageLoader.stopThread();
        try {
            this.adapter.imageLoader.photoLoaderThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        this.lv_folder_filter.setAdapter((ListAdapter) null);
        super.onPause();
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
        this.isListViewInitialized = false;
    }

    public boolean dispatchKeyEvent(KeyEvent event) {
        int action = event.getAction();
        switch (event.getKeyCode()) {
            case 4:
                if (action != 1) {
                    return true;
                }
                if (!this.m_isModified.booleanValue()) {
                    finish();
                    return true;
                } else if (this.alertDialog.isShowing()) {
                    this.alertDialog.hide();
                    return true;
                } else {
                    this.alertDialog.show();
                    return true;
                }
            default:
                return super.dispatchKeyEvent(event);
        }
    }

    /* access modifiers changed from: package-private */
    public void __________mark_resource() {
    }

    /* access modifiers changed from: package-private */
    public void initResources() {
        this.mainList = new ArrayList<>();
    }

    private void findViews() {
        this.btn_title_back = (Button) findViewById(R.id.btn_title_back);
        this.btn_title_confirm = (Button) findViewById(R.id.btn_title_confirm);
        this.btn_only_select_jpeg = (LinearLayout) findViewById(R.id.btn_only_select_jpeg);
        this.tv_only_select_jpeg = (TextView) findViewById(R.id.tv_only_select_jpeg);
        this.cb_only_select_jpeg = (CheckBox) findViewById(R.id.cb_only_select_jpeg);
        this.btn_only_select_gps = (LinearLayout) findViewById(R.id.btn_only_select_gps);
        this.tv_only_select_gps = (TextView) findViewById(R.id.tv_only_select_gps);
        this.cb_only_select_gps = (CheckBox) findViewById(R.id.cb_only_select_gps);
        this.tv_bucket_pre_path = (TextView) findViewById(R.id.tv_bucket_pre_path);
        this.tv_bucket_name = (TextView) findViewById(R.id.tv_bucket_name);
        this.lv_folder_filter = (ListView) findViewById(R.id.lv_folder_filter);
        this.alertDialog = new AlertDialog.Builder(this).create();
        this.alertDialog.setMessage(getString(R.string.IsNeedSaveCurrentSettings));
        this.alertDialog.setButton(-1, getString(R.string.YES), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                PhotoFilterPage.this.m_isNeedSaveSettings = true;
                PhotoFilterPage.this.finish();
            }
        });
        this.alertDialog.setButton(-2, getString(R.string.NO), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                PhotoFilterPage.this.m_isNeedSaveSettings = false;
                PhotoFilterPage.this.finish();
            }
        });
        this.btn_title_back.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return PhotoFilterPage.this.btn_process_title_back(v, event);
            }
        });
        this.btn_title_confirm.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return PhotoFilterPage.this.btn_process_title_confirm(v, event);
            }
        });
        this.btn_only_select_jpeg.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return PhotoFilterPage.this.btn_process_select_jpeg(v, event);
            }
        });
        this.btn_only_select_gps.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return PhotoFilterPage.this.btn_process_select_gps(v, event);
            }
        });
    }

    public boolean btn_process_title_back(View view, MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            case 0:
                this.btn_title_back.setBackgroundDrawable(getResources().getDrawable(R.drawable.rect_blue_btn_press));
                break;
            case 1:
                this.btn_title_back.setBackgroundDrawable(getResources().getDrawable(R.drawable.rect_blue_btn_normal));
                this.m_isNeedSaveSettings = false;
                finish();
                break;
        }
        return false;
    }

    public boolean btn_process_title_confirm(View view, MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            case 0:
                this.btn_title_confirm.setBackgroundDrawable(getResources().getDrawable(R.drawable.rect_blue_btn_press));
                return false;
            case 1:
                this.btn_title_confirm.setBackgroundDrawable(getResources().getDrawable(R.drawable.rect_blue_btn_normal));
                this.m_isNeedSaveSettings = true;
                finish();
                return false;
            default:
                return false;
        }
    }

    public boolean btn_process_select_jpeg(View view, MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            case 0:
                this.btn_only_select_jpeg.setBackgroundColor(Color.rgb(45, 90, 140));
                break;
            case 1:
                this.btn_only_select_jpeg.setBackgroundColor(0);
                if (this.m_mimeMode == 0) {
                    this.cb_only_select_jpeg.setChecked(true);
                    this.m_mimeMode = 1;
                } else {
                    this.cb_only_select_jpeg.setChecked(false);
                    this.m_mimeMode = 0;
                }
                general_refresh_view_func();
                this.m_isModified = true;
                break;
        }
        return false;
    }

    public boolean btn_process_select_gps(View view, MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            case 0:
                this.btn_only_select_gps.setBackgroundColor(Color.rgb(45, 90, 140));
                break;
            case 1:
                this.btn_only_select_gps.setBackgroundColor(0);
                if (this.m_gpsMode == 0) {
                    this.cb_only_select_gps.setChecked(true);
                    this.m_gpsMode = 1;
                } else {
                    this.cb_only_select_gps.setChecked(false);
                    this.m_gpsMode = 0;
                }
                general_refresh_view_func();
                this.m_isModified = true;
                break;
        }
        return false;
    }

    private Boolean getMediaData() {
        String[] projection = {"_id", "_data", "bucket_id", "bucket_display_name", "orientation"};
        String selectGroup = null;
        if (this.m_mimeMode == 0 && this.m_gpsMode == 0) {
            selectGroup = null;
        } else {
            Boolean bFirstAlreadyAdded = false;
            if (this.m_mimeMode != 0) {
                if (!bFirstAlreadyAdded.booleanValue()) {
                    selectGroup = "mime_type='image/jpeg'";
                    bFirstAlreadyAdded = true;
                } else {
                    selectGroup = String.valueOf(String.valueOf((Object) null) + " AND ") + "mime_type='image/jpeg'";
                }
            }
            if (this.m_gpsMode != 0) {
                if (!bFirstAlreadyAdded.booleanValue()) {
                    selectGroup = "latitude<>'null'";
                } else {
                    selectGroup = String.valueOf(String.valueOf(selectGroup) + " AND ") + "latitude<>'null'";
                }
            }
        }
        Cursor cursor = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, selectGroup, (String[]) null, "bucket_display_name ASC");
        if (cursor == null) {
            return false;
        }
        getColumnData(cursor);
        cursor.close();
        return true;
    }

    private void getColumnData(Cursor cur) {
        if (this.mainList.size() > 0) {
            this.mainList.clear();
        }
        this.total_photoNum_in_all_folders = "0";
        String now_bucket_id = "";
        int cursorCount = cur.getCount();
        if (cursorCount > 0 && cur.moveToFirst()) {
            boolean bFirst = true;
            int tmp_image_id = 0;
            String tmp_image_data = null;
            String tmp_image_bucket_id = null;
            String tmp_image_bucket_display_name = null;
            int tmp_image_orientation = 0;
            int tmp_photo_num = 0;
            int index_id = cur.getColumnIndex("_id");
            int index_data = cur.getColumnIndex("_data");
            int index_bucket_id = cur.getColumnIndex("bucket_id");
            int index_bucket_display_name = cur.getColumnIndex("bucket_display_name");
            int index_orientation = cur.getColumnIndex("orientation");
            do {
                String image_bucket_id = cur.getString(index_bucket_id);
                if (image_bucket_id != null) {
                    if (!now_bucket_id.equals(image_bucket_id)) {
                        if (bFirst) {
                            tmp_image_id = cur.getInt(index_id);
                            tmp_image_data = cur.getString(index_data);
                            tmp_image_bucket_id = cur.getString(index_bucket_id);
                            tmp_image_bucket_display_name = cur.getString(index_bucket_display_name);
                            tmp_image_orientation = cur.getInt(index_orientation);
                            tmp_photo_num = 1;
                            bFirst = false;
                        } else {
                            HashMap<String, String> hash = new HashMap<>();
                            hash.put("id", new StringBuilder(String.valueOf(tmp_image_id)).toString());
                            hash.put("data", tmp_image_data);
                            hash.put("bucket_id", tmp_image_bucket_id);
                            hash.put("bucket_display_name", tmp_image_bucket_display_name);
                            hash.put("orientation", new StringBuilder(String.valueOf(tmp_image_orientation)).toString());
                            hash.put("photo_num", String.valueOf(tmp_photo_num));
                            this.mainList.add(hash);
                            tmp_image_id = cur.getInt(index_id);
                            tmp_image_data = cur.getString(index_data);
                            tmp_image_bucket_id = cur.getString(index_bucket_id);
                            tmp_image_bucket_display_name = cur.getString(index_bucket_display_name);
                            tmp_image_orientation = cur.getInt(index_orientation);
                            tmp_photo_num = 1;
                        }
                        now_bucket_id = image_bucket_id;
                    } else {
                        tmp_photo_num++;
                    }
                }
            } while (cur.moveToNext());
            if (tmp_photo_num > 0) {
                HashMap<String, String> hash2 = new HashMap<>();
                hash2.put("id", new StringBuilder(String.valueOf(tmp_image_id)).toString());
                hash2.put("data", tmp_image_data);
                hash2.put("bucket_id", tmp_image_bucket_id);
                hash2.put("bucket_display_name", tmp_image_bucket_display_name);
                hash2.put("orientation", new StringBuilder(String.valueOf(tmp_image_orientation)).toString());
                hash2.put("photo_num", String.valueOf(tmp_photo_num));
                this.mainList.add(hash2);
            }
            this.total_photoNum_in_all_folders = String.valueOf(cursorCount);
        }
        if (this.mainList.size() >= 2) {
            Collections.sort(this.mainList, new Comparator<HashMap<String, String>>() {
                public int compare(HashMap<String, String> arg0, HashMap<String, String> arg1) {
                    return arg0.get("bucket_display_name").compareToIgnoreCase(arg1.get("bucket_display_name"));
                }
            });
        }
    }

    /* access modifiers changed from: package-private */
    public void getCurrentData() {
        int mainListSize = this.mainList.size();
        if (mainListSize > 0 && this.m_curFolderPosition == -1) {
            this.m_curFolderPosition = 0;
        }
        Boolean bFindBucket = false;
        int tmp_curFolderPosition = 0;
        int i = 0;
        while (true) {
            if (i < mainListSize) {
                String image_bucket_display_name = (String) this.mainList.get(i).get("bucket_display_name");
                if (this.m_bucketId.equals((String) this.mainList.get(i).get("bucket_id")) && this.m_bucketName.equals(image_bucket_display_name)) {
                    bFindBucket = true;
                    tmp_curFolderPosition = i;
                    break;
                }
                i++;
            } else {
                break;
            }
        }
        if (bFindBucket.booleanValue()) {
            this.m_curFolderPosition = tmp_curFolderPosition + 1;
        } else {
            this.m_curFolderPosition = 0;
        }
    }

    private void initialListView() {
        this.lv_folder_filter.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View v, int position, long id) {
                if (PhotoFilterPage.this.m_curFolderViewHolder != null) {
                    PhotoFilterPage.this.m_curFolderViewHolder.radioButton.setChecked(false);
                }
                ViewHolder viewHolder = (ViewHolder) v.getTag();
                viewHolder.radioButton.setChecked(true);
                PhotoFilterPage.this.m_curFolderViewHolder = viewHolder;
                PhotoFilterPage.this.m_curFolderPosition = position;
                PhotoFilterPage.this.uiFolderNameUpdate(position);
                PhotoFilterPage.this.m_isModified = true;
                PhotoFilterPage.this.adapter.notifyDataSetChanged();
            }
        });
        this.lv_folder_filter.setOnScrollListener(new AbsListView.OnScrollListener() {
            public void onScroll(AbsListView arg0, int arg1, int arg2, int arg3) {
            }

            public void onScrollStateChanged(AbsListView view, int scrollState) {
            }
        });
        this.adapter = new ImageTextAdapter(this, this);
        this.lv_folder_filter.setAdapter(this.adapter);
        this.lv_folder_filter.setSelection(this.m_curFolderPosition);
    }

    public class MemoryCache {
        private HashMap<String, SoftReference<Bitmap>> cache = new HashMap<>();

        public MemoryCache() {
        }

        public Bitmap get(String id) {
            if (!this.cache.containsKey(id)) {
                return null;
            }
            return this.cache.get(id).get();
        }

        public void put(String id, Bitmap bitmap) {
            this.cache.put(id, new SoftReference(bitmap));
        }

        public void clear() {
            this.cache.clear();
        }
    }

    public class ImageLoader {
        /* access modifiers changed from: private */
        public Map<ImageView, String> imageViews = Collections.synchronizedMap(new WeakHashMap());
        MemoryCache memoryCache;
        PhotosLoader photoLoaderThread = new PhotosLoader();
        PhotosQueue photosQueue = new PhotosQueue();
        final int stub_id = R.drawable.gray_16x16;

        public ImageLoader(Context context) {
            this.memoryCache = new MemoryCache();
            this.photoLoaderThread.setPriority(4);
        }

        public void DisplayImage(String url, Activity activity, ImageView imageView) {
            this.imageViews.put(imageView, url);
            Bitmap bitmap = this.memoryCache.get(url);
            if (bitmap != null) {
                imageView.setImageBitmap(bitmap);
                return;
            }
            queuePhoto(url, activity, imageView);
            imageView.setImageResource(R.drawable.gray_16x16);
        }

        private void queuePhoto(String url, Activity activity, ImageView imageView) {
            synchronized (this.photosQueue.photosToLoad) {
                this.photosQueue.Clean(imageView);
                this.photosQueue.photosToLoad.push(new PhotoToLoad(url, imageView));
                this.photosQueue.photosToLoad.notifyAll();
            }
            if (this.photoLoaderThread.getState() == Thread.State.NEW) {
                this.photoLoaderThread.start();
            }
        }

        /* access modifiers changed from: private */
        public Bitmap getBitmap(String url) {
            int image_orientation;
            int position = Integer.valueOf(url).intValue();
            Bitmap bmThumbnail = MediaStore.Images.Thumbnails.getThumbnail(PhotoFilterPage.this.getContentResolver(), (long) Integer.valueOf((String) ((HashMap) PhotoFilterPage.this.mainList.get(position)).get("id")).intValue(), 3, (BitmapFactory.Options) null);
            if (bmThumbnail == null || (image_orientation = Integer.valueOf((String) ((HashMap) PhotoFilterPage.this.mainList.get(position)).get("orientation")).intValue()) <= 0) {
                return bmThumbnail;
            }
            Matrix matrix = new Matrix();
            matrix.postRotate((float) image_orientation);
            return Bitmap.createBitmap(bmThumbnail, 0, 0, bmThumbnail.getWidth(), bmThumbnail.getHeight(), matrix, true);
        }

        private class PhotoToLoad {
            public ImageView imageView;
            public String url;

            public PhotoToLoad(String u, ImageView i) {
                this.url = u;
                this.imageView = i;
            }
        }

        public void stopThread() {
            this.photoLoaderThread.interrupt();
        }

        class PhotosQueue {
            /* access modifiers changed from: private */
            public Stack<PhotoToLoad> photosToLoad = new Stack<>();

            PhotosQueue() {
            }

            public void Clean(ImageView image) {
                for (int j = 0; j < this.photosToLoad.size(); j++) {
                    if (((PhotoToLoad) this.photosToLoad.get(j)).imageView == image) {
                        this.photosToLoad.remove(j);
                        return;
                    }
                }
            }
        }

        class PhotosLoader extends Thread {
            PhotosLoader() {
            }

            /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v10, resolved type: java.lang.Object} */
            /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v0, resolved type: com.jkfantasy.photopoinokia.PhotoFilterPage$ImageLoader$PhotoToLoad} */
            /* JADX WARNING: Multi-variable type inference failed */
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public void run() {
                /*
                    r9 = this;
                L_0x0000:
                    r5 = 0
                    r4 = 0
                    com.jkfantasy.photopoinokia.PhotoFilterPage$ImageLoader r7 = com.jkfantasy.photopoinokia.PhotoFilterPage.ImageLoader.this     // Catch:{ InterruptedException -> 0x007f }
                    com.jkfantasy.photopoinokia.PhotoFilterPage$ImageLoader$PhotosQueue r7 = r7.photosQueue     // Catch:{ InterruptedException -> 0x007f }
                    java.util.Stack r8 = r7.photosToLoad     // Catch:{ InterruptedException -> 0x007f }
                    monitor-enter(r8)     // Catch:{ InterruptedException -> 0x007f }
                    com.jkfantasy.photopoinokia.PhotoFilterPage$ImageLoader r7 = com.jkfantasy.photopoinokia.PhotoFilterPage.ImageLoader.this     // Catch:{ all -> 0x007c }
                    com.jkfantasy.photopoinokia.PhotoFilterPage$ImageLoader$PhotosQueue r7 = r7.photosQueue     // Catch:{ all -> 0x007c }
                    java.util.Stack r7 = r7.photosToLoad     // Catch:{ all -> 0x007c }
                    int r5 = r7.size()     // Catch:{ all -> 0x007c }
                    if (r5 != 0) goto L_0x006b
                    com.jkfantasy.photopoinokia.PhotoFilterPage$ImageLoader r7 = com.jkfantasy.photopoinokia.PhotoFilterPage.ImageLoader.this     // Catch:{ all -> 0x007c }
                    com.jkfantasy.photopoinokia.PhotoFilterPage$ImageLoader$PhotosQueue r7 = r7.photosQueue     // Catch:{ all -> 0x007c }
                    java.util.Stack r7 = r7.photosToLoad     // Catch:{ all -> 0x007c }
                    r7.wait()     // Catch:{ all -> 0x007c }
                L_0x0024:
                    monitor-exit(r8)     // Catch:{ all -> 0x007c }
                    if (r5 == 0) goto L_0x0064
                    com.jkfantasy.photopoinokia.PhotoFilterPage$ImageLoader r7 = com.jkfantasy.photopoinokia.PhotoFilterPage.ImageLoader.this     // Catch:{ InterruptedException -> 0x007f }
                    java.lang.String r8 = r4.url     // Catch:{ InterruptedException -> 0x007f }
                    android.graphics.Bitmap r3 = r7.getBitmap(r8)     // Catch:{ InterruptedException -> 0x007f }
                    com.jkfantasy.photopoinokia.PhotoFilterPage$ImageLoader r7 = com.jkfantasy.photopoinokia.PhotoFilterPage.ImageLoader.this     // Catch:{ InterruptedException -> 0x007f }
                    com.jkfantasy.photopoinokia.PhotoFilterPage$MemoryCache r7 = r7.memoryCache     // Catch:{ InterruptedException -> 0x007f }
                    java.lang.String r8 = r4.url     // Catch:{ InterruptedException -> 0x007f }
                    r7.put(r8, r3)     // Catch:{ InterruptedException -> 0x007f }
                    com.jkfantasy.photopoinokia.PhotoFilterPage$ImageLoader r7 = com.jkfantasy.photopoinokia.PhotoFilterPage.ImageLoader.this     // Catch:{ InterruptedException -> 0x007f }
                    java.util.Map r7 = r7.imageViews     // Catch:{ InterruptedException -> 0x007f }
                    android.widget.ImageView r8 = r4.imageView     // Catch:{ InterruptedException -> 0x007f }
                    java.lang.Object r6 = r7.get(r8)     // Catch:{ InterruptedException -> 0x007f }
                    java.lang.String r6 = (java.lang.String) r6     // Catch:{ InterruptedException -> 0x007f }
                    if (r6 == 0) goto L_0x0064
                    java.lang.String r7 = r4.url     // Catch:{ InterruptedException -> 0x007f }
                    boolean r7 = r6.equals(r7)     // Catch:{ InterruptedException -> 0x007f }
                    if (r7 == 0) goto L_0x0064
                    com.jkfantasy.photopoinokia.PhotoFilterPage$ImageLoader$BitmapDisplayer r2 = new com.jkfantasy.photopoinokia.PhotoFilterPage$ImageLoader$BitmapDisplayer     // Catch:{ InterruptedException -> 0x007f }
                    com.jkfantasy.photopoinokia.PhotoFilterPage$ImageLoader r7 = com.jkfantasy.photopoinokia.PhotoFilterPage.ImageLoader.this     // Catch:{ InterruptedException -> 0x007f }
                    android.widget.ImageView r8 = r4.imageView     // Catch:{ InterruptedException -> 0x007f }
                    r2.<init>(r3, r8)     // Catch:{ InterruptedException -> 0x007f }
                    android.widget.ImageView r7 = r4.imageView     // Catch:{ InterruptedException -> 0x007f }
                    android.content.Context r1 = r7.getContext()     // Catch:{ InterruptedException -> 0x007f }
                    android.app.Activity r1 = (android.app.Activity) r1     // Catch:{ InterruptedException -> 0x007f }
                    r1.runOnUiThread(r2)     // Catch:{ InterruptedException -> 0x007f }
                L_0x0064:
                    boolean r7 = java.lang.Thread.interrupted()     // Catch:{ InterruptedException -> 0x007f }
                    if (r7 == 0) goto L_0x0000
                L_0x006a:
                    return
                L_0x006b:
                    com.jkfantasy.photopoinokia.PhotoFilterPage$ImageLoader r7 = com.jkfantasy.photopoinokia.PhotoFilterPage.ImageLoader.this     // Catch:{ all -> 0x007c }
                    com.jkfantasy.photopoinokia.PhotoFilterPage$ImageLoader$PhotosQueue r7 = r7.photosQueue     // Catch:{ all -> 0x007c }
                    java.util.Stack r7 = r7.photosToLoad     // Catch:{ all -> 0x007c }
                    java.lang.Object r7 = r7.pop()     // Catch:{ all -> 0x007c }
                    r0 = r7
                    com.jkfantasy.photopoinokia.PhotoFilterPage$ImageLoader$PhotoToLoad r0 = (com.jkfantasy.photopoinokia.PhotoFilterPage.ImageLoader.PhotoToLoad) r0     // Catch:{ all -> 0x007c }
                    r4 = r0
                    goto L_0x0024
                L_0x007c:
                    r7 = move-exception
                    monitor-exit(r8)     // Catch:{ all -> 0x007c }
                    throw r7     // Catch:{ InterruptedException -> 0x007f }
                L_0x007f:
                    r7 = move-exception
                    goto L_0x006a
                */
                throw new UnsupportedOperationException("Method not decompiled: com.jkfantasy.photopoinokia.PhotoFilterPage.ImageLoader.PhotosLoader.run():void");
            }
        }

        class BitmapDisplayer implements Runnable {
            Bitmap bitmap;
            ImageView imageView;

            public BitmapDisplayer(Bitmap b, ImageView i) {
                this.bitmap = b;
                this.imageView = i;
            }

            public void run() {
                if (this.bitmap != null) {
                    this.imageView.setImageBitmap(this.bitmap);
                } else {
                    this.imageView.setImageResource(R.drawable.gray_16x16);
                }
            }
        }

        public void clearCache() {
            this.memoryCache.clear();
        }
    }

    private class ImageTextAdapter extends BaseAdapter {
        private Activity activity;
        public ImageLoader imageLoader;
        private LayoutInflater layoutInflater;

        public ImageTextAdapter(Context context, Activity a) {
            this.activity = a;
            this.imageLoader = new ImageLoader(this.activity.getApplicationContext());
            this.layoutInflater = (LayoutInflater) context.getSystemService("layout_inflater");
        }

        public int getCount() {
            return PhotoFilterPage.this.mainList.size() + 1;
        }

        public Object getItem(int position) {
            return Integer.valueOf(position);
        }

        public long getItemId(int position) {
            return (long) position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder viewHolder;
            boolean bYellow;
            if (convertView == null) {
                convertView = this.layoutInflater.inflate(R.layout.listview_item, (ViewGroup) null);
                viewHolder = new ViewHolder(PhotoFilterPage.this, (ViewHolder) null);
                viewHolder.textView = (TextView) convertView.findViewById(R.id.lv_textView);
                viewHolder.countView = (TextView) convertView.findViewById(R.id.lv_countView);
                viewHolder.imageView = (ImageView) convertView.findViewById(R.id.lv_imageView);
                viewHolder.radioButton = (RadioButton) convertView.findViewById(R.id.lv_radioButton);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }
            if (position == PhotoFilterPage.this.m_curFolderPosition) {
                viewHolder.radioButton.setChecked(true);
                if (position != 0) {
                    PhotoFilterPage.this.m_curFolderViewHolder = null;
                    PhotoFilterPage.this.m_curFolderViewHolder = viewHolder;
                } else if (parent.getChildCount() == position) {
                    PhotoFilterPage.this.m_curFolderViewHolder = null;
                    PhotoFilterPage.this.m_curFolderViewHolder = viewHolder;
                }
            } else {
                viewHolder.radioButton.setChecked(false);
            }
            if (position == 0) {
                viewHolder.imageView.setImageDrawable(PhotoFilterPage.this.getResources().getDrawable(R.drawable.all_folders));
                viewHolder.textView.setText(PhotoFilterPage.this.getString(R.string.AllFolders));
                viewHolder.countView.setText("(" + PhotoFilterPage.this.total_photoNum_in_all_folders + ")");
                viewHolder.textView.setTextColor(-256);
            } else {
                int mainListPosition = position - 1;
                this.imageLoader.DisplayImage(String.valueOf(mainListPosition), this.activity, viewHolder.imageView);
                String image_bucket_display_name = (String) ((HashMap) PhotoFilterPage.this.mainList.get(mainListPosition)).get("bucket_display_name");
                if (image_bucket_display_name.toLowerCase(Locale.ENGLISH).contains("camera")) {
                    bYellow = true;
                } else if (image_bucket_display_name.equalsIgnoreCase("100MEDIA")) {
                    bYellow = true;
                } else {
                    bYellow = false;
                }
                if (bYellow) {
                    viewHolder.textView.setTextColor(-256);
                } else {
                    viewHolder.textView.setTextColor(-1);
                }
                viewHolder.textView.setText(image_bucket_display_name);
                viewHolder.countView.setText("(" + ((String) ((HashMap) PhotoFilterPage.this.mainList.get(mainListPosition)).get("photo_num")) + ")");
            }
            return convertView;
        }
    }

    /* access modifiers changed from: package-private */
    public void initializeSettings() {
        this.settings = getSharedPreferences("JK.FinalFantasy_PoiPhoto_V1.0.0.ini", 0);
        this.settings_mimeMode = this.settings.getInt("mimeMode", 1);
        this.settings_gpsMode = this.settings.getInt("gpsMode", 0);
        this.settings_folderMode = this.settings.getInt("folderMode", 0);
        this.settings_bucketId = this.settings.getString("bucketId", "");
        this.settings_bucketName = this.settings.getString("bucketName", "");
        this.m_mimeMode = this.settings_mimeMode;
        this.m_gpsMode = this.settings_gpsMode;
        this.m_folderMode = this.settings_folderMode;
        this.m_bucketId = this.settings_bucketId;
        this.m_bucketName = this.settings_bucketName;
    }

    /* access modifiers changed from: package-private */
    public void saveCurrentSettings() {
        this.settings = getSharedPreferences("JK.FinalFantasy_PoiPhoto_V1.0.0.ini", 0);
        this.settings_mimeMode = this.m_mimeMode;
        this.settings_gpsMode = this.m_gpsMode;
        this.settings_folderMode = this.m_folderMode;
        this.settings_bucketId = this.m_bucketId;
        this.settings_bucketName = this.m_bucketName;
        this.settings.edit().putInt("mimeMode", this.settings_mimeMode).putInt("gpsMode", this.settings_gpsMode).putInt("folderMode", this.settings_folderMode).putString("bucketId", this.settings_bucketId).putString("bucketName", this.settings_bucketName).commit();
    }

    /* access modifiers changed from: package-private */
    public void settingToKernel() {
    }

    /* access modifiers changed from: package-private */
    public void uiFolderNameUpdate(int position) {
        if (position == 0) {
            this.m_folderMode = 0;
            this.m_bucketId = "";
            this.m_bucketName = "";
            this.tv_bucket_pre_path.setText("");
            this.tv_bucket_name.setText(getString(R.string.AllFolders));
            return;
        }
        int mainListPosition = position - 1;
        this.m_folderMode = 1;
        this.m_bucketId = (String) this.mainList.get(mainListPosition).get("bucket_id");
        this.m_bucketName = (String) this.mainList.get(mainListPosition).get("bucket_display_name");
        String str_fullPathName = (String) this.mainList.get(mainListPosition).get("data");
        String str_fullFolderName = str_fullPathName.substring(0, str_fullPathName.lastIndexOf(47));
        int posOfPathEnd = str_fullFolderName.lastIndexOf(47);
        this.tv_bucket_pre_path.setText(str_fullFolderName.substring(0, posOfPathEnd + 1));
        this.tv_bucket_name.setText(str_fullFolderName.substring(posOfPathEnd + 1));
    }

    /* access modifiers changed from: package-private */
    public void settingKernelToUI() {
        if (this.m_mimeMode == 0) {
            this.cb_only_select_jpeg.setChecked(false);
        } else {
            this.cb_only_select_jpeg.setChecked(true);
        }
        if (this.m_gpsMode == 0) {
            this.cb_only_select_gps.setChecked(false);
        } else {
            this.cb_only_select_gps.setChecked(true);
        }
        uiFolderNameUpdate(this.m_curFolderPosition);
    }

    /* access modifiers changed from: package-private */
    public void onCompleted() {
        settingToKernel();
        settingKernelToUI();
    }
}
