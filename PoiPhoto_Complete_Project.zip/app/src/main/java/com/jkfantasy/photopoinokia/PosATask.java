package com.jkfantasy.photopoinokia;

import android.os.AsyncTask;

/* compiled from: MainActivity */
class PosATask {
    AsyncTask aTask = null;
    int position = -1;

    PosATask(int position2, AsyncTask aTask2) {
        this.position = position2;
        this.aTask = aTask2;
    }
}
