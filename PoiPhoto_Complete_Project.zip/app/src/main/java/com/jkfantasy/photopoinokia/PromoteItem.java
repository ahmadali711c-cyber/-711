package com.jkfantasy.photopoinokia;

public class PromoteItem {
    String appName;
    int drawableId;
    String packageName;

    public void setAppName(String appName2) {
        this.appName = appName2;
    }

    public String getAppName() {
        return this.appName;
    }

    public void setPackageName(String packageName2) {
        this.packageName = packageName2;
    }

    public String getPackageName() {
        return this.packageName;
    }

    public void setDrawableId(int drawableId2) {
        this.drawableId = drawableId2;
    }

    public int getDrawableId() {
        return this.drawableId;
    }
}
