package com.jkfantasy.photopoinokia;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.widget.ExploreByTouchHelper;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.ImageView;
import android.widget.Scroller;

public class TouchImageView extends ImageView {
    private static final String DEBUG = "DEBUG";
    private static final float SUPER_MAX_MULTIPLIER = 1.25f;
    private static final float SUPER_MIN_MULTIPLIER = 0.75f;
    Bitmap bigBitmap = null;
    /* access modifiers changed from: private */
    public Context context;
    /* access modifiers changed from: private */
    public Fling fling;
    ImageViewPager imageViewPager = null;
    boolean isNeedBigBitmapLoaded = false;
    /* access modifiers changed from: private */
    public float[] m;
    /* access modifiers changed from: private */
    public GestureDetector mGestureDetector;
    /* access modifiers changed from: private */
    public ScaleGestureDetector mScaleDetector;
    TouchImageView mTiv = null;
    private boolean maintainZoomAfterSetImage;
    private float matchViewHeight;
    private float matchViewWidth;
    /* access modifiers changed from: private */
    public Matrix matrix;
    /* access modifiers changed from: private */
    public float maxScale;
    float middleDnScale = 1.4f;
    float middleScale = 1.5f;
    float middleUpScale = 1.6f;
    /* access modifiers changed from: private */
    public float minScale;
    /* access modifiers changed from: private */
    public float normalizedScale;
    private float prevMatchViewHeight;
    private float prevMatchViewWidth;
    private Matrix prevMatrix;
    private int prevViewHeight = 0;
    private int prevViewWidth = 0;
    int realPhotoHeight = 100;
    int realPhotoWidth = 100;
    private boolean setImageCalledRecenterImage;
    Bitmap smallBitmap = null;
    /* access modifiers changed from: private */
    public State state;
    private float superMaxScale;
    private float superMinScale;
    /* access modifiers changed from: private */
    public SwipeMethod swipeMethod = SwipeMethod.WHEN_BOUNDARY;
    /* access modifiers changed from: private */
    public int viewHeight = 0;
    /* access modifiers changed from: private */
    public int viewWidth = 0;

    public enum State {
        NONE,
        DRAG,
        ZOOM,
        FLING,
        ANIMATE_ZOOM
    }

    public enum SwipeMethod {
        WHEN_1X,
        WHEN_BOUNDARY
    }

    /* access modifiers changed from: package-private */
    public void setImageViewPager(ImageViewPager imageViewPager2) {
        this.imageViewPager = imageViewPager2;
    }

    /* access modifiers changed from: package-private */
    public void setSmallBitmap(Bitmap bitmap) {
        this.smallBitmap = bitmap;
    }

    /* access modifiers changed from: package-private */
    public Bitmap getSmallBitmap() {
        return this.smallBitmap;
    }

    /* access modifiers changed from: package-private */
    public void setBigBitmap(Bitmap bitmap) {
        this.bigBitmap = bitmap;
    }

    /* access modifiers changed from: package-private */
    public Bitmap getBigBitmap() {
        return this.bigBitmap;
    }

    /* access modifiers changed from: package-private */
    public void setBigBitmapNeedLoaded(boolean bNeedLoaded) {
        this.isNeedBigBitmapLoaded = bNeedLoaded;
    }

    /* access modifiers changed from: package-private */
    public boolean getBigBitmapNeedLoaded() {
        return this.isNeedBigBitmapLoaded;
    }

    /* access modifiers changed from: package-private */
    public void setTo1X() {
        if (this.normalizedScale > this.minScale) {
            this.normalizedScale = this.minScale;
            fitImageToView();
        }
    }

    /* access modifiers changed from: package-private */
    public void setFlag1X() {
        this.normalizedScale = this.minScale;
    }

    /* access modifiers changed from: package-private */
    public void setRealPhotoWidth(int width) {
        this.realPhotoWidth = width;
    }

    /* access modifiers changed from: package-private */
    public void setRealPhotoHeight(int height) {
        this.realPhotoHeight = height;
    }

    /* access modifiers changed from: package-private */
    public void calcMaxScale() {
        if (this.viewWidth != 0 && this.viewHeight != 0) {
            this.maxScale = Math.max(((float) this.realPhotoWidth) / ((float) this.viewWidth), ((float) this.realPhotoHeight) / ((float) this.viewHeight));
            if (this.maxScale < 4.0f) {
                this.maxScale = 4.0f;
            }
            this.superMaxScale = SUPER_MAX_MULTIPLIER * this.maxScale;
            this.middleScale = (float) Math.sqrt((double) this.maxScale);
            this.middleUpScale = this.middleScale + 0.1f;
            this.middleDnScale = this.middleScale - 0.1f;
        }
    }

    public TouchImageView(Context context2) {
        super(context2);
        sharedConstructing(context2);
    }

    public TouchImageView(Context context2, AttributeSet attrs) {
        super(context2, attrs);
        sharedConstructing(context2);
    }

    public TouchImageView(Context context2, AttributeSet attrs, int defStyle) {
        super(context2, attrs, defStyle);
        sharedConstructing(context2);
    }

    private void sharedConstructing(Context context2) {
        super.setClickable(true);
        this.context = context2;
        this.mTiv = this;
        this.mScaleDetector = new ScaleGestureDetector(context2, new ScaleListener(this, (ScaleListener) null));
        this.mGestureDetector = new GestureDetector(context2, new GestureListener(this, (GestureListener) null));
        this.matrix = new Matrix();
        this.prevMatrix = new Matrix();
        this.m = new float[9];
        this.normalizedScale = 1.0f;
        this.minScale = 1.0f;
        this.maxScale = 3.0f;
        this.superMinScale = SUPER_MIN_MULTIPLIER * this.minScale;
        this.superMaxScale = SUPER_MAX_MULTIPLIER * this.maxScale;
        this.maintainZoomAfterSetImage = true;
        setImageMatrix(this.matrix);
        setScaleType(ImageView.ScaleType.MATRIX);
        setState(State.NONE);
        setOnTouchListener(new TouchImageViewListener(this, (TouchImageViewListener) null));
    }

    public void setImageResource(int resId) {
        super.setImageResource(resId);
        calcMaxScale();
        setImageCalled();
        savePreviousImageValues();
        fitImageToView();
    }

    public void setImageBitmap(Bitmap bm) {
        super.setImageBitmap(bm);
        calcMaxScale();
        setImageCalled();
        savePreviousImageValues();
        fitImageToView();
    }

    public void setImageDrawable(Drawable drawable) {
        super.setImageDrawable(drawable);
        calcMaxScale();
        setImageCalled();
        savePreviousImageValues();
        fitImageToView();
    }

    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        calcMaxScale();
        setImageCalled();
        savePreviousImageValues();
        fitImageToView();
    }

    private void setImageCalled() {
        if (!this.maintainZoomAfterSetImage) {
            this.setImageCalledRecenterImage = true;
        }
    }

    private void savePreviousImageValues() {
        if (this.matrix != null) {
            this.matrix.getValues(this.m);
            this.prevMatrix.setValues(this.m);
            this.prevMatchViewHeight = this.matchViewHeight;
            this.prevMatchViewWidth = this.matchViewWidth;
            this.prevViewHeight = this.viewHeight;
            this.prevViewWidth = this.viewWidth;
        }
    }

    public Parcelable onSaveInstanceState() {
        Bundle bundle = new Bundle();
        bundle.putParcelable("instanceState", super.onSaveInstanceState());
        bundle.putFloat("saveScale", this.normalizedScale);
        bundle.putFloat("matchViewHeight", this.matchViewHeight);
        bundle.putFloat("matchViewWidth", this.matchViewWidth);
        bundle.putInt("viewWidth", this.viewWidth);
        bundle.putInt("viewHeight", this.viewHeight);
        this.matrix.getValues(this.m);
        bundle.putFloatArray("matrix", this.m);
        return bundle;
    }

    public void onRestoreInstanceState(Parcelable state2) {
        if (state2 instanceof Bundle) {
            Bundle bundle = (Bundle) state2;
            this.normalizedScale = bundle.getFloat("saveScale");
            this.m = bundle.getFloatArray("matrix");
            this.prevMatrix.setValues(this.m);
            this.prevMatchViewHeight = bundle.getFloat("matchViewHeight");
            this.prevMatchViewWidth = bundle.getFloat("matchViewWidth");
            this.prevViewHeight = bundle.getInt("viewHeight");
            this.prevViewWidth = bundle.getInt("viewWidth");
            super.onRestoreInstanceState(bundle.getParcelable("instanceState"));
            return;
        }
        super.onRestoreInstanceState(state2);
    }

    public float getMaxZoom() {
        return this.maxScale;
    }

    public void setMaxZoom(float max) {
        this.maxScale = max;
        this.superMaxScale = SUPER_MAX_MULTIPLIER * this.maxScale;
    }

    public float getMinZoom() {
        return this.minScale;
    }

    public void maintainZoomAfterSetImage(boolean maintainZoom) {
        this.maintainZoomAfterSetImage = maintainZoom;
    }

    public float getCurrentZoom() {
        return this.normalizedScale;
    }

    public void setMinZoom(float min) {
        this.minScale = min;
        this.superMinScale = SUPER_MIN_MULTIPLIER * this.minScale;
    }

    public PointF getDrawablePointFromTouchPoint(float x, float y) {
        return transformCoordTouchToBitmap(x, y, true);
    }

    public PointF getDrawablePointFromTouchPoint(PointF p) {
        return transformCoordTouchToBitmap(p.x, p.y, true);
    }

    /* access modifiers changed from: private */
    public void fixTrans() {
        this.matrix.getValues(this.m);
        float transX = this.m[2];
        float transY = this.m[5];
        float fixTransX = getFixTrans(transX, (float) this.viewWidth, getImageWidth());
        float fixTransY = getFixTrans(transY, (float) this.viewHeight, getImageHeight());
        if (this.swipeMethod == SwipeMethod.WHEN_BOUNDARY && (fixTransX != 0.0f || getImageWidth() <= ((float) this.viewWidth))) {
            this.imageViewPager.setSwipe(true);
        }
        if (fixTransX != 0.0f || fixTransY != 0.0f) {
            this.matrix.postTranslate(fixTransX, fixTransY);
        }
    }

    /* access modifiers changed from: private */
    public void fixScaleTrans() {
        fixTrans();
        this.matrix.getValues(this.m);
        if (getImageWidth() < ((float) this.viewWidth)) {
            this.m[2] = (((float) this.viewWidth) - getImageWidth()) / 2.0f;
        }
        if (getImageHeight() < ((float) this.viewHeight)) {
            this.m[5] = (((float) this.viewHeight) - getImageHeight()) / 2.0f;
        }
        this.matrix.setValues(this.m);
    }

    private float getFixTrans(float trans, float viewSize, float contentSize) {
        float minTrans;
        float maxTrans;
        if (contentSize <= viewSize) {
            minTrans = 0.0f;
            maxTrans = viewSize - contentSize;
        } else {
            minTrans = viewSize - contentSize;
            maxTrans = 0.0f;
        }
        if (trans < minTrans) {
            return (-trans) + minTrans;
        }
        if (trans > maxTrans) {
            return (-trans) + maxTrans;
        }
        return 0.0f;
    }

    /* access modifiers changed from: private */
    public float getFixDragTrans(float delta, float viewSize, float contentSize) {
        if (contentSize <= viewSize) {
            return 0.0f;
        }
        return delta;
    }

    /* access modifiers changed from: private */
    public float getImageWidth() {
        return this.matchViewWidth * this.normalizedScale;
    }

    /* access modifiers changed from: private */
    public float getImageHeight() {
        return this.matchViewHeight * this.normalizedScale;
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        Drawable drawable = getDrawable();
        if (drawable == null || drawable.getIntrinsicWidth() == 0 || drawable.getIntrinsicHeight() == 0) {
            setMeasuredDimension(0, 0);
            return;
        }
        int drawableWidth = drawable.getIntrinsicWidth();
        int drawableHeight = drawable.getIntrinsicHeight();
        int widthSize = View.MeasureSpec.getSize(widthMeasureSpec);
        int widthMode = View.MeasureSpec.getMode(widthMeasureSpec);
        int heightSize = View.MeasureSpec.getSize(heightMeasureSpec);
        int heightMode = View.MeasureSpec.getMode(heightMeasureSpec);
        this.viewWidth = setViewSize(widthMode, widthSize, drawableWidth);
        this.viewHeight = setViewSize(heightMode, heightSize, drawableHeight);
        setMeasuredDimension(this.viewWidth, this.viewHeight);
        fitImageToView();
    }

    private void fitImageToView() {
        Drawable drawable = getDrawable();
        if (drawable != null && drawable.getIntrinsicWidth() != 0 && drawable.getIntrinsicHeight() != 0 && this.matrix != null && this.prevMatrix != null) {
            int drawableWidth = drawable.getIntrinsicWidth();
            int drawableHeight = drawable.getIntrinsicHeight();
            float scale = Math.min(((float) this.viewWidth) / ((float) drawableWidth), ((float) this.viewHeight) / ((float) drawableHeight));
            float redundantYSpace = ((float) this.viewHeight) - (((float) drawableHeight) * scale);
            float redundantXSpace = ((float) this.viewWidth) - (((float) drawableWidth) * scale);
            this.matchViewWidth = ((float) this.viewWidth) - redundantXSpace;
            this.matchViewHeight = ((float) this.viewHeight) - redundantYSpace;
            if (this.normalizedScale == 1.0f || this.setImageCalledRecenterImage) {
                this.matrix.setScale(scale, scale);
                this.matrix.postTranslate(redundantXSpace / 2.0f, redundantYSpace / 2.0f);
                this.normalizedScale = 1.0f;
                this.setImageCalledRecenterImage = false;
            } else {
                this.prevMatrix.getValues(this.m);
                this.m[0] = (this.matchViewWidth / ((float) drawableWidth)) * this.normalizedScale;
                this.m[4] = (this.matchViewHeight / ((float) drawableHeight)) * this.normalizedScale;
                float transX = this.m[2];
                float transY = this.m[5];
                translateMatrixAfterRotate(2, transX, this.prevMatchViewWidth * this.normalizedScale, getImageWidth(), this.prevViewWidth, this.viewWidth, drawableWidth);
                translateMatrixAfterRotate(5, transY, this.prevMatchViewHeight * this.normalizedScale, getImageHeight(), this.prevViewHeight, this.viewHeight, drawableHeight);
                this.matrix.setValues(this.m);
            }
            setImageMatrix(this.matrix);
        }
    }

    private int setViewSize(int mode, int size, int drawableWidth) {
        switch (mode) {
            case ExploreByTouchHelper.INVALID_ID:
                return Math.min(drawableWidth, size);
            case 0:
                return drawableWidth;
            case 1073741824:
                return size;
            default:
                return size;
        }
    }

    private void translateMatrixAfterRotate(int axis, float trans, float prevImageSize, float imageSize, int prevViewSize, int viewSize, int drawableSize) {
        if (imageSize < ((float) viewSize)) {
            this.m[axis] = (((float) viewSize) - (((float) drawableSize) * this.m[0])) * 0.5f;
        } else if (trans > 0.0f) {
            this.m[axis] = -((imageSize - ((float) viewSize)) * 0.5f);
        } else {
            this.m[axis] = -((((Math.abs(trans) + (((float) prevViewSize) * 0.5f)) / prevImageSize) * imageSize) - (((float) viewSize) * 0.5f));
        }
    }

    /* access modifiers changed from: private */
    public void setState(State state2) {
        this.state = state2;
    }

    private class GestureListener extends GestureDetector.SimpleOnGestureListener {
        private GestureListener() {
        }

        /* synthetic */ GestureListener(TouchImageView touchImageView, GestureListener gestureListener) {
            this();
        }

        public boolean onSingleTapConfirmed(MotionEvent e) {
            return TouchImageView.this.performClick();
        }

        public void onLongPress(MotionEvent e) {
            TouchImageView.this.performLongClick();
        }

        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
            if (TouchImageView.this.fling != null) {
                TouchImageView.this.fling.cancelFling();
            }
            TouchImageView.this.fling = new Fling((int) velocityX, (int) velocityY);
            TouchImageView.this.compatPostOnAnimation(TouchImageView.this.fling);
            return super.onFling(e1, e2, velocityX, velocityY);
        }

        public boolean onDoubleTap(MotionEvent e) {
            float targetZoom;
            if (TouchImageView.this.state != State.NONE) {
                return false;
            }
            if (TouchImageView.this.normalizedScale <= TouchImageView.this.middleUpScale + 0.1f && TouchImageView.this.normalizedScale >= TouchImageView.this.middleScale) {
                targetZoom = TouchImageView.this.maxScale;
            } else if (TouchImageView.this.normalizedScale < TouchImageView.this.middleScale && TouchImageView.this.normalizedScale >= TouchImageView.this.middleDnScale - 0.1f) {
                targetZoom = TouchImageView.this.minScale;
            } else if (TouchImageView.this.normalizedScale >= TouchImageView.this.minScale && ((double) TouchImageView.this.normalizedScale) <= ((double) TouchImageView.this.minScale) + 0.1d) {
                targetZoom = TouchImageView.this.middleUpScale;
            } else if (TouchImageView.this.normalizedScale > TouchImageView.this.maxScale || ((double) TouchImageView.this.normalizedScale) < ((double) TouchImageView.this.maxScale) - 0.1d) {
                targetZoom = TouchImageView.this.minScale;
            } else {
                targetZoom = TouchImageView.this.middleDnScale;
            }
            if (TouchImageView.this.swipeMethod == SwipeMethod.WHEN_1X) {
                if (targetZoom <= TouchImageView.this.minScale) {
                    TouchImageView.this.imageViewPager.setSwipe(true);
                } else {
                    TouchImageView.this.imageViewPager.setSwipe(false);
                }
            }
            TouchImageView.this.compatPostOnAnimation(new DoubleTapZoom(targetZoom, e.getX(), e.getY(), false));
            return true;
        }
    }

    private class TouchImageViewListener implements View.OnTouchListener {
        private PointF last;

        private TouchImageViewListener() {
            this.last = new PointF();
        }

        /* synthetic */ TouchImageViewListener(TouchImageView touchImageView, TouchImageViewListener touchImageViewListener) {
            this();
        }

        public boolean onTouch(View v, MotionEvent event) {
            if (TouchImageView.this.swipeMethod == SwipeMethod.WHEN_BOUNDARY && event.getAction() == 0) {
                TouchImageView.this.imageViewPager.setSwipe(false);
            }
            TouchImageView.this.mScaleDetector.onTouchEvent(event);
            TouchImageView.this.mGestureDetector.onTouchEvent(event);
            PointF curr = new PointF(event.getX(), event.getY());
            if (TouchImageView.this.state == State.NONE || TouchImageView.this.state == State.DRAG || TouchImageView.this.state == State.FLING) {
                switch (event.getAction()) {
                    case 0:
                        this.last.set(curr);
                        if (TouchImageView.this.fling != null) {
                            TouchImageView.this.fling.cancelFling();
                        }
                        TouchImageView.this.setState(State.DRAG);
                        break;
                    case 1:
                    case 6:
                        TouchImageView.this.setState(State.NONE);
                        break;
                    case 2:
                        if (TouchImageView.this.state == State.DRAG) {
                            float deltaX = curr.x - this.last.x;
                            float deltaY = curr.y - this.last.y;
                            float fixTransX = TouchImageView.this.getFixDragTrans(deltaX, (float) TouchImageView.this.viewWidth, TouchImageView.this.getImageWidth());
                            float fixTransY = TouchImageView.this.getFixDragTrans(deltaY, (float) TouchImageView.this.viewHeight, TouchImageView.this.getImageHeight());
                            if (TouchImageView.this.swipeMethod == SwipeMethod.WHEN_BOUNDARY) {
                                if (TouchImageView.this.normalizedScale <= TouchImageView.this.minScale) {
                                    TouchImageView.this.imageViewPager.setSwipe(true);
                                } else {
                                    TouchImageView.this.imageViewPager.setSwipe(false);
                                }
                            }
                            TouchImageView.this.matrix.postTranslate(fixTransX, fixTransY);
                            TouchImageView.this.fixTrans();
                            this.last.set(curr.x, curr.y);
                            break;
                        }
                        break;
                }
            }
            TouchImageView.this.setImageMatrix(TouchImageView.this.matrix);
            return true;
        }
    }

    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        private ScaleListener() {
        }

        /* synthetic */ ScaleListener(TouchImageView touchImageView, ScaleListener scaleListener) {
            this();
        }

        public boolean onScaleBegin(ScaleGestureDetector detector) {
            TouchImageView.this.setState(State.ZOOM);
            return true;
        }

        public boolean onScale(ScaleGestureDetector detector) {
            TouchImageView.this.scaleImage(detector.getScaleFactor(), detector.getFocusX(), detector.getFocusY(), true);
            return true;
        }

        public void onScaleEnd(ScaleGestureDetector detector) {
            super.onScaleEnd(detector);
            TouchImageView.this.setState(State.NONE);
            boolean animateToZoomBoundary = false;
            float targetZoom = TouchImageView.this.normalizedScale;
            if (TouchImageView.this.normalizedScale > TouchImageView.this.maxScale) {
                targetZoom = TouchImageView.this.maxScale;
                animateToZoomBoundary = true;
            } else if (TouchImageView.this.normalizedScale < TouchImageView.this.minScale) {
                targetZoom = TouchImageView.this.minScale;
                animateToZoomBoundary = true;
            }
            if (TouchImageView.this.swipeMethod == SwipeMethod.WHEN_1X) {
                if (TouchImageView.this.normalizedScale <= TouchImageView.this.minScale) {
                    TouchImageView.this.imageViewPager.setSwipe(true);
                } else {
                    TouchImageView.this.imageViewPager.setSwipe(false);
                }
            }
            if (animateToZoomBoundary) {
                TouchImageView.this.compatPostOnAnimation(new DoubleTapZoom(targetZoom, (float) (TouchImageView.this.viewWidth / 2), (float) (TouchImageView.this.viewHeight / 2), true));
            }
        }
    }

    /* access modifiers changed from: private */
    public void scaleImage(float deltaScale, float focusX, float focusY, boolean stretchImageToSuper) {
        float lowerScale;
        float upperScale;
        if (stretchImageToSuper) {
            lowerScale = this.superMinScale;
            upperScale = this.superMaxScale;
        } else {
            lowerScale = this.minScale;
            upperScale = this.maxScale;
        }
        float origScale = this.normalizedScale;
        this.normalizedScale *= deltaScale;
        if (this.normalizedScale > upperScale) {
            this.normalizedScale = upperScale;
            deltaScale = upperScale / origScale;
        } else if (this.normalizedScale < lowerScale) {
            this.normalizedScale = lowerScale;
            deltaScale = lowerScale / origScale;
        }
        this.matrix.postScale(deltaScale, deltaScale, focusX, focusY);
        fixScaleTrans();
    }

    private class DoubleTapZoom implements Runnable {
        private static final float ZOOM_TIME = 200.0f;
        private float bitmapX;
        private float bitmapY;
        private PointF endTouch;
        private AccelerateDecelerateInterpolator interpolator = new AccelerateDecelerateInterpolator();
        private long startTime;
        private PointF startTouch;
        private float startZoom;
        private boolean stretchImageToSuper;
        private float targetZoom;

        DoubleTapZoom(float targetZoom2, float focusX, float focusY, boolean stretchImageToSuper2) {
            TouchImageView.this.setState(State.ANIMATE_ZOOM);
            this.startTime = System.currentTimeMillis();
            this.startZoom = TouchImageView.this.normalizedScale;
            this.targetZoom = targetZoom2;
            this.stretchImageToSuper = stretchImageToSuper2;
            PointF bitmapPoint = TouchImageView.this.transformCoordTouchToBitmap(focusX, focusY, false);
            this.bitmapX = bitmapPoint.x;
            this.bitmapY = bitmapPoint.y;
            this.startTouch = TouchImageView.this.transformCoordBitmapToTouch(this.bitmapX, this.bitmapY);
            this.endTouch = new PointF((float) (TouchImageView.this.viewWidth / 2), (float) (TouchImageView.this.viewHeight / 2));
        }

        public void run() {
            float t = interpolate();
            TouchImageView.this.scaleImage(calculateDeltaScale(t), this.bitmapX, this.bitmapY, this.stretchImageToSuper);
            translateImageToCenterTouchPosition(t);
            TouchImageView.this.fixScaleTrans();
            TouchImageView.this.setImageMatrix(TouchImageView.this.matrix);
            if (t < 1.0f) {
                TouchImageView.this.compatPostOnAnimation(this);
            } else {
                TouchImageView.this.setState(State.NONE);
            }
        }

        private void translateImageToCenterTouchPosition(float t) {
            float targetX = this.startTouch.x + ((this.endTouch.x - this.startTouch.x) * t);
            float targetY = this.startTouch.y + ((this.endTouch.y - this.startTouch.y) * t);
            PointF curr = TouchImageView.this.transformCoordBitmapToTouch(this.bitmapX, this.bitmapY);
            TouchImageView.this.matrix.postTranslate(targetX - curr.x, targetY - curr.y);
        }

        private float interpolate() {
            return this.interpolator.getInterpolation(Math.min(1.0f, ((float) (System.currentTimeMillis() - this.startTime)) / ZOOM_TIME));
        }

        private float calculateDeltaScale(float t) {
            return (this.startZoom + ((this.targetZoom - this.startZoom) * t)) / TouchImageView.this.normalizedScale;
        }
    }

    /* access modifiers changed from: private */
    public PointF transformCoordTouchToBitmap(float x, float y, boolean clipToBitmap) {
        this.matrix.getValues(this.m);
        float origW = (float) getDrawable().getIntrinsicWidth();
        float origH = (float) getDrawable().getIntrinsicHeight();
        float transX = this.m[2];
        float transY = this.m[5];
        float finalX = ((x - transX) * origW) / getImageWidth();
        float finalY = ((y - transY) * origH) / getImageHeight();
        if (clipToBitmap) {
            finalX = Math.min(Math.max(x, 0.0f), origW);
            finalY = Math.min(Math.max(y, 0.0f), origH);
        }
        return new PointF(finalX, finalY);
    }

    /* access modifiers changed from: private */
    public PointF transformCoordBitmapToTouch(float bx, float by) {
        this.matrix.getValues(this.m);
        float origW = (float) getDrawable().getIntrinsicWidth();
        return new PointF(this.m[2] + (getImageWidth() * (bx / origW)), this.m[5] + (getImageHeight() * (by / ((float) getDrawable().getIntrinsicHeight()))));
    }

    private class Fling implements Runnable {
        int currX;
        int currY;
        Scroller scroller;

        Fling(int velocityX, int velocityY) {
            int maxX;
            int minX;
            int maxY;
            int minY;
            TouchImageView.this.setState(State.FLING);
            this.scroller = new Scroller(TouchImageView.this.context);
            TouchImageView.this.matrix.getValues(TouchImageView.this.m);
            int startX = (int) TouchImageView.this.m[2];
            int startY = (int) TouchImageView.this.m[5];
            if (TouchImageView.this.getImageWidth() > ((float) TouchImageView.this.viewWidth)) {
                minX = TouchImageView.this.viewWidth - ((int) TouchImageView.this.getImageWidth());
                maxX = 0;
            } else {
                maxX = startX;
                minX = startX;
            }
            if (TouchImageView.this.getImageHeight() > ((float) TouchImageView.this.viewHeight)) {
                minY = TouchImageView.this.viewHeight - ((int) TouchImageView.this.getImageHeight());
                maxY = 0;
            } else {
                maxY = startY;
                minY = startY;
            }
            this.scroller.fling(startX, startY, velocityX, velocityY, minX, maxX, minY, maxY);
            this.currX = startX;
            this.currY = startY;
        }

        public void cancelFling() {
            if (this.scroller != null) {
                TouchImageView.this.setState(State.NONE);
                this.scroller.forceFinished(true);
            }
        }

        public void run() {
            if (this.scroller.isFinished()) {
                this.scroller = null;
            } else if (this.scroller.computeScrollOffset()) {
                int newX = this.scroller.getCurrX();
                int newY = this.scroller.getCurrY();
                int transX = newX - this.currX;
                int transY = newY - this.currY;
                this.currX = newX;
                this.currY = newY;
                TouchImageView.this.matrix.postTranslate((float) transX, (float) transY);
                TouchImageView.this.fixTrans();
                TouchImageView.this.setImageMatrix(TouchImageView.this.matrix);
                TouchImageView.this.compatPostOnAnimation(this);
            }
        }
    }

    /* access modifiers changed from: private */
    @TargetApi(16)
    public void compatPostOnAnimation(Runnable runnable) {
        if (Build.VERSION.SDK_INT >= 16) {
            postOnAnimation(runnable);
        } else {
            postDelayed(runnable, 16);
        }
    }

    private void printMatrixInfo() {
        this.matrix.getValues(this.m);
        Log.d(DEBUG, "Scale: " + this.m[0] + " TransX: " + this.m[2] + " TransY: " + this.m[5]);
    }
}
