package com.jkfantasy.photopoinokia;

/* compiled from: MainActivity */
class WHICH_PUBLISH_MARKET {
    static int AMAZON = 3;
    static int GOOGLE = 1;
    static int NORMAL = 0;
    static int SAMSUNG = 2;

    WHICH_PUBLISH_MARKET() {
    }
}
