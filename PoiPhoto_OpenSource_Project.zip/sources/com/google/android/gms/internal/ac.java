package com.google.android.gms.internal;

public interface ac {
    void a(af afVar, boolean z);
}
