package com.google.android.gms.internal;

import org.json.JSONObject;

public interface ah {

    public interface a {
        void aR();
    }

    void a(a aVar);

    void a(t tVar, ds dsVar, cb cbVar, dv dvVar, boolean z, ce ceVar);

    void a(String str, cd cdVar);

    void a(String str, JSONObject jSONObject);

    void destroy();

    void f(String str);

    void g(String str);

    void pause();

    void resume();
}
