package com.google.android.gms.internal;

import android.util.Base64OutputStream;
import com.google.android.gms.internal.as;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Locale;
import java.util.PriorityQueue;

public class ap {
    private final int nT;
    private final int nU;
    private final ao nV = new ar();
    private Base64OutputStream nW;
    private ByteArrayOutputStream nX;

    public ap(int i) {
        this.nU = i;
        this.nT = 6;
    }

    private String m(String str) {
        String[] split = str.split("\n");
        if (split == null || split.length == 0) {
            return "";
        }
        this.nX = new ByteArrayOutputStream();
        this.nW = new Base64OutputStream(this.nX, 10);
        Arrays.sort(split, new Comparator<String>() {
            public int compare(String s1, String s2) {
                return s2.length() - s1.length();
            }
        });
        int i = 0;
        while (i < split.length && i < this.nU) {
            if (split[i].trim().length() != 0) {
                try {
                    this.nW.write(this.nV.l(split[i]));
                } catch (IOException e) {
                    gr.b("Error while writing hash to byteStream", e);
                }
            }
            i++;
        }
        try {
            this.nW.flush();
            this.nW.close();
            return this.nX.toString();
        } catch (IOException e2) {
            gr.b("HashManager: Unable to convert to base 64", e2);
            return "";
        }
    }

    public String a(ArrayList<String> arrayList) {
        StringBuffer stringBuffer = new StringBuffer();
        Iterator<String> it = arrayList.iterator();
        while (it.hasNext()) {
            stringBuffer.append(it.next().toLowerCase(Locale.US));
            stringBuffer.append(10);
        }
        switch (0) {
            case 0:
                return n(stringBuffer.toString());
            case 1:
                return m(stringBuffer.toString());
            default:
                return "";
        }
    }

    /* access modifiers changed from: package-private */
    public String n(String str) {
        String[] split = str.split("\n");
        if (split == null || split.length == 0) {
            return "";
        }
        this.nX = new ByteArrayOutputStream();
        this.nW = new Base64OutputStream(this.nX, 10);
        PriorityQueue priorityQueue = new PriorityQueue(this.nU, new Comparator<as.a>() {
            /* renamed from: a */
            public int compare(as.a aVar, as.a aVar2) {
                return (int) (aVar.value - aVar2.value);
            }
        });
        for (String p : split) {
            String[] p2 = aq.p(p);
            if (p2.length >= this.nT) {
                as.a(p2, this.nU, this.nT, (PriorityQueue<as.a>) priorityQueue);
            }
        }
        Iterator it = priorityQueue.iterator();
        while (it.hasNext()) {
            try {
                this.nW.write(this.nV.l(((as.a) it.next()).oa));
            } catch (IOException e) {
                gr.b("Error while writing hash to byteStream", e);
            }
        }
        try {
            this.nW.flush();
            this.nW.close();
            return this.nX.toString();
        } catch (IOException e2) {
            gr.b("HashManager: unable to convert to base 64", e2);
            return "";
        }
    }
}
