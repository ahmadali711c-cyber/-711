package com.google.android.gms.internal;

import com.google.android.gms.ads.doubleclick.a;

@ey
public class bp implements a {
    private final bq pA;

    public bp(bq bqVar) {
        this.pA = bqVar;
    }
}
