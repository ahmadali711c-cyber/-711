package com.google.android.gms.internal;

import android.os.IInterface;
import android.os.RemoteException;

public interface bz extends IInterface {
    void a(bx bxVar) throws RemoteException;
}
