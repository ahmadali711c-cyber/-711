package com.google.android.gms.internal;

import java.util.ArrayList;

public interface ce {
    void a(String str, ArrayList<String> arrayList);
}
