package com.google.android.gms.internal;

public interface cg {
    void d(boolean z);
}
