package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

@ey
public final class ci implements cd {
    private final ce qc;
    private final v qd;

    public ci(ce ceVar, v vVar) {
        this.qc = ceVar;
        this.qd = vVar;
    }

    private static boolean b(Map<String, String> map) {
        return "1".equals(map.get("custom_close"));
    }

    private static int c(Map<String, String> map) {
        String str = map.get("o");
        if (str != null) {
            if ("p".equalsIgnoreCase(str)) {
                return gi.dv();
            }
            if ("l".equalsIgnoreCase(str)) {
                return gi.du();
            }
        }
        return -1;
    }

    public void a(gu guVar, Map<String, String> map) {
        String str = map.get("a");
        if (str == null) {
            gr.W("Action missing from an open GMSG.");
        } else if (this.qd == null || this.qd.az()) {
            gv dD = guVar.dD();
            if ("expand".equalsIgnoreCase(str)) {
                if (guVar.dH()) {
                    gr.W("Cannot expand WebView that is already expanded.");
                } else {
                    dD.a(b(map), c(map));
                }
            } else if ("webapp".equalsIgnoreCase(str)) {
                String str2 = map.get("u");
                if (str2 != null) {
                    dD.a(b(map), c(map), str2);
                } else {
                    dD.a(b(map), c(map), map.get("html"), map.get("baseurl"));
                }
            } else if ("in_app_purchase".equalsIgnoreCase(str)) {
                String str3 = map.get("product_id");
                String str4 = map.get("report_urls");
                if (this.qc == null) {
                    return;
                }
                if (str4 == null || str4.isEmpty()) {
                    this.qc.a(str3, new ArrayList());
                    return;
                }
                this.qc.a(str3, new ArrayList(Arrays.asList(str4.split(" "))));
            } else {
                dD.a(new Cdo(map.get("i"), map.get("u"), map.get("m"), map.get("p"), map.get("c"), map.get("f"), map.get("e")));
            }
        } else {
            this.qd.d(map.get("u"));
        }
    }
}
