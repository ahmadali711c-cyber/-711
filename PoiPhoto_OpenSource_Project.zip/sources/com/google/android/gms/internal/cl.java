package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.IBinder;
import android.os.RemoteException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.internal.cm;
import com.google.android.gms.internal.jl;

@ey
public class cl extends jl<cm> {
    final int qg;

    public cl(Context context, GoogleApiClient.ConnectionCallbacks connectionCallbacks, GoogleApiClient.OnConnectionFailedListener onConnectionFailedListener, int i) {
        super(context, context.getMainLooper(), connectionCallbacks, onConnectionFailedListener, new String[0]);
        this.qg = i;
    }

    /* access modifiers changed from: protected */
    public void a(jt jtVar, jl.e eVar) throws RemoteException {
        jtVar.g(eVar, this.qg, getContext().getPackageName(), new Bundle());
    }

    /* access modifiers changed from: protected */
    public String bK() {
        return "com.google.android.gms.ads.gservice.START";
    }

    /* access modifiers changed from: protected */
    public String bL() {
        return "com.google.android.gms.ads.internal.gservice.IGservicesValueService";
    }

    public cm bM() throws DeadObjectException {
        return (cm) super.hw();
    }

    /* access modifiers changed from: protected */
    /* renamed from: k */
    public cm l(IBinder iBinder) {
        return cm.a.m(iBinder);
    }
}
