package com.google.android.gms.internal;

import android.location.Location;

public interface cn {
    Location a(long j);

    void init();
}
