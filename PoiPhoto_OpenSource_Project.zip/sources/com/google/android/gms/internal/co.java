package com.google.android.gms.internal;

import android.location.Location;

@ey
public final class co implements cn {
    public Location a(long j) {
        return null;
    }

    public void init() {
    }
}
