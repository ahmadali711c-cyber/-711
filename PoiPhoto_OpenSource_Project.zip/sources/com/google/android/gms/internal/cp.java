package com.google.android.gms.internal;

import android.content.Context;

@ey
public final class cp {
    private final cy lA;
    private final Context mContext;
    private final Object mH = new Object();
    private final fh qh;
    private final cr qi;
    private boolean qj = false;
    private cu qk;

    public cp(Context context, fh fhVar, cy cyVar, cr crVar) {
        this.mContext = context;
        this.qh = fhVar;
        this.lA = cyVar;
        this.qi = crVar;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0080, code lost:
        r4 = r16.qk.b(r17, r19);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x008e, code lost:
        if (r4.qO != 0) goto L_0x0099;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0090, code lost:
        com.google.android.gms.internal.gr.S("Adapter succeeded.");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x009b, code lost:
        if (r4.qQ == null) goto L_0x0039;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x009d, code lost:
        com.google.android.gms.internal.gq.wR.post(new com.google.android.gms.internal.cp.AnonymousClass1(r16));
     */
    /* JADX WARNING: Code restructure failed: missing block: B:38:?, code lost:
        return r4;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public com.google.android.gms.internal.cv a(long r17, long r19) {
        /*
            r16 = this;
            java.lang.String r4 = "Starting mediation."
            com.google.android.gms.internal.gr.S(r4)
            r0 = r16
            com.google.android.gms.internal.cr r4 = r0.qi
            java.util.List<com.google.android.gms.internal.cq> r4 = r4.qu
            java.util.Iterator r13 = r4.iterator()
        L_0x000f:
            boolean r4 = r13.hasNext()
            if (r4 == 0) goto L_0x00aa
            java.lang.Object r9 = r13.next()
            com.google.android.gms.internal.cq r9 = (com.google.android.gms.internal.cq) r9
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            java.lang.String r5 = "Trying mediation network: "
            java.lang.StringBuilder r4 = r4.append(r5)
            java.lang.String r5 = r9.qo
            java.lang.StringBuilder r4 = r4.append(r5)
            java.lang.String r4 = r4.toString()
            com.google.android.gms.internal.gr.U(r4)
            java.util.List<java.lang.String> r4 = r9.qp
            java.util.Iterator r14 = r4.iterator()
        L_0x0039:
            boolean r4 = r14.hasNext()
            if (r4 == 0) goto L_0x000f
            java.lang.Object r6 = r14.next()
            java.lang.String r6 = (java.lang.String) r6
            r0 = r16
            java.lang.Object r15 = r0.mH
            monitor-enter(r15)
            r0 = r16
            boolean r4 = r0.qj     // Catch:{ all -> 0x0096 }
            if (r4 == 0) goto L_0x0058
            com.google.android.gms.internal.cv r4 = new com.google.android.gms.internal.cv     // Catch:{ all -> 0x0096 }
            r5 = -1
            r4.<init>(r5)     // Catch:{ all -> 0x0096 }
            monitor-exit(r15)     // Catch:{ all -> 0x0096 }
        L_0x0057:
            return r4
        L_0x0058:
            com.google.android.gms.internal.cu r4 = new com.google.android.gms.internal.cu     // Catch:{ all -> 0x0096 }
            r0 = r16
            android.content.Context r5 = r0.mContext     // Catch:{ all -> 0x0096 }
            r0 = r16
            com.google.android.gms.internal.cy r7 = r0.lA     // Catch:{ all -> 0x0096 }
            r0 = r16
            com.google.android.gms.internal.cr r8 = r0.qi     // Catch:{ all -> 0x0096 }
            r0 = r16
            com.google.android.gms.internal.fh r10 = r0.qh     // Catch:{ all -> 0x0096 }
            com.google.android.gms.internal.av r10 = r10.tL     // Catch:{ all -> 0x0096 }
            r0 = r16
            com.google.android.gms.internal.fh r11 = r0.qh     // Catch:{ all -> 0x0096 }
            com.google.android.gms.internal.ay r11 = r11.lS     // Catch:{ all -> 0x0096 }
            r0 = r16
            com.google.android.gms.internal.fh r12 = r0.qh     // Catch:{ all -> 0x0096 }
            com.google.android.gms.internal.gs r12 = r12.lO     // Catch:{ all -> 0x0096 }
            r4.<init>(r5, r6, r7, r8, r9, r10, r11, r12)     // Catch:{ all -> 0x0096 }
            r0 = r16
            r0.qk = r4     // Catch:{ all -> 0x0096 }
            monitor-exit(r15)     // Catch:{ all -> 0x0096 }
            r0 = r16
            com.google.android.gms.internal.cu r4 = r0.qk
            r0 = r17
            r2 = r19
            com.google.android.gms.internal.cv r4 = r4.b(r0, r2)
            int r5 = r4.qO
            if (r5 != 0) goto L_0x0099
            java.lang.String r5 = "Adapter succeeded."
            com.google.android.gms.internal.gr.S(r5)
            goto L_0x0057
        L_0x0096:
            r4 = move-exception
            monitor-exit(r15)     // Catch:{ all -> 0x0096 }
            throw r4
        L_0x0099:
            com.google.android.gms.internal.cz r5 = r4.qQ
            if (r5 == 0) goto L_0x0039
            android.os.Handler r5 = com.google.android.gms.internal.gq.wR
            com.google.android.gms.internal.cp$1 r6 = new com.google.android.gms.internal.cp$1
            r0 = r16
            r6.<init>(r4)
            r5.post(r6)
            goto L_0x0039
        L_0x00aa:
            com.google.android.gms.internal.cv r4 = new com.google.android.gms.internal.cv
            r5 = 1
            r4.<init>(r5)
            goto L_0x0057
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.cp.a(long, long):com.google.android.gms.internal.cv");
    }

    public void cancel() {
        synchronized (this.mH) {
            this.qj = true;
            if (this.qk != null) {
                this.qk.cancel();
            }
        }
    }
}
