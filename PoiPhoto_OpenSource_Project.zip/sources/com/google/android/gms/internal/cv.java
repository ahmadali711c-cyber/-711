package com.google.android.gms.internal;

@ey
public final class cv {
    public final int qO;
    public final cq qP;
    public final cz qQ;
    public final String qR;
    public final ct qS;

    public interface a {
        void k(int i);
    }

    public cv(int i) {
        this((cq) null, (cz) null, (String) null, (ct) null, i);
    }

    public cv(cq cqVar, cz czVar, String str, ct ctVar, int i) {
        this.qP = cqVar;
        this.qQ = czVar;
        this.qR = str;
        this.qS = ctVar;
        this.qO = i;
    }
}
