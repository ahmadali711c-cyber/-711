package com.google.android.gms.internal;

public interface ds {
    void ag();

    void ah();
}
