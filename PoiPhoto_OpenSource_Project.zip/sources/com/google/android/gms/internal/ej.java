package com.google.android.gms.internal;

import android.content.Intent;

public interface ej {
    void a(String str, boolean z, int i, Intent intent, ef efVar);
}
