package com.google.android.gms.internal;

import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.text.TextUtils;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.Thread;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

@ey
public class ex implements Thread.UncaughtExceptionHandler {
    private Context mContext;
    private Thread.UncaughtExceptionHandler tf;
    private Thread.UncaughtExceptionHandler tg;
    private gs th;

    public ex(Context context, gs gsVar, Thread.UncaughtExceptionHandler uncaughtExceptionHandler, Thread.UncaughtExceptionHandler uncaughtExceptionHandler2) {
        this.tf = uncaughtExceptionHandler;
        this.tg = uncaughtExceptionHandler2;
        this.mContext = context;
        this.th = gsVar;
    }

    public static ex a(Context context, Thread thread, gs gsVar) {
        if (context == null || thread == null || gsVar == null) {
            return null;
        }
        ga.bN();
        if (!k(context)) {
            return null;
        }
        Thread.UncaughtExceptionHandler uncaughtExceptionHandler = thread.getUncaughtExceptionHandler();
        ex exVar = new ex(context, gsVar, uncaughtExceptionHandler, Thread.getDefaultUncaughtExceptionHandler());
        if (uncaughtExceptionHandler != null && (uncaughtExceptionHandler instanceof ex)) {
            return (ex) uncaughtExceptionHandler;
        }
        try {
            thread.setUncaughtExceptionHandler(exVar);
            return exVar;
        } catch (SecurityException e) {
            gr.c("Fail to set UncaughtExceptionHandler.", e);
            return null;
        }
    }

    private String cD() {
        String str = Build.MANUFACTURER;
        String str2 = Build.MODEL;
        return str2.startsWith(str) ? str2 : str + " " + str2;
    }

    private Throwable d(Throwable th2) {
        Throwable th3;
        Bundle bN = ga.bN();
        if (bN != null && bN.getBoolean("gads:sdk_crash_report_full_stacktrace", false)) {
            return th2;
        }
        LinkedList linkedList = new LinkedList();
        while (th2 != null) {
            linkedList.push(th2);
            th2 = th2.getCause();
        }
        Throwable th4 = null;
        while (!linkedList.isEmpty()) {
            Throwable th5 = (Throwable) linkedList.pop();
            StackTraceElement[] stackTrace = th5.getStackTrace();
            ArrayList arrayList = new ArrayList();
            arrayList.add(new StackTraceElement(th5.getClass().getName(), "<filtered>", "<filtered>", 1));
            boolean z = false;
            for (StackTraceElement stackTraceElement : stackTrace) {
                if (G(stackTraceElement.getClassName())) {
                    arrayList.add(stackTraceElement);
                    z = true;
                } else if (H(stackTraceElement.getClassName())) {
                    arrayList.add(stackTraceElement);
                } else {
                    arrayList.add(new StackTraceElement("<filtered>", "<filtered>", "<filtered>", 1));
                }
            }
            if (z) {
                th3 = th4 == null ? new Throwable(th5.getMessage()) : new Throwable(th5.getMessage(), th4);
                th3.setStackTrace((StackTraceElement[]) arrayList.toArray(new StackTraceElement[0]));
            } else {
                th3 = th4;
            }
            th4 = th3;
        }
        return th4;
    }

    private static boolean k(Context context) {
        Bundle bN = ga.bN();
        return bN != null && bN.getBoolean("gads:sdk_crash_report_enabled", false);
    }

    /* access modifiers changed from: protected */
    public boolean G(String str) {
        if (TextUtils.isEmpty(str)) {
            return false;
        }
        if (str.startsWith("com.google.android.gms.ads")) {
            return true;
        }
        if (str.startsWith("com.google.ads")) {
            return true;
        }
        try {
            return Class.forName(str).isAnnotationPresent(ey.class);
        } catch (Exception e) {
            gr.a("Fail to check class type for class " + str, e);
            return false;
        }
    }

    /* access modifiers changed from: protected */
    public boolean H(String str) {
        if (TextUtils.isEmpty(str)) {
            return false;
        }
        return str.startsWith("android.") || str.startsWith("java.");
    }

    /* access modifiers changed from: protected */
    public boolean a(Throwable th2) {
        boolean z = true;
        if (th2 == null) {
            return false;
        }
        boolean z2 = false;
        boolean z3 = false;
        while (th2 != null) {
            for (StackTraceElement stackTraceElement : th2.getStackTrace()) {
                if (G(stackTraceElement.getClassName())) {
                    z3 = true;
                }
                if (getClass().getName().equals(stackTraceElement.getClassName())) {
                    z2 = true;
                }
            }
            th2 = th2.getCause();
        }
        if (!z3 || z2) {
            z = false;
        }
        return z;
    }

    public void b(Throwable th2) {
        Throwable d;
        if (k(this.mContext) && (d = d(th2)) != null) {
            ArrayList arrayList = new ArrayList();
            arrayList.add(c(d));
            gi.a(this.mContext, this.th.wS, (List<String>) arrayList, ga.dn());
        }
    }

    /* access modifiers changed from: protected */
    public String c(Throwable th2) {
        StringWriter stringWriter = new StringWriter();
        th2.printStackTrace(new PrintWriter(stringWriter));
        return new Uri.Builder().scheme("https").path("//pagead2.googlesyndication.com/pagead/gen_204").appendQueryParameter("id", "gmob-apps-report-exception").appendQueryParameter("os", Build.VERSION.RELEASE).appendQueryParameter("api", String.valueOf(Build.VERSION.SDK_INT)).appendQueryParameter("device", cD()).appendQueryParameter("js", this.th.wS).appendQueryParameter("appid", this.mContext.getApplicationContext().getPackageName()).appendQueryParameter("stacktrace", stringWriter.toString()).toString();
    }

    public void uncaughtException(Thread thread, Throwable exception) {
        if (a(exception)) {
            b(exception);
            if (Looper.getMainLooper().getThread() != thread) {
                return;
            }
        }
        if (this.tf != null) {
            this.tf.uncaughtException(thread, exception);
        } else if (this.tg != null) {
            this.tg.uncaughtException(thread, exception);
        }
    }
}
