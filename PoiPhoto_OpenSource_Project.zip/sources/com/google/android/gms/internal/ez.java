package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.internal.fh;
import com.google.android.gms.internal.fy;

@ey
public final class ez {

    public interface a {
        void a(fy.a aVar);
    }

    public static gf a(Context context, fh.a aVar, k kVar, a aVar2) {
        fa faVar = new fa(context, aVar, kVar, aVar2);
        faVar.start();
        return faVar;
    }
}
