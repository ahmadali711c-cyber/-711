package com.google.android.gms.internal;

import android.content.Context;
import android.os.SystemClock;
import android.text.TextUtils;
import com.google.android.gms.internal.ez;
import com.google.android.gms.internal.fe;
import com.google.android.gms.internal.fh;
import org.json.JSONException;

@ey
public class fa extends gf implements fe.a {
    private final Context mContext;
    /* access modifiers changed from: private */
    public final Object mH = new Object();
    private cr qi;
    /* access modifiers changed from: private */
    public final ez.a ti;
    private final Object tj = new Object();
    private final fh.a tk;
    private final k tl;
    private gf tm;
    private fj tn;

    @ey
    private static final class a extends Exception {
        private final int tq;

        public a(String str, int i) {
            super(str);
            this.tq = i;
        }

        public int getErrorCode() {
            return this.tq;
        }
    }

    public fa(Context context, fh.a aVar, k kVar, ez.a aVar2) {
        this.ti = aVar2;
        this.mContext = context;
        this.tk = aVar;
        this.tl = kVar;
    }

    private ay a(fh fhVar) throws a {
        if (this.tn.tZ == null) {
            throw new a("The ad response must specify one of the supported ad sizes.", 0);
        }
        String[] split = this.tn.tZ.split("x");
        if (split.length != 2) {
            throw new a("Could not parse the ad size from the ad response: " + this.tn.tZ, 0);
        }
        try {
            int parseInt = Integer.parseInt(split[0]);
            int parseInt2 = Integer.parseInt(split[1]);
            for (ay ayVar : fhVar.lS.or) {
                float f = this.mContext.getResources().getDisplayMetrics().density;
                int i = ayVar.width == -1 ? (int) (((float) ayVar.widthPixels) / f) : ayVar.width;
                int i2 = ayVar.height == -2 ? (int) (((float) ayVar.heightPixels) / f) : ayVar.height;
                if (parseInt == i && parseInt2 == i2) {
                    return new ay(ayVar, fhVar.lS.or);
                }
            }
            throw new a("The ad size from the ad response was not one of the requested sizes: " + this.tn.tZ, 0);
        } catch (NumberFormatException e) {
            throw new a("Could not parse the ad size from the ad response: " + this.tn.tZ, 0);
        }
    }

    private boolean c(long j) throws a {
        long elapsedRealtime = 60000 - (SystemClock.elapsedRealtime() - j);
        if (elapsedRealtime <= 0) {
            return false;
        }
        try {
            this.mH.wait(elapsedRealtime);
            return true;
        } catch (InterruptedException e) {
            throw new a("Ad request cancelled.", -1);
        }
    }

    private void cE() throws a {
        if (this.tn.errorCode != -3) {
            if (TextUtils.isEmpty(this.tn.tU)) {
                throw new a("No fill from ad server.", 3);
            }
            ga.a(this.mContext, this.tn.tT);
            if (this.tn.tW) {
                try {
                    this.qi = new cr(this.tn.tU);
                } catch (JSONException e) {
                    throw new a("Could not parse mediation config: " + this.tn.tU, 0);
                }
            }
        }
    }

    private void e(long j) throws a {
        while (c(j)) {
            if (this.tn != null) {
                synchronized (this.tj) {
                    this.tm = null;
                }
                if (this.tn.errorCode != -2 && this.tn.errorCode != -3) {
                    throw new a("There was a problem getting an ad response. ErrorCode: " + this.tn.errorCode, this.tn.errorCode);
                }
                return;
            }
        }
        throw new a("Timed out waiting for ad response.", 2);
    }

    private void t(boolean z) {
        ga.dc().x(z);
        an l = ga.dc().l(this.mContext);
        if (l != null && !l.isAlive()) {
            gr.S("start fetching content...");
            l.ba();
        }
    }

    public void a(fj fjVar) {
        synchronized (this.mH) {
            gr.S("Received ad response.");
            this.tn = fjVar;
            this.mH.notify();
        }
    }

    /*  JADX ERROR: IndexOutOfBoundsException in pass: RegionMakerVisitor
        java.lang.IndexOutOfBoundsException: Index: 0, Size: 0
        	at java.util.ArrayList.rangeCheck(ArrayList.java:659)
        	at java.util.ArrayList.get(ArrayList.java:435)
        	at jadx.core.dex.nodes.InsnNode.getArg(InsnNode.java:101)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:611)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.processMonitorEnter(RegionMaker.java:561)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:133)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processMonitorEnter(RegionMaker.java:598)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:133)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:49)
        */
    public void cx() {
        /*
            r12 = this;
            r8 = 0
            java.lang.Object r11 = r12.mH
            monitor-enter(r11)
            java.lang.String r0 = "AdLoaderBackgroundTask started."
            com.google.android.gms.internal.gr.S(r0)     // Catch:{ all -> 0x00b9 }
            com.google.android.gms.internal.k r0 = r12.tl     // Catch:{ all -> 0x00b9 }
            com.google.android.gms.internal.g r0 = r0.C()     // Catch:{ all -> 0x00b9 }
            android.content.Context r1 = r12.mContext     // Catch:{ all -> 0x00b9 }
            java.lang.String r0 = r0.a((android.content.Context) r1)     // Catch:{ all -> 0x00b9 }
            com.google.android.gms.internal.fh r1 = new com.google.android.gms.internal.fh     // Catch:{ all -> 0x00b9 }
            com.google.android.gms.internal.fh$a r2 = r12.tk     // Catch:{ all -> 0x00b9 }
            r1.<init>(r2, r0)     // Catch:{ all -> 0x00b9 }
            r5 = -2
            r2 = -1
            long r6 = android.os.SystemClock.elapsedRealtime()     // Catch:{ a -> 0x003e }
            android.content.Context r0 = r12.mContext     // Catch:{ a -> 0x003e }
            com.google.android.gms.internal.gf r0 = com.google.android.gms.internal.fe.a(r0, r1, r12)     // Catch:{ a -> 0x003e }
            java.lang.Object r4 = r12.tj     // Catch:{ a -> 0x003e }
            monitor-enter(r4)     // Catch:{ a -> 0x003e }
            r12.tm = r0     // Catch:{ all -> 0x003b }
            com.google.android.gms.internal.gf r0 = r12.tm     // Catch:{ all -> 0x003b }
            if (r0 != 0) goto L_0x0093
            com.google.android.gms.internal.fa$a r0 = new com.google.android.gms.internal.fa$a     // Catch:{ all -> 0x003b }
            java.lang.String r5 = "Could not start the ad request service."
            r6 = 0
            r0.<init>(r5, r6)     // Catch:{ all -> 0x003b }
            throw r0     // Catch:{ all -> 0x003b }
        L_0x003b:
            r0 = move-exception
            monitor-exit(r4)     // Catch:{ all -> 0x003b }
            throw r0     // Catch:{ a -> 0x003e }
        L_0x003e:
            r0 = move-exception
            r4 = r8
        L_0x0040:
            int r5 = r0.getErrorCode()     // Catch:{ all -> 0x00b9 }
            r6 = 3
            if (r5 == r6) goto L_0x004a
            r6 = -1
            if (r5 != r6) goto L_0x00b1
        L_0x004a:
            java.lang.String r0 = r0.getMessage()     // Catch:{ all -> 0x00b9 }
            com.google.android.gms.internal.gr.U(r0)     // Catch:{ all -> 0x00b9 }
        L_0x0051:
            com.google.android.gms.internal.fj r0 = r12.tn     // Catch:{ all -> 0x00b9 }
            if (r0 != 0) goto L_0x00bc
            com.google.android.gms.internal.fj r0 = new com.google.android.gms.internal.fj     // Catch:{ all -> 0x00b9 }
            r0.<init>(r5)     // Catch:{ all -> 0x00b9 }
            r12.tn = r0     // Catch:{ all -> 0x00b9 }
        L_0x005c:
            android.os.Handler r0 = com.google.android.gms.internal.gq.wR     // Catch:{ all -> 0x00b9 }
            com.google.android.gms.internal.fa$1 r6 = new com.google.android.gms.internal.fa$1     // Catch:{ all -> 0x00b9 }
            r6.<init>()     // Catch:{ all -> 0x00b9 }
            r0.post(r6)     // Catch:{ all -> 0x00b9 }
            r6 = r2
        L_0x0067:
            com.google.android.gms.internal.fj r0 = r12.tn     // Catch:{ all -> 0x00b9 }
            java.lang.String r0 = r0.ue     // Catch:{ all -> 0x00b9 }
            boolean r0 = android.text.TextUtils.isEmpty(r0)     // Catch:{ all -> 0x00b9 }
            if (r0 != 0) goto L_0x00ce
            org.json.JSONObject r10 = new org.json.JSONObject     // Catch:{ Exception -> 0x00c8 }
            com.google.android.gms.internal.fj r0 = r12.tn     // Catch:{ Exception -> 0x00c8 }
            java.lang.String r0 = r0.ue     // Catch:{ Exception -> 0x00c8 }
            r10.<init>(r0)     // Catch:{ Exception -> 0x00c8 }
        L_0x007a:
            com.google.android.gms.internal.fy$a r0 = new com.google.android.gms.internal.fy$a     // Catch:{ all -> 0x00b9 }
            com.google.android.gms.internal.fj r2 = r12.tn     // Catch:{ all -> 0x00b9 }
            com.google.android.gms.internal.cr r3 = r12.qi     // Catch:{ all -> 0x00b9 }
            com.google.android.gms.internal.fj r8 = r12.tn     // Catch:{ all -> 0x00b9 }
            long r8 = r8.ua     // Catch:{ all -> 0x00b9 }
            r0.<init>(r1, r2, r3, r4, r5, r6, r8, r10)     // Catch:{ all -> 0x00b9 }
            android.os.Handler r1 = com.google.android.gms.internal.gq.wR     // Catch:{ all -> 0x00b9 }
            com.google.android.gms.internal.fa$2 r2 = new com.google.android.gms.internal.fa$2     // Catch:{ all -> 0x00b9 }
            r2.<init>(r0)     // Catch:{ all -> 0x00b9 }
            r1.post(r2)     // Catch:{ all -> 0x00b9 }
            monitor-exit(r11)     // Catch:{ all -> 0x00b9 }
            return
        L_0x0093:
            monitor-exit(r4)     // Catch:{ all -> 0x003b }
            r12.e(r6)     // Catch:{ a -> 0x003e }
            long r2 = android.os.SystemClock.elapsedRealtime()     // Catch:{ a -> 0x003e }
            r12.cE()     // Catch:{ a -> 0x003e }
            com.google.android.gms.internal.ay r0 = r1.lS     // Catch:{ a -> 0x003e }
            com.google.android.gms.internal.ay[] r0 = r0.or     // Catch:{ a -> 0x003e }
            if (r0 == 0) goto L_0x00d3
            com.google.android.gms.internal.ay r4 = r12.a((com.google.android.gms.internal.fh) r1)     // Catch:{ a -> 0x003e }
        L_0x00a8:
            com.google.android.gms.internal.fj r0 = r12.tn     // Catch:{ a -> 0x00d0 }
            boolean r0 = r0.uh     // Catch:{ a -> 0x00d0 }
            r12.t(r0)     // Catch:{ a -> 0x00d0 }
            r6 = r2
            goto L_0x0067
        L_0x00b1:
            java.lang.String r0 = r0.getMessage()     // Catch:{ all -> 0x00b9 }
            com.google.android.gms.internal.gr.W(r0)     // Catch:{ all -> 0x00b9 }
            goto L_0x0051
        L_0x00b9:
            r0 = move-exception
            monitor-exit(r11)     // Catch:{ all -> 0x00b9 }
            throw r0
        L_0x00bc:
            com.google.android.gms.internal.fj r0 = new com.google.android.gms.internal.fj     // Catch:{ all -> 0x00b9 }
            com.google.android.gms.internal.fj r6 = r12.tn     // Catch:{ all -> 0x00b9 }
            long r6 = r6.qA     // Catch:{ all -> 0x00b9 }
            r0.<init>(r5, r6)     // Catch:{ all -> 0x00b9 }
            r12.tn = r0     // Catch:{ all -> 0x00b9 }
            goto L_0x005c
        L_0x00c8:
            r0 = move-exception
            java.lang.String r2 = "Error parsing the JSON for Active View."
            com.google.android.gms.internal.gr.b(r2, r0)     // Catch:{ all -> 0x00b9 }
        L_0x00ce:
            r10 = r8
            goto L_0x007a
        L_0x00d0:
            r0 = move-exception
            goto L_0x0040
        L_0x00d3:
            r4 = r8
            goto L_0x00a8
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.fa.cx():void");
    }

    public void onStop() {
        synchronized (this.tj) {
            if (this.tm != null) {
                this.tm.cancel();
            }
        }
    }
}
