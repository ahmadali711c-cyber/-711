package com.google.android.gms.internal;

import com.google.android.gms.internal.fn;
import java.util.concurrent.ExecutionException;
import org.json.JSONException;
import org.json.JSONObject;

@ey
public class fp implements fn.a<bu> {
    /* renamed from: c */
    public bu a(fn fnVar, JSONObject jSONObject) throws JSONException, InterruptedException, ExecutionException {
        return new bu(jSONObject.getString("headline"), fnVar.a(jSONObject, "image", true).get(), jSONObject.getString("body"), fnVar.a(jSONObject, "secondary_image", false).get(), jSONObject.getString("call_to_action"), jSONObject.getString("attribution"));
    }
}
