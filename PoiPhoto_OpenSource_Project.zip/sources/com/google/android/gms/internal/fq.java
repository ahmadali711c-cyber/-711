package com.google.android.gms.internal;

import android.content.Context;
import android.location.Location;
import com.google.android.gms.internal.fl;
import com.google.android.gms.internal.gv;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@ey
public final class fq extends fl.a {
    private static final Object ut = new Object();
    private static fq uu;
    private final Context mContext;
    private final fw uv;
    private final cn uw;
    private final bm ux;

    fq(Context context, bm bmVar, cn cnVar, fw fwVar) {
        this.mContext = context;
        this.uv = fwVar;
        this.uw = cnVar;
        this.ux = bmVar;
    }

    private static gv.a I(final String str) {
        return new gv.a() {
            public void a(gu guVar) {
                String format = String.format("javascript:%s(%s);", new Object[]{"AFMA_buildAdURL", str});
                gr.V("About to execute: " + format);
                guVar.loadUrl(format);
            }
        };
    }

    private static fj a(Context context, bm bmVar, cn cnVar, fw fwVar, fh fhVar) {
        String string;
        gr.S("Starting ad request from service.");
        cnVar.init();
        fv fvVar = new fv(context);
        if (fvVar.vr == -1) {
            gr.S("Device is offline.");
            return new fj(2);
        }
        final fs fsVar = new fs(fhVar.applicationInfo.packageName);
        if (fhVar.tL.extras != null && (string = fhVar.tL.extras.getString("_ad")) != null) {
            return fr.a(context, fhVar, string);
        }
        Location a = cnVar.a(250);
        String bu = bmVar.bu();
        String a2 = fr.a(fhVar, fvVar, a, bmVar.bv(), bmVar.bw(), bmVar.bx());
        if (a2 == null) {
            return new fj(0);
        }
        final gv.a I = I(a2);
        final Context context2 = context;
        final fh fhVar2 = fhVar;
        final fs fsVar2 = fsVar;
        final String str = bu;
        gq.wR.post(new Runnable() {
            public void run() {
                gu a = gu.a(context2, new ay(), false, false, (k) null, fhVar2.lO);
                a.setWillNotDraw(true);
                fsVar2.b(a);
                gv dD = a.dD();
                dD.a("/invalidRequest", fsVar2.uG);
                dD.a("/loadAdURL", fsVar2.uH);
                dD.a("/log", cc.pX);
                dD.a(I);
                gr.S("Loading the JS library.");
                a.loadUrl(str);
            }
        });
        try {
            fu fuVar = fsVar.cR().get(10, TimeUnit.SECONDS);
            if (fuVar == null) {
                return new fj(0);
            }
            if (fuVar.getErrorCode() != -2) {
                fj fjVar = new fj(fuVar.getErrorCode());
                gq.wR.post(new Runnable() {
                    public void run() {
                        fsVar.cS();
                    }
                });
                return fjVar;
            }
            String str2 = null;
            if (fuVar.cV()) {
                str2 = fwVar.K(fhVar.tM.packageName);
            }
            fj a3 = a(context, fhVar.lO.wS, fuVar.getUrl(), str2, fuVar);
            gq.wR.post(new Runnable() {
                public void run() {
                    fsVar.cS();
                }
            });
            return a3;
        } catch (Exception e) {
            return new fj(0);
        } finally {
            gq.wR.post(new Runnable() {
                public void run() {
                    fsVar.cS();
                }
            });
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:39:?, code lost:
        com.google.android.gms.internal.gr.W("Received error HTTP response code: " + r6);
        r1 = new com.google.android.gms.internal.fj(0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:41:?, code lost:
        r0.disconnect();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:59:?, code lost:
        return r1;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static com.google.android.gms.internal.fj a(android.content.Context r10, java.lang.String r11, java.lang.String r12, java.lang.String r13, com.google.android.gms.internal.fu r14) {
        /*
            r9 = 300(0x12c, float:4.2E-43)
            r0 = 0
            com.google.android.gms.internal.ft r3 = new com.google.android.gms.internal.ft     // Catch:{ IOException -> 0x0104 }
            r3.<init>()     // Catch:{ IOException -> 0x0104 }
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ IOException -> 0x0104 }
            r1.<init>()     // Catch:{ IOException -> 0x0104 }
            java.lang.String r2 = "AdRequestServiceImpl: Sending request: "
            java.lang.StringBuilder r1 = r1.append(r2)     // Catch:{ IOException -> 0x0104 }
            java.lang.StringBuilder r1 = r1.append(r12)     // Catch:{ IOException -> 0x0104 }
            java.lang.String r1 = r1.toString()     // Catch:{ IOException -> 0x0104 }
            com.google.android.gms.internal.gr.S(r1)     // Catch:{ IOException -> 0x0104 }
            java.net.URL r1 = new java.net.URL     // Catch:{ IOException -> 0x0104 }
            r1.<init>(r12)     // Catch:{ IOException -> 0x0104 }
            long r4 = android.os.SystemClock.elapsedRealtime()     // Catch:{ IOException -> 0x0104 }
            r2 = r1
            r1 = r0
        L_0x0029:
            java.net.URLConnection r0 = r2.openConnection()     // Catch:{ IOException -> 0x0104 }
            java.net.HttpURLConnection r0 = (java.net.HttpURLConnection) r0     // Catch:{ IOException -> 0x0104 }
            r6 = 0
            com.google.android.gms.internal.gi.a((android.content.Context) r10, (java.lang.String) r11, (boolean) r6, (java.net.HttpURLConnection) r0)     // Catch:{ all -> 0x0127 }
            boolean r6 = android.text.TextUtils.isEmpty(r13)     // Catch:{ all -> 0x0127 }
            if (r6 != 0) goto L_0x003e
            java.lang.String r6 = "x-afma-drt-cookie"
            r0.addRequestProperty(r6, r13)     // Catch:{ all -> 0x0127 }
        L_0x003e:
            if (r14 == 0) goto L_0x0069
            java.lang.String r6 = r14.cU()     // Catch:{ all -> 0x0127 }
            boolean r6 = android.text.TextUtils.isEmpty(r6)     // Catch:{ all -> 0x0127 }
            if (r6 != 0) goto L_0x0069
            r6 = 1
            r0.setDoOutput(r6)     // Catch:{ all -> 0x0127 }
            java.lang.String r6 = r14.cU()     // Catch:{ all -> 0x0127 }
            byte[] r6 = r6.getBytes()     // Catch:{ all -> 0x0127 }
            int r7 = r6.length     // Catch:{ all -> 0x0127 }
            r0.setFixedLengthStreamingMode(r7)     // Catch:{ all -> 0x0127 }
            java.io.BufferedOutputStream r7 = new java.io.BufferedOutputStream     // Catch:{ all -> 0x0127 }
            java.io.OutputStream r8 = r0.getOutputStream()     // Catch:{ all -> 0x0127 }
            r7.<init>(r8)     // Catch:{ all -> 0x0127 }
            r7.write(r6)     // Catch:{ all -> 0x0127 }
            r7.close()     // Catch:{ all -> 0x0127 }
        L_0x0069:
            int r6 = r0.getResponseCode()     // Catch:{ all -> 0x0127 }
            java.util.Map r7 = r0.getHeaderFields()     // Catch:{ all -> 0x0127 }
            r8 = 200(0xc8, float:2.8E-43)
            if (r6 < r8) goto L_0x0097
            if (r6 >= r9) goto L_0x0097
            java.lang.String r1 = r2.toString()     // Catch:{ all -> 0x0127 }
            java.io.InputStreamReader r2 = new java.io.InputStreamReader     // Catch:{ all -> 0x0127 }
            java.io.InputStream r8 = r0.getInputStream()     // Catch:{ all -> 0x0127 }
            r2.<init>(r8)     // Catch:{ all -> 0x0127 }
            java.lang.String r2 = com.google.android.gms.internal.gi.a((java.lang.Readable) r2)     // Catch:{ all -> 0x0127 }
            a((java.lang.String) r1, (java.util.Map<java.lang.String, java.util.List<java.lang.String>>) r7, (java.lang.String) r2, (int) r6)     // Catch:{ all -> 0x0127 }
            r3.a(r1, r7, r2)     // Catch:{ all -> 0x0127 }
            com.google.android.gms.internal.fj r1 = r3.i((long) r4)     // Catch:{ all -> 0x0127 }
            r0.disconnect()     // Catch:{ IOException -> 0x0104 }
            r0 = r1
        L_0x0096:
            return r0
        L_0x0097:
            java.lang.String r2 = r2.toString()     // Catch:{ all -> 0x0127 }
            r8 = 0
            a((java.lang.String) r2, (java.util.Map<java.lang.String, java.util.List<java.lang.String>>) r7, (java.lang.String) r8, (int) r6)     // Catch:{ all -> 0x0127 }
            if (r6 < r9) goto L_0x00db
            r2 = 400(0x190, float:5.6E-43)
            if (r6 >= r2) goto L_0x00db
            java.lang.String r2 = "Location"
            java.lang.String r6 = r0.getHeaderField(r2)     // Catch:{ all -> 0x0127 }
            boolean r2 = android.text.TextUtils.isEmpty(r6)     // Catch:{ all -> 0x0127 }
            if (r2 == 0) goto L_0x00c1
            java.lang.String r1 = "No location header to follow redirect."
            com.google.android.gms.internal.gr.W(r1)     // Catch:{ all -> 0x0127 }
            com.google.android.gms.internal.fj r1 = new com.google.android.gms.internal.fj     // Catch:{ all -> 0x0127 }
            r2 = 0
            r1.<init>(r2)     // Catch:{ all -> 0x0127 }
            r0.disconnect()     // Catch:{ IOException -> 0x0104 }
            r0 = r1
            goto L_0x0096
        L_0x00c1:
            java.net.URL r2 = new java.net.URL     // Catch:{ all -> 0x0127 }
            r2.<init>(r6)     // Catch:{ all -> 0x0127 }
            int r1 = r1 + 1
            r6 = 5
            if (r1 <= r6) goto L_0x00fc
            java.lang.String r1 = "Too many redirects."
            com.google.android.gms.internal.gr.W(r1)     // Catch:{ all -> 0x0127 }
            com.google.android.gms.internal.fj r1 = new com.google.android.gms.internal.fj     // Catch:{ all -> 0x0127 }
            r2 = 0
            r1.<init>(r2)     // Catch:{ all -> 0x0127 }
            r0.disconnect()     // Catch:{ IOException -> 0x0104 }
            r0 = r1
            goto L_0x0096
        L_0x00db:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ all -> 0x0127 }
            r1.<init>()     // Catch:{ all -> 0x0127 }
            java.lang.String r2 = "Received error HTTP response code: "
            java.lang.StringBuilder r1 = r1.append(r2)     // Catch:{ all -> 0x0127 }
            java.lang.StringBuilder r1 = r1.append(r6)     // Catch:{ all -> 0x0127 }
            java.lang.String r1 = r1.toString()     // Catch:{ all -> 0x0127 }
            com.google.android.gms.internal.gr.W(r1)     // Catch:{ all -> 0x0127 }
            com.google.android.gms.internal.fj r1 = new com.google.android.gms.internal.fj     // Catch:{ all -> 0x0127 }
            r2 = 0
            r1.<init>(r2)     // Catch:{ all -> 0x0127 }
            r0.disconnect()     // Catch:{ IOException -> 0x0104 }
            r0 = r1
            goto L_0x0096
        L_0x00fc:
            r3.e(r7)     // Catch:{ all -> 0x0127 }
            r0.disconnect()     // Catch:{ IOException -> 0x0104 }
            goto L_0x0029
        L_0x0104:
            r0 = move-exception
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "Error while connecting to ad server: "
            java.lang.StringBuilder r1 = r1.append(r2)
            java.lang.String r0 = r0.getMessage()
            java.lang.StringBuilder r0 = r1.append(r0)
            java.lang.String r0 = r0.toString()
            com.google.android.gms.internal.gr.W(r0)
            com.google.android.gms.internal.fj r0 = new com.google.android.gms.internal.fj
            r1 = 2
            r0.<init>(r1)
            goto L_0x0096
        L_0x0127:
            r1 = move-exception
            r0.disconnect()     // Catch:{ IOException -> 0x0104 }
            throw r1     // Catch:{ IOException -> 0x0104 }
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.fq.a(android.content.Context, java.lang.String, java.lang.String, java.lang.String, com.google.android.gms.internal.fu):com.google.android.gms.internal.fj");
    }

    public static fq a(Context context, bm bmVar, cn cnVar, fw fwVar) {
        fq fqVar;
        synchronized (ut) {
            if (uu == null) {
                uu = new fq(context.getApplicationContext(), bmVar, cnVar, fwVar);
            }
            fqVar = uu;
        }
        return fqVar;
    }

    private static void a(String str, Map<String, List<String>> map, String str2, int i) {
        if (gr.v(2)) {
            gr.V("Http Response: {\n  URL:\n    " + str + "\n  Headers:");
            if (map != null) {
                for (String next : map.keySet()) {
                    gr.V("    " + next + ":");
                    for (String str3 : map.get(next)) {
                        gr.V("      " + str3);
                    }
                }
            }
            gr.V("  Body:");
            if (str2 != null) {
                for (int i2 = 0; i2 < Math.min(str2.length(), 100000); i2 += 1000) {
                    gr.V(str2.substring(i2, Math.min(str2.length(), i2 + 1000)));
                }
            } else {
                gr.V("    null");
            }
            gr.V("  Response Code:\n    " + i + "\n}");
        }
    }

    public fj b(fh fhVar) {
        return a(this.mContext, this.ux, this.uw, this.uv, fhVar);
    }
}
