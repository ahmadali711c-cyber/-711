package com.google.android.gms.internal;

public interface fw {
    String K(String str);
}
