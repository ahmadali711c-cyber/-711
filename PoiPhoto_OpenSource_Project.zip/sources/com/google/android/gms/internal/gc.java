package com.google.android.gms.internal;

import java.util.HashSet;

public interface gc {
    void a(HashSet<fz> hashSet);
}
