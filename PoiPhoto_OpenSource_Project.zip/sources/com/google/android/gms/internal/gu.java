package com.google.android.gms.internal;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.MutableContextWrapper;
import android.net.Uri;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.DownloadListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import com.google.android.gms.drive.DriveFile;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

@ey
public class gu extends WebView implements DownloadListener {
    private final Object mH = new Object();
    private final WindowManager mR;
    private ay qI;
    private final gs qJ;
    private final k tl;
    private final gv wW;
    private final a wX;
    private dp wY;
    private boolean wZ;
    private boolean xa;
    private boolean xb;
    private boolean xc;

    @ey
    protected static class a extends MutableContextWrapper {
        private Context mO;
        private Activity xd;

        public a(Context context) {
            super(context);
            setBaseContext(context);
        }

        public Context dI() {
            return this.xd;
        }

        public void setBaseContext(Context base) {
            this.mO = base.getApplicationContext();
            this.xd = base instanceof Activity ? (Activity) base : null;
            super.setBaseContext(this.mO);
        }

        public void startActivity(Intent intent) {
            if (this.xd != null) {
                this.xd.startActivity(intent);
                return;
            }
            intent.setFlags(DriveFile.MODE_READ_ONLY);
            this.mO.startActivity(intent);
        }
    }

    protected gu(a aVar, ay ayVar, boolean z, boolean z2, k kVar, gs gsVar) {
        super(aVar);
        this.wX = aVar;
        this.qI = ayVar;
        this.wZ = z;
        this.tl = kVar;
        this.qJ = gsVar;
        this.mR = (WindowManager) getContext().getSystemService("window");
        setBackgroundColor(0);
        WebSettings settings = getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setSavePassword(false);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        gi.a((Context) aVar, gsVar.wS, settings);
        if (Build.VERSION.SDK_INT >= 17) {
            go.a(getContext(), settings);
        } else if (Build.VERSION.SDK_INT >= 11) {
            gm.a(getContext(), settings);
        }
        setDownloadListener(this);
        if (Build.VERSION.SDK_INT >= 11) {
            this.wW = new gx(this, z2);
        } else {
            this.wW = new gv(this, z2);
        }
        setWebViewClient(this.wW);
        if (Build.VERSION.SDK_INT >= 14) {
            setWebChromeClient(new gy(this));
        } else if (Build.VERSION.SDK_INT >= 11) {
            setWebChromeClient(new gw(this));
        }
        dJ();
    }

    public static gu a(Context context, ay ayVar, boolean z, boolean z2, k kVar, gs gsVar) {
        return new gu(new a(context), ayVar, z, z2, kVar, gsVar);
    }

    private void dJ() {
        synchronized (this.mH) {
            if (this.wZ || this.qI.oq) {
                if (Build.VERSION.SDK_INT < 14) {
                    gr.S("Disabling hardware acceleration on an overlay.");
                    dK();
                } else {
                    gr.S("Enabling hardware acceleration on an overlay.");
                    dL();
                }
            } else if (Build.VERSION.SDK_INT < 18) {
                gr.S("Disabling hardware acceleration on an AdView.");
                dK();
            } else {
                gr.S("Enabling hardware acceleration on an AdView.");
                dL();
            }
        }
    }

    private void dK() {
        synchronized (this.mH) {
            if (!this.xa && Build.VERSION.SDK_INT >= 11) {
                gm.i(this);
            }
            this.xa = true;
        }
    }

    private void dL() {
        synchronized (this.mH) {
            if (this.xa && Build.VERSION.SDK_INT >= 11) {
                gm.j(this);
            }
            this.xa = false;
        }
    }

    /* access modifiers changed from: protected */
    public void X(String str) {
        synchronized (this.mH) {
            if (!isDestroyed()) {
                loadUrl(str);
            } else {
                gr.W("The webview is destroyed. Ignoring action.");
            }
        }
    }

    public void a(Context context, ay ayVar) {
        synchronized (this.mH) {
            this.wX.setBaseContext(context);
            this.wY = null;
            this.qI = ayVar;
            this.wZ = false;
            this.xc = false;
            gi.b(this);
            loadUrl("about:blank");
            this.wW.reset();
            setOnTouchListener((View.OnTouchListener) null);
            setOnClickListener((View.OnClickListener) null);
        }
    }

    public void a(ay ayVar) {
        synchronized (this.mH) {
            this.qI = ayVar;
            requestLayout();
        }
    }

    public void a(dp dpVar) {
        synchronized (this.mH) {
            this.wY = dpVar;
        }
    }

    public void a(String str, Map<String, ?> map) {
        try {
            b(str, gi.t(map));
        } catch (JSONException e) {
            gr.W("Could not convert parameters to JSON.");
        }
    }

    public void a(String str, JSONObject jSONObject) {
        if (jSONObject == null) {
            jSONObject = new JSONObject();
        }
        String jSONObject2 = jSONObject.toString();
        StringBuilder sb = new StringBuilder();
        sb.append("javascript:" + str + "(");
        sb.append(jSONObject2);
        sb.append(");");
        X(sb.toString());
    }

    public ay ac() {
        ay ayVar;
        synchronized (this.mH) {
            ayVar = this.qI;
        }
        return ayVar;
    }

    public void b(String str, JSONObject jSONObject) {
        if (jSONObject == null) {
            jSONObject = new JSONObject();
        }
        String jSONObject2 = jSONObject.toString();
        StringBuilder sb = new StringBuilder();
        sb.append("javascript:AFMA_ReceiveMessage('");
        sb.append(str);
        sb.append("'");
        sb.append(",");
        sb.append(jSONObject2);
        sb.append(");");
        gr.V("Dispatching AFMA event: " + sb);
        X(sb.toString());
    }

    public void cb() {
        if (dD().dN()) {
            DisplayMetrics displayMetrics = new DisplayMetrics();
            Display defaultDisplay = this.mR.getDefaultDisplay();
            defaultDisplay.getMetrics(displayMetrics);
            int s = gi.s(getContext());
            float f = 160.0f / ((float) displayMetrics.densityDpi);
            int round = Math.round(((float) displayMetrics.widthPixels) * f);
            try {
                b("onScreenInfoChanged", new JSONObject().put("width", round).put("height", Math.round(((float) (displayMetrics.heightPixels - s)) * f)).put("density", (double) displayMetrics.density).put("rotation", defaultDisplay.getRotation()));
            } catch (JSONException e) {
                gr.b("Error occured while obtaining screen information.", e);
            }
        }
    }

    public void ci() {
        HashMap hashMap = new HashMap(1);
        hashMap.put("version", this.qJ.wS);
        a("onshow", (Map<String, ?>) hashMap);
    }

    public void cj() {
        HashMap hashMap = new HashMap(1);
        hashMap.put("version", this.qJ.wS);
        a("onhide", (Map<String, ?>) hashMap);
    }

    public dp dC() {
        dp dpVar;
        synchronized (this.mH) {
            dpVar = this.wY;
        }
        return dpVar;
    }

    public gv dD() {
        return this.wW;
    }

    public boolean dE() {
        return this.xc;
    }

    public k dF() {
        return this.tl;
    }

    public gs dG() {
        return this.qJ;
    }

    public boolean dH() {
        boolean z;
        synchronized (this.mH) {
            z = this.wZ;
        }
        return z;
    }

    public Context dI() {
        return this.wX.dI();
    }

    public void destroy() {
        synchronized (this.mH) {
            if (this.wY != null) {
                this.wY.close();
            }
            this.xb = true;
            super.destroy();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:15:?, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void evaluateJavascript(java.lang.String r3, android.webkit.ValueCallback<java.lang.String> r4) {
        /*
            r2 = this;
            java.lang.Object r1 = r2.mH
            monitor-enter(r1)
            boolean r0 = r2.isDestroyed()     // Catch:{ all -> 0x001b }
            if (r0 == 0) goto L_0x0016
            java.lang.String r0 = "The webview is destroyed. Ignoring action."
            com.google.android.gms.internal.gr.W(r0)     // Catch:{ all -> 0x001b }
            if (r4 == 0) goto L_0x0014
            r0 = 0
            r4.onReceiveValue(r0)     // Catch:{ all -> 0x001b }
        L_0x0014:
            monitor-exit(r1)     // Catch:{ all -> 0x001b }
        L_0x0015:
            return
        L_0x0016:
            super.evaluateJavascript(r3, r4)     // Catch:{ all -> 0x001b }
            monitor-exit(r1)     // Catch:{ all -> 0x001b }
            goto L_0x0015
        L_0x001b:
            r0 = move-exception
            monitor-exit(r1)     // Catch:{ all -> 0x001b }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.gu.evaluateJavascript(java.lang.String, android.webkit.ValueCallback):void");
    }

    public boolean isDestroyed() {
        boolean z;
        synchronized (this.mH) {
            z = this.xb;
        }
        return z;
    }

    public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimeType, long size) {
        try {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setDataAndType(Uri.parse(url), mimeType);
            getContext().startActivity(intent);
        } catch (ActivityNotFoundException e) {
            gr.S("Couldn't find an Activity to view url/mimetype: " + url + " / " + mimeType);
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:36:?, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r10, int r11) {
        /*
            r9 = this;
            r0 = 2147483647(0x7fffffff, float:NaN)
            r8 = 1073741824(0x40000000, float:2.0)
            r7 = 8
            r6 = -2147483648(0xffffffff80000000, float:-0.0)
            java.lang.Object r4 = r9.mH
            monitor-enter(r4)
            boolean r1 = r9.isInEditMode()     // Catch:{ all -> 0x00ae }
            if (r1 != 0) goto L_0x0016
            boolean r1 = r9.wZ     // Catch:{ all -> 0x00ae }
            if (r1 == 0) goto L_0x001b
        L_0x0016:
            super.onMeasure(r10, r11)     // Catch:{ all -> 0x00ae }
            monitor-exit(r4)     // Catch:{ all -> 0x00ae }
        L_0x001a:
            return
        L_0x001b:
            int r2 = android.view.View.MeasureSpec.getMode(r10)     // Catch:{ all -> 0x00ae }
            int r3 = android.view.View.MeasureSpec.getSize(r10)     // Catch:{ all -> 0x00ae }
            int r5 = android.view.View.MeasureSpec.getMode(r11)     // Catch:{ all -> 0x00ae }
            int r1 = android.view.View.MeasureSpec.getSize(r11)     // Catch:{ all -> 0x00ae }
            if (r2 == r6) goto L_0x002f
            if (r2 != r8) goto L_0x00c7
        L_0x002f:
            r2 = r3
        L_0x0030:
            if (r5 == r6) goto L_0x0034
            if (r5 != r8) goto L_0x0035
        L_0x0034:
            r0 = r1
        L_0x0035:
            com.google.android.gms.internal.ay r5 = r9.qI     // Catch:{ all -> 0x00ae }
            int r5 = r5.widthPixels     // Catch:{ all -> 0x00ae }
            if (r5 > r2) goto L_0x0041
            com.google.android.gms.internal.ay r2 = r9.qI     // Catch:{ all -> 0x00ae }
            int r2 = r2.heightPixels     // Catch:{ all -> 0x00ae }
            if (r2 <= r0) goto L_0x00b1
        L_0x0041:
            com.google.android.gms.internal.gu$a r0 = r9.wX     // Catch:{ all -> 0x00ae }
            android.content.res.Resources r0 = r0.getResources()     // Catch:{ all -> 0x00ae }
            android.util.DisplayMetrics r0 = r0.getDisplayMetrics()     // Catch:{ all -> 0x00ae }
            float r0 = r0.density     // Catch:{ all -> 0x00ae }
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ all -> 0x00ae }
            r2.<init>()     // Catch:{ all -> 0x00ae }
            java.lang.String r5 = "Not enough space to show ad. Needs "
            java.lang.StringBuilder r2 = r2.append(r5)     // Catch:{ all -> 0x00ae }
            com.google.android.gms.internal.ay r5 = r9.qI     // Catch:{ all -> 0x00ae }
            int r5 = r5.widthPixels     // Catch:{ all -> 0x00ae }
            float r5 = (float) r5     // Catch:{ all -> 0x00ae }
            float r5 = r5 / r0
            int r5 = (int) r5     // Catch:{ all -> 0x00ae }
            java.lang.StringBuilder r2 = r2.append(r5)     // Catch:{ all -> 0x00ae }
            java.lang.String r5 = "x"
            java.lang.StringBuilder r2 = r2.append(r5)     // Catch:{ all -> 0x00ae }
            com.google.android.gms.internal.ay r5 = r9.qI     // Catch:{ all -> 0x00ae }
            int r5 = r5.heightPixels     // Catch:{ all -> 0x00ae }
            float r5 = (float) r5     // Catch:{ all -> 0x00ae }
            float r5 = r5 / r0
            int r5 = (int) r5     // Catch:{ all -> 0x00ae }
            java.lang.StringBuilder r2 = r2.append(r5)     // Catch:{ all -> 0x00ae }
            java.lang.String r5 = " dp, but only has "
            java.lang.StringBuilder r2 = r2.append(r5)     // Catch:{ all -> 0x00ae }
            float r3 = (float) r3     // Catch:{ all -> 0x00ae }
            float r3 = r3 / r0
            int r3 = (int) r3     // Catch:{ all -> 0x00ae }
            java.lang.StringBuilder r2 = r2.append(r3)     // Catch:{ all -> 0x00ae }
            java.lang.String r3 = "x"
            java.lang.StringBuilder r2 = r2.append(r3)     // Catch:{ all -> 0x00ae }
            float r1 = (float) r1     // Catch:{ all -> 0x00ae }
            float r0 = r1 / r0
            int r0 = (int) r0     // Catch:{ all -> 0x00ae }
            java.lang.StringBuilder r0 = r2.append(r0)     // Catch:{ all -> 0x00ae }
            java.lang.String r1 = " dp."
            java.lang.StringBuilder r0 = r0.append(r1)     // Catch:{ all -> 0x00ae }
            java.lang.String r0 = r0.toString()     // Catch:{ all -> 0x00ae }
            com.google.android.gms.internal.gr.W(r0)     // Catch:{ all -> 0x00ae }
            int r0 = r9.getVisibility()     // Catch:{ all -> 0x00ae }
            if (r0 == r7) goto L_0x00a6
            r0 = 4
            r9.setVisibility(r0)     // Catch:{ all -> 0x00ae }
        L_0x00a6:
            r0 = 0
            r1 = 0
            r9.setMeasuredDimension(r0, r1)     // Catch:{ all -> 0x00ae }
        L_0x00ab:
            monitor-exit(r4)     // Catch:{ all -> 0x00ae }
            goto L_0x001a
        L_0x00ae:
            r0 = move-exception
            monitor-exit(r4)     // Catch:{ all -> 0x00ae }
            throw r0
        L_0x00b1:
            int r0 = r9.getVisibility()     // Catch:{ all -> 0x00ae }
            if (r0 == r7) goto L_0x00bb
            r0 = 0
            r9.setVisibility(r0)     // Catch:{ all -> 0x00ae }
        L_0x00bb:
            com.google.android.gms.internal.ay r0 = r9.qI     // Catch:{ all -> 0x00ae }
            int r0 = r0.widthPixels     // Catch:{ all -> 0x00ae }
            com.google.android.gms.internal.ay r1 = r9.qI     // Catch:{ all -> 0x00ae }
            int r1 = r1.heightPixels     // Catch:{ all -> 0x00ae }
            r9.setMeasuredDimension(r0, r1)     // Catch:{ all -> 0x00ae }
            goto L_0x00ab
        L_0x00c7:
            r2 = r0
            goto L_0x0030
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.gu.onMeasure(int, int):void");
    }

    public boolean onTouchEvent(MotionEvent event) {
        if (this.tl != null) {
            this.tl.a(event);
        }
        return super.onTouchEvent(event);
    }

    public void q(boolean z) {
        synchronized (this.mH) {
            if (this.wY != null) {
                this.wY.q(z);
            } else {
                this.xc = z;
            }
        }
    }

    public void setContext(Context context) {
        this.wX.setBaseContext(context);
    }

    public void z(boolean z) {
        synchronized (this.mH) {
            this.wZ = z;
            dJ();
        }
    }
}
