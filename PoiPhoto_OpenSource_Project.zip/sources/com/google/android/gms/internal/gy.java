package com.google.android.gms.internal;

import android.view.View;
import android.webkit.WebChromeClient;

@ey
public final class gy extends gw {
    public gy(gu guVar) {
        super(guVar);
    }

    public void onShowCustomView(View view, int requestedOrientation, WebChromeClient.CustomViewCallback customViewCallback) {
        a(view, requestedOrientation, customViewCallback);
    }
}
