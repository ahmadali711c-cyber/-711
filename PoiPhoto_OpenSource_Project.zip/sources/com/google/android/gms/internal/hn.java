package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.internal.hl;
import java.util.ArrayList;

public class hn implements Parcelable.Creator<hl.b> {
    static void a(hl.b bVar, Parcel parcel, int i) {
        int H = b.H(parcel);
        b.c(parcel, 1000, bVar.CK);
        b.a(parcel, 1, (Parcelable) bVar.Dd, i, false);
        b.c(parcel, 2, bVar.De, false);
        b.H(parcel, H);
    }

    /* renamed from: O */
    public hl.b[] newArray(int i) {
        return new hl.b[i];
    }

    /* renamed from: q */
    public hl.b createFromParcel(Parcel parcel) {
        ArrayList c;
        Status status;
        int i;
        ArrayList arrayList = null;
        int G = a.G(parcel);
        int i2 = 0;
        Status status2 = null;
        while (parcel.dataPosition() < G) {
            int F = a.F(parcel);
            switch (a.aH(F)) {
                case 1:
                    i = i2;
                    Status status3 = (Status) a.a(parcel, F, Status.CREATOR);
                    c = arrayList;
                    status = status3;
                    break;
                case 2:
                    c = a.c(parcel, F, hr.CREATOR);
                    status = status2;
                    i = i2;
                    break;
                case 1000:
                    ArrayList arrayList2 = arrayList;
                    status = status2;
                    i = a.g(parcel, F);
                    c = arrayList2;
                    break;
                default:
                    a.b(parcel, F);
                    c = arrayList;
                    status = status2;
                    i = i2;
                    break;
            }
            i2 = i;
            status2 = status;
            arrayList = c;
        }
        if (parcel.dataPosition() == G) {
            return new hl.b(i2, status2, arrayList);
        }
        throw new a.C0004a("Overread allowed size end=" + G, parcel);
    }
}
