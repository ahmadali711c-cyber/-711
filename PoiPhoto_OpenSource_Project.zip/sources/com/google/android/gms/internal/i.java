package com.google.android.gms.internal;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import com.google.android.gms.internal.o;
import dalvik.system.DexClassLoader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.security.SecureRandom;
import java.util.ArrayList;

public abstract class i extends h {
    private static Method kA;
    private static Method kB;
    private static Method kC;
    private static Method kD;
    private static Method kE;
    private static Method kF;
    private static Method kG;
    private static Method kH;
    private static Method kI;
    private static String kJ;
    private static String kK;
    private static String kL;
    private static o kM;
    static boolean kN = false;
    private static long startTime = 0;

    static class a extends Exception {
        public a() {
        }

        public a(Throwable th) {
            super(th);
        }
    }

    protected i(Context context, m mVar, n nVar) {
        super(context, mVar, nVar);
    }

    static String a(Context context, m mVar) throws a {
        if (kK != null) {
            return kK;
        }
        if (kD == null) {
            throw new a();
        }
        try {
            ByteBuffer byteBuffer = (ByteBuffer) kD.invoke((Object) null, new Object[]{context});
            if (byteBuffer == null) {
                throw new a();
            }
            kK = mVar.a(byteBuffer.array(), true);
            return kK;
        } catch (IllegalAccessException e) {
            throw new a(e);
        } catch (InvocationTargetException e2) {
            throw new a(e2);
        }
    }

    static ArrayList<Long> a(MotionEvent motionEvent, DisplayMetrics displayMetrics) throws a {
        if (kE == null || motionEvent == null) {
            throw new a();
        }
        try {
            return (ArrayList) kE.invoke((Object) null, new Object[]{motionEvent, displayMetrics});
        } catch (IllegalAccessException e) {
            throw new a(e);
        } catch (InvocationTargetException e2) {
            throw new a(e2);
        }
    }

    protected static synchronized void a(String str, Context context, m mVar) {
        synchronized (i.class) {
            if (!kN) {
                try {
                    kM = new o(mVar, (SecureRandom) null);
                    kJ = str;
                    g(context);
                    startTime = w().longValue();
                    kN = true;
                } catch (a | UnsupportedOperationException e) {
                }
            }
        }
    }

    static String b(Context context, m mVar) throws a {
        if (kL != null) {
            return kL;
        }
        if (kG == null) {
            throw new a();
        }
        try {
            ByteBuffer byteBuffer = (ByteBuffer) kG.invoke((Object) null, new Object[]{context});
            if (byteBuffer == null) {
                throw new a();
            }
            kL = mVar.a(byteBuffer.array(), true);
            return kL;
        } catch (IllegalAccessException e) {
            throw new a(e);
        } catch (InvocationTargetException e2) {
            throw new a(e2);
        }
    }

    private static String b(byte[] bArr, String str) throws a {
        try {
            return new String(kM.c(bArr, str), "UTF-8");
        } catch (o.a e) {
            throw new a(e);
        } catch (UnsupportedEncodingException e2) {
            throw new a(e2);
        }
    }

    static String d(Context context) throws a {
        if (kF == null) {
            throw new a();
        }
        try {
            String str = (String) kF.invoke((Object) null, new Object[]{context});
            if (str != null) {
                return str;
            }
            throw new a();
        } catch (IllegalAccessException e) {
            throw new a(e);
        } catch (InvocationTargetException e2) {
            throw new a(e2);
        }
    }

    static ArrayList<Long> e(Context context) throws a {
        if (kH == null) {
            throw new a();
        }
        try {
            ArrayList<Long> arrayList = (ArrayList) kH.invoke((Object) null, new Object[]{context});
            if (arrayList != null && arrayList.size() == 2) {
                return arrayList;
            }
            throw new a();
        } catch (IllegalAccessException e) {
            throw new a(e);
        } catch (InvocationTargetException e2) {
            throw new a(e2);
        }
    }

    static int[] f(Context context) throws a {
        if (kI == null) {
            throw new a();
        }
        try {
            return (int[]) kI.invoke((Object) null, new Object[]{context});
        } catch (IllegalAccessException e) {
            throw new a(e);
        } catch (InvocationTargetException e2) {
            throw new a(e2);
        }
    }

    private static void g(Context context) throws a {
        File file;
        File createTempFile;
        try {
            byte[] b = kM.b(q.getKey());
            byte[] c = kM.c(b, q.E());
            File cacheDir = context.getCacheDir();
            if (cacheDir == null && (cacheDir = context.getDir("dex", 0)) == null) {
                throw new a();
            }
            file = cacheDir;
            createTempFile = File.createTempFile("ads", ".jar", file);
            FileOutputStream fileOutputStream = new FileOutputStream(createTempFile);
            fileOutputStream.write(c, 0, c.length);
            fileOutputStream.close();
            DexClassLoader dexClassLoader = new DexClassLoader(createTempFile.getAbsolutePath(), file.getAbsolutePath(), (String) null, context.getClassLoader());
            Class loadClass = dexClassLoader.loadClass(b(b, q.H()));
            Class loadClass2 = dexClassLoader.loadClass(b(b, q.T()));
            Class loadClass3 = dexClassLoader.loadClass(b(b, q.N()));
            Class loadClass4 = dexClassLoader.loadClass(b(b, q.L()));
            Class loadClass5 = dexClassLoader.loadClass(b(b, q.V()));
            Class loadClass6 = dexClassLoader.loadClass(b(b, q.J()));
            Class loadClass7 = dexClassLoader.loadClass(b(b, q.R()));
            Class loadClass8 = dexClassLoader.loadClass(b(b, q.P()));
            Class loadClass9 = dexClassLoader.loadClass(b(b, q.F()));
            kA = loadClass.getMethod(b(b, q.I()), new Class[0]);
            kB = loadClass2.getMethod(b(b, q.U()), new Class[0]);
            kC = loadClass3.getMethod(b(b, q.O()), new Class[0]);
            kD = loadClass4.getMethod(b(b, q.M()), new Class[]{Context.class});
            kE = loadClass5.getMethod(b(b, q.W()), new Class[]{MotionEvent.class, DisplayMetrics.class});
            kF = loadClass6.getMethod(b(b, q.K()), new Class[]{Context.class});
            kG = loadClass7.getMethod(b(b, q.S()), new Class[]{Context.class});
            kH = loadClass8.getMethod(b(b, q.Q()), new Class[]{Context.class});
            kI = loadClass9.getMethod(b(b, q.G()), new Class[]{Context.class});
            String name = createTempFile.getName();
            createTempFile.delete();
            new File(file, name.replace(".jar", ".dex")).delete();
        } catch (FileNotFoundException e) {
            throw new a(e);
        } catch (IOException e2) {
            throw new a(e2);
        } catch (ClassNotFoundException e3) {
            throw new a(e3);
        } catch (o.a e4) {
            throw new a(e4);
        } catch (NoSuchMethodException e5) {
            throw new a(e5);
        } catch (NullPointerException e6) {
            throw new a(e6);
        } catch (Throwable th) {
            String name2 = createTempFile.getName();
            createTempFile.delete();
            new File(file, name2.replace(".jar", ".dex")).delete();
            throw th;
        }
    }

    static String v() throws a {
        if (kJ != null) {
            return kJ;
        }
        throw new a();
    }

    static Long w() throws a {
        if (kA == null) {
            throw new a();
        }
        try {
            return (Long) kA.invoke((Object) null, new Object[0]);
        } catch (IllegalAccessException e) {
            throw new a(e);
        } catch (InvocationTargetException e2) {
            throw new a(e2);
        }
    }

    static String x() throws a {
        if (kC == null) {
            throw new a();
        }
        try {
            return (String) kC.invoke((Object) null, new Object[0]);
        } catch (IllegalAccessException e) {
            throw new a(e);
        } catch (InvocationTargetException e2) {
            throw new a(e2);
        }
    }

    static Long y() throws a {
        if (kB == null) {
            throw new a();
        }
        try {
            return (Long) kB.invoke((Object) null, new Object[0]);
        } catch (IllegalAccessException e) {
            throw new a(e);
        } catch (InvocationTargetException e2) {
            throw new a(e2);
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:33:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:?, code lost:
        return;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x0090 A[ExcHandler: IOException (e java.io.IOException), Splitter:B:6:0x0010] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void b(android.content.Context r7) {
        /*
            r6 = this;
            r0 = 1
            java.lang.String r1 = x()     // Catch:{ a -> 0x00a1, IOException -> 0x0090 }
            r6.a((int) r0, (java.lang.String) r1)     // Catch:{ a -> 0x00a1, IOException -> 0x0090 }
        L_0x0008:
            r0 = 2
            java.lang.String r1 = v()     // Catch:{ a -> 0x009e, IOException -> 0x0090 }
            r6.a((int) r0, (java.lang.String) r1)     // Catch:{ a -> 0x009e, IOException -> 0x0090 }
        L_0x0010:
            java.lang.Long r0 = w()     // Catch:{ a -> 0x009c, IOException -> 0x0090 }
            long r0 = r0.longValue()     // Catch:{ a -> 0x009c, IOException -> 0x0090 }
            r2 = 25
            r6.a((int) r2, (long) r0)     // Catch:{ a -> 0x009c, IOException -> 0x0090 }
            long r2 = startTime     // Catch:{ a -> 0x009c, IOException -> 0x0090 }
            r4 = 0
            int r2 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r2 == 0) goto L_0x0034
            r2 = 17
            long r3 = startTime     // Catch:{ a -> 0x009c, IOException -> 0x0090 }
            long r0 = r0 - r3
            r6.a((int) r2, (long) r0)     // Catch:{ a -> 0x009c, IOException -> 0x0090 }
            r0 = 23
            long r1 = startTime     // Catch:{ a -> 0x009c, IOException -> 0x0090 }
            r6.a((int) r0, (long) r1)     // Catch:{ a -> 0x009c, IOException -> 0x0090 }
        L_0x0034:
            java.util.ArrayList r1 = e(r7)     // Catch:{ a -> 0x009a, IOException -> 0x0090 }
            r2 = 31
            r0 = 0
            java.lang.Object r0 = r1.get(r0)     // Catch:{ a -> 0x009a, IOException -> 0x0090 }
            java.lang.Long r0 = (java.lang.Long) r0     // Catch:{ a -> 0x009a, IOException -> 0x0090 }
            long r3 = r0.longValue()     // Catch:{ a -> 0x009a, IOException -> 0x0090 }
            r6.a((int) r2, (long) r3)     // Catch:{ a -> 0x009a, IOException -> 0x0090 }
            r2 = 32
            r0 = 1
            java.lang.Object r0 = r1.get(r0)     // Catch:{ a -> 0x009a, IOException -> 0x0090 }
            java.lang.Long r0 = (java.lang.Long) r0     // Catch:{ a -> 0x009a, IOException -> 0x0090 }
            long r0 = r0.longValue()     // Catch:{ a -> 0x009a, IOException -> 0x0090 }
            r6.a((int) r2, (long) r0)     // Catch:{ a -> 0x009a, IOException -> 0x0090 }
        L_0x0058:
            r0 = 33
            java.lang.Long r1 = y()     // Catch:{ a -> 0x0098, IOException -> 0x0090 }
            long r1 = r1.longValue()     // Catch:{ a -> 0x0098, IOException -> 0x0090 }
            r6.a((int) r0, (long) r1)     // Catch:{ a -> 0x0098, IOException -> 0x0090 }
        L_0x0065:
            r0 = 27
            com.google.android.gms.internal.m r1 = r6.ky     // Catch:{ a -> 0x0096, IOException -> 0x0090 }
            java.lang.String r1 = a((android.content.Context) r7, (com.google.android.gms.internal.m) r1)     // Catch:{ a -> 0x0096, IOException -> 0x0090 }
            r6.a((int) r0, (java.lang.String) r1)     // Catch:{ a -> 0x0096, IOException -> 0x0090 }
        L_0x0070:
            r0 = 29
            com.google.android.gms.internal.m r1 = r6.ky     // Catch:{ a -> 0x0094, IOException -> 0x0090 }
            java.lang.String r1 = b((android.content.Context) r7, (com.google.android.gms.internal.m) r1)     // Catch:{ a -> 0x0094, IOException -> 0x0090 }
            r6.a((int) r0, (java.lang.String) r1)     // Catch:{ a -> 0x0094, IOException -> 0x0090 }
        L_0x007b:
            int[] r0 = f(r7)     // Catch:{ a -> 0x0092, IOException -> 0x0090 }
            r1 = 5
            r2 = 0
            r2 = r0[r2]     // Catch:{ a -> 0x0092, IOException -> 0x0090 }
            long r2 = (long) r2     // Catch:{ a -> 0x0092, IOException -> 0x0090 }
            r6.a((int) r1, (long) r2)     // Catch:{ a -> 0x0092, IOException -> 0x0090 }
            r1 = 6
            r2 = 1
            r0 = r0[r2]     // Catch:{ a -> 0x0092, IOException -> 0x0090 }
            long r2 = (long) r0     // Catch:{ a -> 0x0092, IOException -> 0x0090 }
            r6.a((int) r1, (long) r2)     // Catch:{ a -> 0x0092, IOException -> 0x0090 }
        L_0x008f:
            return
        L_0x0090:
            r0 = move-exception
            goto L_0x008f
        L_0x0092:
            r0 = move-exception
            goto L_0x008f
        L_0x0094:
            r0 = move-exception
            goto L_0x007b
        L_0x0096:
            r0 = move-exception
            goto L_0x0070
        L_0x0098:
            r0 = move-exception
            goto L_0x0065
        L_0x009a:
            r0 = move-exception
            goto L_0x0058
        L_0x009c:
            r0 = move-exception
            goto L_0x0034
        L_0x009e:
            r0 = move-exception
            goto L_0x0010
        L_0x00a1:
            r0 = move-exception
            goto L_0x0008
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.i.b(android.content.Context):void");
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:20:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:?, code lost:
        return;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Removed duplicated region for block: B:13:0x005d A[ExcHandler: IOException (e java.io.IOException), Splitter:B:1:0x0001] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void c(android.content.Context r6) {
        /*
            r5 = this;
            r0 = 2
            java.lang.String r1 = v()     // Catch:{ a -> 0x0065, IOException -> 0x005d }
            r5.a((int) r0, (java.lang.String) r1)     // Catch:{ a -> 0x0065, IOException -> 0x005d }
        L_0x0008:
            r0 = 1
            java.lang.String r1 = x()     // Catch:{ a -> 0x0063, IOException -> 0x005d }
            r5.a((int) r0, (java.lang.String) r1)     // Catch:{ a -> 0x0063, IOException -> 0x005d }
        L_0x0010:
            r0 = 25
            java.lang.Long r1 = w()     // Catch:{ a -> 0x0061, IOException -> 0x005d }
            long r1 = r1.longValue()     // Catch:{ a -> 0x0061, IOException -> 0x005d }
            r5.a((int) r0, (long) r1)     // Catch:{ a -> 0x0061, IOException -> 0x005d }
        L_0x001d:
            android.view.MotionEvent r0 = r5.kw     // Catch:{ a -> 0x005f, IOException -> 0x005d }
            android.util.DisplayMetrics r1 = r5.kx     // Catch:{ a -> 0x005f, IOException -> 0x005d }
            java.util.ArrayList r1 = a((android.view.MotionEvent) r0, (android.util.DisplayMetrics) r1)     // Catch:{ a -> 0x005f, IOException -> 0x005d }
            r2 = 14
            r0 = 0
            java.lang.Object r0 = r1.get(r0)     // Catch:{ a -> 0x005f, IOException -> 0x005d }
            java.lang.Long r0 = (java.lang.Long) r0     // Catch:{ a -> 0x005f, IOException -> 0x005d }
            long r3 = r0.longValue()     // Catch:{ a -> 0x005f, IOException -> 0x005d }
            r5.a((int) r2, (long) r3)     // Catch:{ a -> 0x005f, IOException -> 0x005d }
            r2 = 15
            r0 = 1
            java.lang.Object r0 = r1.get(r0)     // Catch:{ a -> 0x005f, IOException -> 0x005d }
            java.lang.Long r0 = (java.lang.Long) r0     // Catch:{ a -> 0x005f, IOException -> 0x005d }
            long r3 = r0.longValue()     // Catch:{ a -> 0x005f, IOException -> 0x005d }
            r5.a((int) r2, (long) r3)     // Catch:{ a -> 0x005f, IOException -> 0x005d }
            int r0 = r1.size()     // Catch:{ a -> 0x005f, IOException -> 0x005d }
            r2 = 3
            if (r0 < r2) goto L_0x005c
            r2 = 16
            r0 = 2
            java.lang.Object r0 = r1.get(r0)     // Catch:{ a -> 0x005f, IOException -> 0x005d }
            java.lang.Long r0 = (java.lang.Long) r0     // Catch:{ a -> 0x005f, IOException -> 0x005d }
            long r0 = r0.longValue()     // Catch:{ a -> 0x005f, IOException -> 0x005d }
            r5.a((int) r2, (long) r0)     // Catch:{ a -> 0x005f, IOException -> 0x005d }
        L_0x005c:
            return
        L_0x005d:
            r0 = move-exception
            goto L_0x005c
        L_0x005f:
            r0 = move-exception
            goto L_0x005c
        L_0x0061:
            r0 = move-exception
            goto L_0x001d
        L_0x0063:
            r0 = move-exception
            goto L_0x0010
        L_0x0065:
            r0 = move-exception
            goto L_0x0008
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.i.c(android.content.Context):void");
    }
}
