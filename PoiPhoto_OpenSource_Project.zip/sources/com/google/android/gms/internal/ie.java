package com.google.android.gms.internal;

import android.content.Context;

public class ie {
    private final np<ni> Ee;
    private final Context mContext;

    private ie(Context context, np<ni> npVar) {
        this.mContext = context;
        this.Ee = npVar;
    }

    public static ie a(Context context, np<ni> npVar) {
        return new ie(context, npVar);
    }
}
