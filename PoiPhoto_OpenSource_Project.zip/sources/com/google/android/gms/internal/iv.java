package com.google.android.gms.internal;

import org.json.JSONObject;

public interface iv {
    void a(long j, int i, JSONObject jSONObject);

    void n(long j);
}
