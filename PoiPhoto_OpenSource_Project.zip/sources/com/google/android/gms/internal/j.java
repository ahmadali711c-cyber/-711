package com.google.android.gms.internal;

import android.content.Context;
import android.os.AsyncTask;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.internal.i;
import java.io.IOException;
import java.util.concurrent.CountDownLatch;

public class j extends i {
    /* access modifiers changed from: private */
    public static AdvertisingIdClient kO;
    /* access modifiers changed from: private */
    public static CountDownLatch kP = new CountDownLatch(1);
    /* access modifiers changed from: private */
    public static boolean kQ;

    class a {
        private String kR;
        private boolean kS;

        public a(String str, boolean z) {
            this.kR = str;
            this.kS = z;
        }

        public String getId() {
            return this.kR;
        }

        public boolean isLimitAdTrackingEnabled() {
            return this.kS;
        }
    }

    protected j(Context context, m mVar, n nVar) {
        super(context, mVar, nVar);
    }

    public static j a(String str, Context context) {
        e eVar = new e();
        a(str, context, eVar);
        synchronized (j.class) {
            if (kO == null) {
                kO = new AdvertisingIdClient(context);
                new AsyncTask<Void, Void, Void>() {
                    /* access modifiers changed from: protected */
                    /* renamed from: a */
                    public Void doInBackground(Void... voidArr) {
                        try {
                            j.kO.start();
                        } catch (GooglePlayServicesNotAvailableException e) {
                            boolean unused = j.kQ = true;
                            AdvertisingIdClient unused2 = j.kO = null;
                        } catch (IOException e2) {
                            AdvertisingIdClient unused3 = j.kO = null;
                        } catch (GooglePlayServicesRepairableException e3) {
                            AdvertisingIdClient unused4 = j.kO = null;
                        }
                        j.kP.countDown();
                        return null;
                    }
                }.execute(new Void[0]);
            }
        }
        return new j(context, eVar, new p(239));
    }

    /* access modifiers changed from: protected */
    public void b(Context context) {
        super.b(context);
        try {
            if (kQ) {
                a(24, d(context));
                return;
            }
            a z = z();
            a(28, z.isLimitAdTrackingEnabled() ? 1 : 0);
            String id = z.getId();
            if (id != null) {
                a(26, 5);
                a(24, id);
            }
        } catch (i.a | IOException e) {
        }
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x003c, code lost:
        r2 = r3.getId();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x0040, code lost:
        if (r2 == null) goto L_0x0094;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0048, code lost:
        if (r2.matches("^[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}$") == false) goto L_0x0094;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x004a, code lost:
        r4 = new byte[16];
        r1 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0051, code lost:
        if (r0 >= r2.length()) goto L_0x0082;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:0x0055, code lost:
        if (r0 == 8) goto L_0x0063;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:33:0x0059, code lost:
        if (r0 == 13) goto L_0x0063;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x005d, code lost:
        if (r0 == 18) goto L_0x0063;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:37:0x0061, code lost:
        if (r0 != 23) goto L_0x0065;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:38:0x0063, code lost:
        r0 = r0 + 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:39:0x0065, code lost:
        r4[r1] = (byte) ((java.lang.Character.digit(r2.charAt(r0), 16) << 4) + java.lang.Character.digit(r2.charAt(r0 + 1), 16));
        r1 = r1 + 1;
        r0 = r0 + 2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:40:0x0082, code lost:
        r0 = r8.ky.a(r4, true);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:42:0x0094, code lost:
        r0 = r2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:49:?, code lost:
        return new com.google.android.gms.internal.j.a(r8, r0, r3.isLimitAdTrackingEnabled());
     */
    /* JADX WARNING: No exception handlers in catch block: Catch:{  } */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public com.google.android.gms.internal.j.a z() throws java.io.IOException {
        /*
            r8 = this;
            r7 = 16
            r0 = 0
            java.lang.Class<com.google.android.gms.internal.j> r1 = com.google.android.gms.internal.j.class
            monitor-enter(r1)
            java.util.concurrent.CountDownLatch r2 = kP     // Catch:{ InterruptedException -> 0x001b }
            r3 = 2
            java.util.concurrent.TimeUnit r5 = java.util.concurrent.TimeUnit.SECONDS     // Catch:{ InterruptedException -> 0x001b }
            boolean r2 = r2.await(r3, r5)     // Catch:{ InterruptedException -> 0x001b }
            if (r2 != 0) goto L_0x0028
            com.google.android.gms.internal.j$a r0 = new com.google.android.gms.internal.j$a     // Catch:{ InterruptedException -> 0x001b }
            r2 = 0
            r3 = 0
            r0.<init>(r2, r3)     // Catch:{ InterruptedException -> 0x001b }
            monitor-exit(r1)     // Catch:{ all -> 0x0025 }
        L_0x001a:
            return r0
        L_0x001b:
            r0 = move-exception
            com.google.android.gms.internal.j$a r0 = new com.google.android.gms.internal.j$a     // Catch:{ all -> 0x0025 }
            r2 = 0
            r3 = 0
            r0.<init>(r2, r3)     // Catch:{ all -> 0x0025 }
            monitor-exit(r1)     // Catch:{ all -> 0x0025 }
            goto L_0x001a
        L_0x0025:
            r0 = move-exception
            monitor-exit(r1)     // Catch:{ all -> 0x0025 }
            throw r0
        L_0x0028:
            com.google.android.gms.ads.identifier.AdvertisingIdClient r2 = kO     // Catch:{ all -> 0x0025 }
            if (r2 != 0) goto L_0x0035
            com.google.android.gms.internal.j$a r0 = new com.google.android.gms.internal.j$a     // Catch:{ all -> 0x0025 }
            r2 = 0
            r3 = 0
            r0.<init>(r2, r3)     // Catch:{ all -> 0x0025 }
            monitor-exit(r1)     // Catch:{ all -> 0x0025 }
            goto L_0x001a
        L_0x0035:
            com.google.android.gms.ads.identifier.AdvertisingIdClient r2 = kO     // Catch:{ all -> 0x0025 }
            com.google.android.gms.ads.identifier.AdvertisingIdClient$Info r3 = r2.getInfo()     // Catch:{ all -> 0x0025 }
            monitor-exit(r1)     // Catch:{ all -> 0x0025 }
            java.lang.String r2 = r3.getId()
            if (r2 == 0) goto L_0x0094
            java.lang.String r1 = "^[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}$"
            boolean r1 = r2.matches(r1)
            if (r1 == 0) goto L_0x0094
            byte[] r4 = new byte[r7]
            r1 = r0
        L_0x004d:
            int r5 = r2.length()
            if (r0 >= r5) goto L_0x0082
            r5 = 8
            if (r0 == r5) goto L_0x0063
            r5 = 13
            if (r0 == r5) goto L_0x0063
            r5 = 18
            if (r0 == r5) goto L_0x0063
            r5 = 23
            if (r0 != r5) goto L_0x0065
        L_0x0063:
            int r0 = r0 + 1
        L_0x0065:
            char r5 = r2.charAt(r0)
            int r5 = java.lang.Character.digit(r5, r7)
            int r5 = r5 << 4
            int r6 = r0 + 1
            char r6 = r2.charAt(r6)
            int r6 = java.lang.Character.digit(r6, r7)
            int r5 = r5 + r6
            byte r5 = (byte) r5
            r4[r1] = r5
            int r1 = r1 + 1
            int r0 = r0 + 2
            goto L_0x004d
        L_0x0082:
            com.google.android.gms.internal.m r0 = r8.ky
            r1 = 1
            java.lang.String r0 = r0.a((byte[]) r4, (boolean) r1)
        L_0x0089:
            com.google.android.gms.internal.j$a r1 = new com.google.android.gms.internal.j$a
            boolean r2 = r3.isLimitAdTrackingEnabled()
            r1.<init>(r0, r2)
            r0 = r1
            goto L_0x001a
        L_0x0094:
            r0 = r2
            goto L_0x0089
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.j.z():com.google.android.gms.internal.j$a");
    }
}
