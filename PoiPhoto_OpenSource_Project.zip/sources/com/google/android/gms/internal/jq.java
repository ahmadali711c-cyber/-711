package com.google.android.gms.internal;

import android.accounts.Account;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface jq extends IInterface {

    public static abstract class a extends Binder implements jq {
        public a() {
            attachInterface(this, "com.google.android.gms.common.internal.IAccountAccessor");
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            switch (code) {
                case 2:
                    data.enforceInterface("com.google.android.gms.common.internal.IAccountAccessor");
                    Account hk = hk();
                    reply.writeNoException();
                    if (hk != null) {
                        reply.writeInt(1);
                        hk.writeToParcel(reply, 1);
                        return true;
                    }
                    reply.writeInt(0);
                    return true;
                case 1598968902:
                    reply.writeString("com.google.android.gms.common.internal.IAccountAccessor");
                    return true;
                default:
                    return super.onTransact(code, data, reply, flags);
            }
        }
    }

    Account hk() throws RemoteException;
}
