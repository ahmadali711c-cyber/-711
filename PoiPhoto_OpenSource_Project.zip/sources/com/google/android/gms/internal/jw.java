package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.internal.jg;
import java.util.ArrayList;

public class jw implements Parcelable.Creator<jg.a> {
    static void a(jg.a aVar, Parcel parcel, int i) {
        int H = b.H(parcel);
        b.a(parcel, 1, aVar.getAccountName(), false);
        b.c(parcel, 1000, aVar.getVersionCode());
        b.b(parcel, 2, aVar.ho(), false);
        b.c(parcel, 3, aVar.hn());
        b.a(parcel, 4, aVar.hq(), false);
        b.H(parcel, H);
    }

    /* renamed from: E */
    public jg.a createFromParcel(Parcel parcel) {
        int i = 0;
        String str = null;
        int G = a.G(parcel);
        ArrayList<String> arrayList = null;
        String str2 = null;
        int i2 = 0;
        while (parcel.dataPosition() < G) {
            int F = a.F(parcel);
            switch (a.aH(F)) {
                case 1:
                    str2 = a.o(parcel, F);
                    break;
                case 2:
                    arrayList = a.C(parcel, F);
                    break;
                case 3:
                    i = a.g(parcel, F);
                    break;
                case 4:
                    str = a.o(parcel, F);
                    break;
                case 1000:
                    i2 = a.g(parcel, F);
                    break;
                default:
                    a.b(parcel, F);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new jg.a(i2, str2, arrayList, i, str);
        }
        throw new a.C0004a("Overread allowed size end=" + G, parcel);
    }

    /* renamed from: aG */
    public jg.a[] newArray(int i) {
        return new jg.a[i];
    }
}
