package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.android.gms.internal.kh;

public class kb extends kh.a {
    public void aI(int i) throws RemoteException {
    }
}
