package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.kr;
import java.util.ArrayList;
import java.util.HashMap;

public class kv implements SafeParcelable {
    public static final kw CREATOR = new kw();
    private final int CK;
    private final HashMap<String, HashMap<String, kr.a<?, ?>>> NV;
    private final ArrayList<a> NW;
    private final String NX;

    public static class a implements SafeParcelable {
        public static final kx CREATOR = new kx();
        final ArrayList<b> NY;
        final String className;
        final int versionCode;

        a(int i, String str, ArrayList<b> arrayList) {
            this.versionCode = i;
            this.className = str;
            this.NY = arrayList;
        }

        a(String str, HashMap<String, kr.a<?, ?>> hashMap) {
            this.versionCode = 1;
            this.className = str;
            this.NY = a(hashMap);
        }

        private static ArrayList<b> a(HashMap<String, kr.a<?, ?>> hashMap) {
            if (hashMap == null) {
                return null;
            }
            ArrayList<b> arrayList = new ArrayList<>();
            for (String next : hashMap.keySet()) {
                arrayList.add(new b(next, hashMap.get(next)));
            }
            return arrayList;
        }

        public int describeContents() {
            kx kxVar = CREATOR;
            return 0;
        }

        /* access modifiers changed from: package-private */
        public HashMap<String, kr.a<?, ?>> ib() {
            HashMap<String, kr.a<?, ?>> hashMap = new HashMap<>();
            int size = this.NY.size();
            for (int i = 0; i < size; i++) {
                b bVar = this.NY.get(i);
                hashMap.put(bVar.fv, bVar.NZ);
            }
            return hashMap;
        }

        public void writeToParcel(Parcel out, int flags) {
            kx kxVar = CREATOR;
            kx.a(this, out, flags);
        }
    }

    public static class b implements SafeParcelable {
        public static final ku CREATOR = new ku();
        final kr.a<?, ?> NZ;
        final String fv;
        final int versionCode;

        b(int i, String str, kr.a<?, ?> aVar) {
            this.versionCode = i;
            this.fv = str;
            this.NZ = aVar;
        }

        b(String str, kr.a<?, ?> aVar) {
            this.versionCode = 1;
            this.fv = str;
            this.NZ = aVar;
        }

        public int describeContents() {
            ku kuVar = CREATOR;
            return 0;
        }

        public void writeToParcel(Parcel out, int flags) {
            ku kuVar = CREATOR;
            ku.a(this, out, flags);
        }
    }

    kv(int i, ArrayList<a> arrayList, String str) {
        this.CK = i;
        this.NW = null;
        this.NV = c(arrayList);
        this.NX = (String) jx.i(str);
        hX();
    }

    public kv(Class<? extends kr> cls) {
        this.CK = 1;
        this.NW = null;
        this.NV = new HashMap<>();
        this.NX = cls.getCanonicalName();
    }

    private static HashMap<String, HashMap<String, kr.a<?, ?>>> c(ArrayList<a> arrayList) {
        HashMap<String, HashMap<String, kr.a<?, ?>>> hashMap = new HashMap<>();
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            a aVar = arrayList.get(i);
            hashMap.put(aVar.className, aVar.ib());
        }
        return hashMap;
    }

    public void a(Class<? extends kr> cls, HashMap<String, kr.a<?, ?>> hashMap) {
        this.NV.put(cls.getCanonicalName(), hashMap);
    }

    public boolean b(Class<? extends kr> cls) {
        return this.NV.containsKey(cls.getCanonicalName());
    }

    public HashMap<String, kr.a<?, ?>> bg(String str) {
        return this.NV.get(str);
    }

    public int describeContents() {
        kw kwVar = CREATOR;
        return 0;
    }

    /* access modifiers changed from: package-private */
    public int getVersionCode() {
        return this.CK;
    }

    public void hX() {
        for (String str : this.NV.keySet()) {
            HashMap hashMap = this.NV.get(str);
            for (String str2 : hashMap.keySet()) {
                ((kr.a) hashMap.get(str2)).a(this);
            }
        }
    }

    public void hY() {
        for (String next : this.NV.keySet()) {
            HashMap hashMap = this.NV.get(next);
            HashMap hashMap2 = new HashMap();
            for (String str : hashMap.keySet()) {
                hashMap2.put(str, ((kr.a) hashMap.get(str)).hN());
            }
            this.NV.put(next, hashMap2);
        }
    }

    /* access modifiers changed from: package-private */
    public ArrayList<a> hZ() {
        ArrayList<a> arrayList = new ArrayList<>();
        for (String next : this.NV.keySet()) {
            arrayList.add(new a(next, this.NV.get(next)));
        }
        return arrayList;
    }

    public String ia() {
        return this.NX;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (String next : this.NV.keySet()) {
            sb.append(next).append(":\n");
            HashMap hashMap = this.NV.get(next);
            for (String str : hashMap.keySet()) {
                sb.append("  ").append(str).append(": ");
                sb.append(hashMap.get(str));
            }
        }
        return sb.toString();
    }

    public void writeToParcel(Parcel out, int flags) {
        kw kwVar = CREATOR;
        kw.a(this, out, flags);
    }
}
