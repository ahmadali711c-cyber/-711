package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.internal.kv;
import java.util.ArrayList;

public class kx implements Parcelable.Creator<kv.a> {
    static void a(kv.a aVar, Parcel parcel, int i) {
        int H = b.H(parcel);
        b.c(parcel, 1, aVar.versionCode);
        b.a(parcel, 2, aVar.className, false);
        b.c(parcel, 3, aVar.NY, false);
        b.H(parcel, H);
    }

    /* renamed from: P */
    public kv.a createFromParcel(Parcel parcel) {
        ArrayList arrayList = null;
        int G = a.G(parcel);
        int i = 0;
        String str = null;
        while (parcel.dataPosition() < G) {
            int F = a.F(parcel);
            switch (a.aH(F)) {
                case 1:
                    i = a.g(parcel, F);
                    break;
                case 2:
                    str = a.o(parcel, F);
                    break;
                case 3:
                    arrayList = a.c(parcel, F, kv.b.CREATOR);
                    break;
                default:
                    a.b(parcel, F);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new kv.a(i, str, arrayList);
        }
        throw new a.C0004a("Overread allowed size end=" + G, parcel);
    }

    /* renamed from: aQ */
    public kv.a[] newArray(int i) {
        return new kv.a[i];
    }
}
