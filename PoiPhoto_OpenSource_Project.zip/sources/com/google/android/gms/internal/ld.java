package com.google.android.gms.internal;

public interface ld {
    long currentTimeMillis();

    long elapsedRealtime();
}
