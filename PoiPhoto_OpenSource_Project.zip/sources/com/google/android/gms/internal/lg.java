package com.google.android.gms.internal;

public final class lg {
    public static boolean aV(int i) {
        return i >= 3200000;
    }
}
