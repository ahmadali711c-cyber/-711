package com.google.android.gms.internal;

import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.b;
import com.google.android.gms.drive.metadata.internal.f;

public class lr {
    public static final MetadataField<Integer> RW = new f("contentAvailability", 4300000);
    public static final MetadataField<Boolean> RX = new b("isPinnable", 4300000);
}
