package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.internal.jl;
import com.google.android.gms.internal.lz;

public class lv extends jl<lz> implements lu {
    private final String DZ;

    public lv(Context context, Looper looper, GoogleApiClient.ConnectionCallbacks connectionCallbacks, GoogleApiClient.OnConnectionFailedListener onConnectionFailedListener, String str, String[] strArr) {
        super(context, looper, connectionCallbacks, onConnectionFailedListener, strArr);
        this.DZ = str;
    }

    /* access modifiers changed from: protected */
    public void a(jt jtVar, jl.e eVar) throws RemoteException {
        jtVar.a((js) eVar, (int) GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, getContext().getPackageName(), this.DZ, hv(), new Bundle());
    }

    /* access modifiers changed from: protected */
    /* renamed from: ar */
    public lz l(IBinder iBinder) {
        return lz.a.av(iBinder);
    }

    /* access modifiers changed from: protected */
    public String bK() {
        return "com.google.android.gms.fitness.GoogleFitnessService.START";
    }

    /* access modifiers changed from: protected */
    public String bL() {
        return "com.google.android.gms.fitness.internal.IGoogleFitnessService";
    }

    public lz jM() throws DeadObjectException {
        return (lz) hw();
    }
}
