package com.google.android.gms.internal;

public interface m {
    String a(byte[] bArr, boolean z);

    byte[] a(String str, boolean z) throws IllegalArgumentException;
}
