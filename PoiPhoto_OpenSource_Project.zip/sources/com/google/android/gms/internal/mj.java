package com.google.android.gms.internal;

import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.api.BaseImplementation;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.fitness.HistoryApi;
import com.google.android.gms.fitness.data.DataSet;
import com.google.android.gms.fitness.request.DataDeleteRequest;
import com.google.android.gms.fitness.request.DataReadRequest;
import com.google.android.gms.fitness.request.e;
import com.google.android.gms.fitness.result.DataReadResult;
import com.google.android.gms.internal.lu;
import com.google.android.gms.internal.lw;

public class mj implements HistoryApi {

    private static class a extends lw.a {
        private final BaseImplementation.b<DataReadResult> Ea;
        private int Vi;
        private DataReadResult Vj;

        private a(BaseImplementation.b<DataReadResult> bVar) {
            this.Vi = 0;
            this.Vj = null;
            this.Ea = bVar;
        }

        public void a(DataReadResult dataReadResult) {
            synchronized (this) {
                Log.v("Fitness", "Received batch result");
                if (this.Vj == null) {
                    this.Vj = dataReadResult;
                } else {
                    this.Vj.b(dataReadResult);
                }
                this.Vi++;
                if (this.Vi == this.Vj.kr()) {
                    this.Ea.b(this.Vj);
                }
            }
        }
    }

    public PendingResult<Status> deleteData(GoogleApiClient client, final DataDeleteRequest request) {
        return client.a(new lu.c(client) {
            /* access modifiers changed from: protected */
            public void a(lu luVar) throws RemoteException {
                luVar.jM().a(request, (md) new lu.b(this), luVar.getContext().getPackageName());
            }
        });
    }

    public PendingResult<Status> insertData(GoogleApiClient client, final DataSet dataSet) {
        return client.a(new lu.c(client) {
            /* access modifiers changed from: protected */
            public void a(lu luVar) throws RemoteException {
                luVar.jM().a(new e.a().b(dataSet).jU(), (md) new lu.b(this), luVar.getContext().getPackageName());
            }
        });
    }

    public PendingResult<DataReadResult> readData(GoogleApiClient client, final DataReadRequest request) {
        return client.a(new lu.a<DataReadResult>(client) {
            /* access modifiers changed from: protected */
            public void a(lu luVar) throws RemoteException {
                luVar.jM().a(request, (lw) new a(this), luVar.getContext().getPackageName());
            }

            /* access modifiers changed from: protected */
            /* renamed from: x */
            public DataReadResult c(Status status) {
                return DataReadResult.a(status, request);
            }
        });
    }
}
