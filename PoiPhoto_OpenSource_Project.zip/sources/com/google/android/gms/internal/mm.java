package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.os.RemoteException;
import com.google.android.gms.common.api.BaseImplementation;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.fitness.Fitness;
import com.google.android.gms.fitness.SensorsApi;
import com.google.android.gms.fitness.data.k;
import com.google.android.gms.fitness.data.l;
import com.google.android.gms.fitness.request.DataSourcesRequest;
import com.google.android.gms.fitness.request.OnDataPointListener;
import com.google.android.gms.fitness.request.SensorRequest;
import com.google.android.gms.fitness.request.o;
import com.google.android.gms.fitness.request.q;
import com.google.android.gms.fitness.result.DataSourcesResult;
import com.google.android.gms.internal.lu;
import com.google.android.gms.internal.lx;
import com.google.android.gms.internal.md;

public class mm implements SensorsApi {

    private static abstract class a<R extends Result> extends BaseImplementation.a<R, lu> {
        public a(GoogleApiClient googleApiClient) {
            super(Fitness.DQ, googleApiClient);
        }
    }

    private interface b {
        void jO();
    }

    private static class c extends lx.a {
        private final BaseImplementation.b<DataSourcesResult> Ea;

        private c(BaseImplementation.b<DataSourcesResult> bVar) {
            this.Ea = bVar;
        }

        public void a(DataSourcesResult dataSourcesResult) {
            this.Ea.b(dataSourcesResult);
        }
    }

    private static class d extends md.a {
        private final BaseImplementation.b<Status> Ea;
        private final b Vu;

        private d(BaseImplementation.b<Status> bVar, b bVar2) {
            this.Ea = bVar;
            this.Vu = bVar2;
        }

        public void j(Status status) {
            if (this.Vu != null && status.isSuccess()) {
                this.Vu.jO();
            }
            this.Ea.b(status);
        }
    }

    private PendingResult<Status> a(GoogleApiClient googleApiClient, final o oVar) {
        return googleApiClient.a(new a<Status>(googleApiClient) {
            /* access modifiers changed from: protected */
            public void a(lu luVar) throws RemoteException {
                luVar.jM().a(oVar, (md) new lu.b(this), luVar.getContext().getPackageName());
            }

            /* access modifiers changed from: protected */
            /* renamed from: b */
            public Status c(Status status) {
                return status;
            }
        });
    }

    private PendingResult<Status> a(GoogleApiClient googleApiClient, final q qVar, final b bVar) {
        return googleApiClient.b(new a<Status>(googleApiClient) {
            /* access modifiers changed from: protected */
            public void a(lu luVar) throws RemoteException {
                luVar.jM().a(qVar, (md) new d(this, bVar), luVar.getContext().getPackageName());
            }

            /* access modifiers changed from: protected */
            /* renamed from: b */
            public Status c(Status status) {
                return status;
            }
        });
    }

    public PendingResult<Status> add(GoogleApiClient client, SensorRequest request, PendingIntent intent) {
        return a(client, new o(request, (k) null, intent));
    }

    public PendingResult<Status> add(GoogleApiClient client, SensorRequest request, OnDataPointListener listener) {
        return a(client, new o(request, l.a.jG().a(listener), (PendingIntent) null));
    }

    public PendingResult<DataSourcesResult> findDataSources(GoogleApiClient client, final DataSourcesRequest request) {
        return client.a(new a<DataSourcesResult>(client) {
            /* access modifiers changed from: protected */
            public void a(lu luVar) throws RemoteException {
                luVar.jM().a(request, (lx) new c(this), luVar.getContext().getPackageName());
            }

            /* access modifiers changed from: protected */
            /* renamed from: z */
            public DataSourcesResult c(Status status) {
                return DataSourcesResult.D(status);
            }
        });
    }

    public PendingResult<Status> remove(GoogleApiClient client, PendingIntent pendingIntent) {
        return a(client, new q((k) null, pendingIntent), (b) null);
    }

    public PendingResult<Status> remove(GoogleApiClient client, final OnDataPointListener listener) {
        l b2 = l.a.jG().b(listener);
        return b2 == null ? new me(Status.Kw) : a(client, new q(b2, (PendingIntent) null), new b() {
            public void jO() {
                l.a.jG().c(listener);
            }
        });
    }
}
