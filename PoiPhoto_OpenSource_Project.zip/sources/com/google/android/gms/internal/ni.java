package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.location.Location;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.location.GeofencingRequest;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.b;
import com.google.android.gms.location.e;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import java.util.List;

public interface ni extends IInterface {

    public static abstract class a extends Binder implements ni {

        /* renamed from: com.google.android.gms.internal.ni$a$a  reason: collision with other inner class name */
        private static class C0077a implements ni {
            private IBinder le;

            C0077a(IBinder iBinder) {
                this.le = iBinder;
            }

            public void S(boolean z) throws RemoteException {
                int i = 0;
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    if (z) {
                        i = 1;
                    }
                    obtain.writeInt(i);
                    this.le.transact(12, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(long j, boolean z, PendingIntent pendingIntent) throws RemoteException {
                int i = 1;
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    obtain.writeLong(j);
                    if (!z) {
                        i = 0;
                    }
                    obtain.writeInt(i);
                    if (pendingIntent != null) {
                        obtain.writeInt(1);
                        pendingIntent.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(5, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(PendingIntent pendingIntent) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    if (pendingIntent != null) {
                        obtain.writeInt(1);
                        pendingIntent.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(6, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(PendingIntent pendingIntent, nh nhVar, String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    if (pendingIntent != null) {
                        obtain.writeInt(1);
                        pendingIntent.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(nhVar != null ? nhVar.asBinder() : null);
                    obtain.writeString(str);
                    this.le.transact(2, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(Location location, int i) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    if (location != null) {
                        obtain.writeInt(1);
                        location.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeInt(i);
                    this.le.transact(26, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(nh nhVar, String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    obtain.writeStrongBinder(nhVar != null ? nhVar.asBinder() : null);
                    obtain.writeString(str);
                    this.le.transact(4, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(nl nlVar, PendingIntent pendingIntent) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    if (nlVar != null) {
                        obtain.writeInt(1);
                        nlVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (pendingIntent != null) {
                        obtain.writeInt(1);
                        pendingIntent.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(53, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(nl nlVar, b bVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    if (nlVar != null) {
                        obtain.writeInt(1);
                        nlVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(bVar != null ? bVar.asBinder() : null);
                    this.le.transact(52, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(ns nsVar, oh ohVar, PendingIntent pendingIntent) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    if (nsVar != null) {
                        obtain.writeInt(1);
                        nsVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (ohVar != null) {
                        obtain.writeInt(1);
                        ohVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (pendingIntent != null) {
                        obtain.writeInt(1);
                        pendingIntent.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(48, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(nu nuVar, oh ohVar, og ogVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    if (nuVar != null) {
                        obtain.writeInt(1);
                        nuVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (ohVar != null) {
                        obtain.writeInt(1);
                        ohVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(ogVar != null ? ogVar.asBinder() : null);
                    this.le.transact(17, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(nw nwVar, oh ohVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    if (nwVar != null) {
                        obtain.writeInt(1);
                        nwVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (ohVar != null) {
                        obtain.writeInt(1);
                        ohVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(25, obtain, (Parcel) null, 1);
                } finally {
                    obtain.recycle();
                }
            }

            public void a(ny nyVar, oh ohVar, PendingIntent pendingIntent) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    if (nyVar != null) {
                        obtain.writeInt(1);
                        nyVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (ohVar != null) {
                        obtain.writeInt(1);
                        ohVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (pendingIntent != null) {
                        obtain.writeInt(1);
                        pendingIntent.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(18, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(oc ocVar, oh ohVar, og ogVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    if (ocVar != null) {
                        obtain.writeInt(1);
                        ocVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (ohVar != null) {
                        obtain.writeInt(1);
                        ohVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(ogVar != null ? ogVar.asBinder() : null);
                    this.le.transact(46, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(oe oeVar, LatLngBounds latLngBounds, List<String> list, oh ohVar, og ogVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    if (oeVar != null) {
                        obtain.writeInt(1);
                        oeVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (latLngBounds != null) {
                        obtain.writeInt(1);
                        latLngBounds.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStringList(list);
                    if (ohVar != null) {
                        obtain.writeInt(1);
                        ohVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(ogVar != null ? ogVar.asBinder() : null);
                    this.le.transact(50, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(oh ohVar, PendingIntent pendingIntent) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    if (ohVar != null) {
                        obtain.writeInt(1);
                        ohVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (pendingIntent != null) {
                        obtain.writeInt(1);
                        pendingIntent.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(19, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(GeofencingRequest geofencingRequest, PendingIntent pendingIntent, nh nhVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    if (geofencingRequest != null) {
                        obtain.writeInt(1);
                        geofencingRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (pendingIntent != null) {
                        obtain.writeInt(1);
                        pendingIntent.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(nhVar != null ? nhVar.asBinder() : null);
                    this.le.transact(57, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(LocationRequest locationRequest, PendingIntent pendingIntent) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    if (locationRequest != null) {
                        obtain.writeInt(1);
                        locationRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (pendingIntent != null) {
                        obtain.writeInt(1);
                        pendingIntent.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(9, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(LocationRequest locationRequest, b bVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    if (locationRequest != null) {
                        obtain.writeInt(1);
                        locationRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(bVar != null ? bVar.asBinder() : null);
                    this.le.transact(8, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(LocationRequest locationRequest, b bVar, String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    if (locationRequest != null) {
                        obtain.writeInt(1);
                        locationRequest.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(bVar != null ? bVar.asBinder() : null);
                    obtain.writeString(str);
                    this.le.transact(20, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(b bVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    obtain.writeStrongBinder(bVar != null ? bVar.asBinder() : null);
                    this.le.transact(10, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(LatLng latLng, nu nuVar, oh ohVar, og ogVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    if (latLng != null) {
                        obtain.writeInt(1);
                        latLng.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (nuVar != null) {
                        obtain.writeInt(1);
                        nuVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (ohVar != null) {
                        obtain.writeInt(1);
                        ohVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(ogVar != null ? ogVar.asBinder() : null);
                    this.le.transact(16, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(LatLngBounds latLngBounds, int i, nu nuVar, oh ohVar, og ogVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    if (latLngBounds != null) {
                        obtain.writeInt(1);
                        latLngBounds.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeInt(i);
                    if (nuVar != null) {
                        obtain.writeInt(1);
                        nuVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (ohVar != null) {
                        obtain.writeInt(1);
                        ohVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(ogVar != null ? ogVar.asBinder() : null);
                    this.le.transact(14, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(LatLngBounds latLngBounds, int i, String str, nu nuVar, oh ohVar, og ogVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    if (latLngBounds != null) {
                        obtain.writeInt(1);
                        latLngBounds.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeInt(i);
                    obtain.writeString(str);
                    if (nuVar != null) {
                        obtain.writeInt(1);
                        nuVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (ohVar != null) {
                        obtain.writeInt(1);
                        ohVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(ogVar != null ? ogVar.asBinder() : null);
                    this.le.transact(47, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(String str, oh ohVar, og ogVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    obtain.writeString(str);
                    if (ohVar != null) {
                        obtain.writeInt(1);
                        ohVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(ogVar != null ? ogVar.asBinder() : null);
                    this.le.transact(15, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(String str, LatLngBounds latLngBounds, nq nqVar, oh ohVar, og ogVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    obtain.writeString(str);
                    if (latLngBounds != null) {
                        obtain.writeInt(1);
                        latLngBounds.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (nqVar != null) {
                        obtain.writeInt(1);
                        nqVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (ohVar != null) {
                        obtain.writeInt(1);
                        ohVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(ogVar != null ? ogVar.asBinder() : null);
                    this.le.transact(55, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(List<nn> list, PendingIntent pendingIntent, nh nhVar, String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    obtain.writeTypedList(list);
                    if (pendingIntent != null) {
                        obtain.writeInt(1);
                        pendingIntent.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(nhVar != null ? nhVar.asBinder() : null);
                    obtain.writeString(str);
                    this.le.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(List<String> list, oh ohVar, og ogVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    obtain.writeStringList(list);
                    if (ohVar != null) {
                        obtain.writeInt(1);
                        ohVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(ogVar != null ? ogVar.asBinder() : null);
                    this.le.transact(58, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void a(String[] strArr, nh nhVar, String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    obtain.writeStringArray(strArr);
                    obtain.writeStrongBinder(nhVar != null ? nhVar.asBinder() : null);
                    obtain.writeString(str);
                    this.le.transact(3, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public IBinder asBinder() {
                return this.le;
            }

            public void b(PendingIntent pendingIntent) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    if (pendingIntent != null) {
                        obtain.writeInt(1);
                        pendingIntent.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(11, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void b(Location location) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    if (location != null) {
                        obtain.writeInt(1);
                        location.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(13, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void b(oh ohVar, PendingIntent pendingIntent) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    if (ohVar != null) {
                        obtain.writeInt(1);
                        ohVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    if (pendingIntent != null) {
                        obtain.writeInt(1);
                        pendingIntent.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    this.le.transact(49, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void b(String str, oh ohVar, og ogVar) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    obtain.writeString(str);
                    if (ohVar != null) {
                        obtain.writeInt(1);
                        ohVar.writeToParcel(obtain, 0);
                    } else {
                        obtain.writeInt(0);
                    }
                    obtain.writeStrongBinder(ogVar != null ? ogVar.asBinder() : null);
                    this.le.transact(42, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public Location bZ(String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    obtain.writeString(str);
                    this.le.transact(21, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt() != 0 ? (Location) Location.CREATOR.createFromParcel(obtain2) : null;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public e ca(String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    obtain.writeString(str);
                    this.le.transact(34, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt() != 0 ? e.CREATOR.cK(obtain2) : null;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public Location ni() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    this.le.transact(7, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt() != 0 ? (Location) Location.CREATOR.createFromParcel(obtain2) : null;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public IBinder nj() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    this.le.transact(51, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readStrongBinder();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public IBinder nk() throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.location.internal.IGoogleLocationManagerService");
                    this.le.transact(54, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readStrongBinder();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }

        public static ni aO(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.location.internal.IGoogleLocationManagerService");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof ni)) ? new C0077a(iBinder) : (ni) queryLocalInterface;
        }

        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v1, resolved type: com.google.android.gms.internal.oh} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v3, resolved type: com.google.android.gms.internal.oh} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v7, resolved type: com.google.android.gms.internal.oh} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v9, resolved type: com.google.android.gms.internal.oh} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v11, resolved type: com.google.android.gms.internal.oh} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v13, resolved type: com.google.android.gms.internal.oh} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v15, resolved type: com.google.android.gms.internal.oh} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v17, resolved type: com.google.android.gms.internal.oh} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v20, resolved type: com.google.android.gms.internal.nl} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v22, resolved type: com.google.android.gms.location.LocationRequest} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v24, resolved type: com.google.android.gms.location.LocationRequest} */
        /* JADX WARNING: type inference failed for: r5v0 */
        /* JADX WARNING: type inference failed for: r5v26 */
        /* JADX WARNING: type inference failed for: r5v27 */
        /* JADX WARNING: type inference failed for: r5v28 */
        /* JADX WARNING: type inference failed for: r5v29 */
        /* JADX WARNING: type inference failed for: r5v30 */
        /* JADX WARNING: type inference failed for: r5v31 */
        /* JADX WARNING: type inference failed for: r5v32 */
        /* JADX WARNING: type inference failed for: r5v33 */
        /* JADX WARNING: type inference failed for: r5v34 */
        /* JADX WARNING: type inference failed for: r5v35 */
        /* JADX WARNING: type inference failed for: r5v36 */
        /* JADX WARNING: Multi-variable type inference failed */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean onTransact(int r9, android.os.Parcel r10, android.os.Parcel r11, int r12) throws android.os.RemoteException {
            /*
                r8 = this;
                r0 = 0
                r7 = 1
                r5 = 0
                switch(r9) {
                    case 1: goto L_0x0011;
                    case 2: goto L_0x0074;
                    case 3: goto L_0x009d;
                    case 4: goto L_0x00ba;
                    case 5: goto L_0x00d3;
                    case 6: goto L_0x00fd;
                    case 7: goto L_0x011a;
                    case 8: goto L_0x0135;
                    case 9: goto L_0x017b;
                    case 10: goto L_0x01f4;
                    case 11: goto L_0x0209;
                    case 12: goto L_0x0226;
                    case 13: goto L_0x023a;
                    case 14: goto L_0x0257;
                    case 15: goto L_0x02e1;
                    case 16: goto L_0x0306;
                    case 17: goto L_0x0343;
                    case 18: goto L_0x0400;
                    case 19: goto L_0x043b;
                    case 20: goto L_0x0156;
                    case 21: goto L_0x0543;
                    case 25: goto L_0x0562;
                    case 26: goto L_0x0586;
                    case 34: goto L_0x05a7;
                    case 42: goto L_0x0372;
                    case 46: goto L_0x0512;
                    case 47: goto L_0x029b;
                    case 48: goto L_0x0467;
                    case 49: goto L_0x04a2;
                    case 50: goto L_0x03bc;
                    case 51: goto L_0x05c6;
                    case 52: goto L_0x01a7;
                    case 53: goto L_0x01c8;
                    case 54: goto L_0x05d7;
                    case 55: goto L_0x04ce;
                    case 57: goto L_0x003f;
                    case 58: goto L_0x0397;
                    case 1598968902: goto L_0x000b;
                    default: goto L_0x0006;
                }
            L_0x0006:
                boolean r7 = super.onTransact(r9, r10, r11, r12)
            L_0x000a:
                return r7
            L_0x000b:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r11.writeString(r0)
                goto L_0x000a
            L_0x0011:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                com.google.android.gms.internal.no r0 = com.google.android.gms.internal.nn.CREATOR
                java.util.ArrayList r1 = r10.createTypedArrayList(r0)
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x003d
                android.os.Parcelable$Creator r0 = android.app.PendingIntent.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r10)
                android.app.PendingIntent r0 = (android.app.PendingIntent) r0
            L_0x002a:
                android.os.IBinder r2 = r10.readStrongBinder()
                com.google.android.gms.internal.nh r2 = com.google.android.gms.internal.nh.a.aN(r2)
                java.lang.String r3 = r10.readString()
                r8.a((java.util.List<com.google.android.gms.internal.nn>) r1, (android.app.PendingIntent) r0, (com.google.android.gms.internal.nh) r2, (java.lang.String) r3)
                r11.writeNoException()
                goto L_0x000a
            L_0x003d:
                r0 = r5
                goto L_0x002a
            L_0x003f:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x0070
                android.os.Parcelable$Creator<com.google.android.gms.location.GeofencingRequest> r0 = com.google.android.gms.location.GeofencingRequest.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r10)
                com.google.android.gms.location.GeofencingRequest r0 = (com.google.android.gms.location.GeofencingRequest) r0
                r1 = r0
            L_0x0053:
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x0072
                android.os.Parcelable$Creator r0 = android.app.PendingIntent.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r10)
                android.app.PendingIntent r0 = (android.app.PendingIntent) r0
            L_0x0061:
                android.os.IBinder r2 = r10.readStrongBinder()
                com.google.android.gms.internal.nh r2 = com.google.android.gms.internal.nh.a.aN(r2)
                r8.a((com.google.android.gms.location.GeofencingRequest) r1, (android.app.PendingIntent) r0, (com.google.android.gms.internal.nh) r2)
                r11.writeNoException()
                goto L_0x000a
            L_0x0070:
                r1 = r5
                goto L_0x0053
            L_0x0072:
                r0 = r5
                goto L_0x0061
            L_0x0074:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x009b
                android.os.Parcelable$Creator r0 = android.app.PendingIntent.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r10)
                android.app.PendingIntent r0 = (android.app.PendingIntent) r0
            L_0x0087:
                android.os.IBinder r1 = r10.readStrongBinder()
                com.google.android.gms.internal.nh r1 = com.google.android.gms.internal.nh.a.aN(r1)
                java.lang.String r2 = r10.readString()
                r8.a((android.app.PendingIntent) r0, (com.google.android.gms.internal.nh) r1, (java.lang.String) r2)
                r11.writeNoException()
                goto L_0x000a
            L_0x009b:
                r0 = r5
                goto L_0x0087
            L_0x009d:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                java.lang.String[] r0 = r10.createStringArray()
                android.os.IBinder r1 = r10.readStrongBinder()
                com.google.android.gms.internal.nh r1 = com.google.android.gms.internal.nh.a.aN(r1)
                java.lang.String r2 = r10.readString()
                r8.a((java.lang.String[]) r0, (com.google.android.gms.internal.nh) r1, (java.lang.String) r2)
                r11.writeNoException()
                goto L_0x000a
            L_0x00ba:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                android.os.IBinder r0 = r10.readStrongBinder()
                com.google.android.gms.internal.nh r0 = com.google.android.gms.internal.nh.a.aN(r0)
                java.lang.String r1 = r10.readString()
                r8.a((com.google.android.gms.internal.nh) r0, (java.lang.String) r1)
                r11.writeNoException()
                goto L_0x000a
            L_0x00d3:
                java.lang.String r1 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r1)
                long r2 = r10.readLong()
                int r1 = r10.readInt()
                if (r1 == 0) goto L_0x00f9
                r1 = r7
            L_0x00e3:
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x00fb
                android.os.Parcelable$Creator r0 = android.app.PendingIntent.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r10)
                android.app.PendingIntent r0 = (android.app.PendingIntent) r0
            L_0x00f1:
                r8.a((long) r2, (boolean) r1, (android.app.PendingIntent) r0)
                r11.writeNoException()
                goto L_0x000a
            L_0x00f9:
                r1 = r0
                goto L_0x00e3
            L_0x00fb:
                r0 = r5
                goto L_0x00f1
            L_0x00fd:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x0118
                android.os.Parcelable$Creator r0 = android.app.PendingIntent.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r10)
                android.app.PendingIntent r0 = (android.app.PendingIntent) r0
            L_0x0110:
                r8.a((android.app.PendingIntent) r0)
                r11.writeNoException()
                goto L_0x000a
            L_0x0118:
                r0 = r5
                goto L_0x0110
            L_0x011a:
                java.lang.String r1 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r1)
                android.location.Location r1 = r8.ni()
                r11.writeNoException()
                if (r1 == 0) goto L_0x0130
                r11.writeInt(r7)
                r1.writeToParcel(r11, r7)
                goto L_0x000a
            L_0x0130:
                r11.writeInt(r0)
                goto L_0x000a
            L_0x0135:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x0146
                com.google.android.gms.location.d r0 = com.google.android.gms.location.LocationRequest.CREATOR
                com.google.android.gms.location.LocationRequest r5 = r0.createFromParcel(r10)
            L_0x0146:
                android.os.IBinder r0 = r10.readStrongBinder()
                com.google.android.gms.location.b r0 = com.google.android.gms.location.b.a.aL(r0)
                r8.a((com.google.android.gms.location.LocationRequest) r5, (com.google.android.gms.location.b) r0)
                r11.writeNoException()
                goto L_0x000a
            L_0x0156:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x0167
                com.google.android.gms.location.d r0 = com.google.android.gms.location.LocationRequest.CREATOR
                com.google.android.gms.location.LocationRequest r5 = r0.createFromParcel(r10)
            L_0x0167:
                android.os.IBinder r0 = r10.readStrongBinder()
                com.google.android.gms.location.b r0 = com.google.android.gms.location.b.a.aL(r0)
                java.lang.String r1 = r10.readString()
                r8.a((com.google.android.gms.location.LocationRequest) r5, (com.google.android.gms.location.b) r0, (java.lang.String) r1)
                r11.writeNoException()
                goto L_0x000a
            L_0x017b:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x01a3
                com.google.android.gms.location.d r0 = com.google.android.gms.location.LocationRequest.CREATOR
                com.google.android.gms.location.LocationRequest r0 = r0.createFromParcel(r10)
                r1 = r0
            L_0x018d:
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x01a5
                android.os.Parcelable$Creator r0 = android.app.PendingIntent.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r10)
                android.app.PendingIntent r0 = (android.app.PendingIntent) r0
            L_0x019b:
                r8.a((com.google.android.gms.location.LocationRequest) r1, (android.app.PendingIntent) r0)
                r11.writeNoException()
                goto L_0x000a
            L_0x01a3:
                r1 = r5
                goto L_0x018d
            L_0x01a5:
                r0 = r5
                goto L_0x019b
            L_0x01a7:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x01b8
                com.google.android.gms.internal.nm r0 = com.google.android.gms.internal.nl.CREATOR
                com.google.android.gms.internal.nl r5 = r0.createFromParcel(r10)
            L_0x01b8:
                android.os.IBinder r0 = r10.readStrongBinder()
                com.google.android.gms.location.b r0 = com.google.android.gms.location.b.a.aL(r0)
                r8.a((com.google.android.gms.internal.nl) r5, (com.google.android.gms.location.b) r0)
                r11.writeNoException()
                goto L_0x000a
            L_0x01c8:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x01f0
                com.google.android.gms.internal.nm r0 = com.google.android.gms.internal.nl.CREATOR
                com.google.android.gms.internal.nl r0 = r0.createFromParcel(r10)
                r1 = r0
            L_0x01da:
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x01f2
                android.os.Parcelable$Creator r0 = android.app.PendingIntent.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r10)
                android.app.PendingIntent r0 = (android.app.PendingIntent) r0
            L_0x01e8:
                r8.a((com.google.android.gms.internal.nl) r1, (android.app.PendingIntent) r0)
                r11.writeNoException()
                goto L_0x000a
            L_0x01f0:
                r1 = r5
                goto L_0x01da
            L_0x01f2:
                r0 = r5
                goto L_0x01e8
            L_0x01f4:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                android.os.IBinder r0 = r10.readStrongBinder()
                com.google.android.gms.location.b r0 = com.google.android.gms.location.b.a.aL(r0)
                r8.a((com.google.android.gms.location.b) r0)
                r11.writeNoException()
                goto L_0x000a
            L_0x0209:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x0224
                android.os.Parcelable$Creator r0 = android.app.PendingIntent.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r10)
                android.app.PendingIntent r0 = (android.app.PendingIntent) r0
            L_0x021c:
                r8.b((android.app.PendingIntent) r0)
                r11.writeNoException()
                goto L_0x000a
            L_0x0224:
                r0 = r5
                goto L_0x021c
            L_0x0226:
                java.lang.String r1 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r1)
                int r1 = r10.readInt()
                if (r1 == 0) goto L_0x0232
                r0 = r7
            L_0x0232:
                r8.S(r0)
                r11.writeNoException()
                goto L_0x000a
            L_0x023a:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x0255
                android.os.Parcelable$Creator r0 = android.location.Location.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r10)
                android.location.Location r0 = (android.location.Location) r0
            L_0x024d:
                r8.b((android.location.Location) r0)
                r11.writeNoException()
                goto L_0x000a
            L_0x0255:
                r0 = r5
                goto L_0x024d
            L_0x0257:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x0295
                com.google.android.gms.maps.model.g r0 = com.google.android.gms.maps.model.LatLngBounds.CREATOR
                com.google.android.gms.maps.model.LatLngBounds r1 = r0.createFromParcel(r10)
            L_0x0268:
                int r2 = r10.readInt()
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x0297
                com.google.android.gms.internal.nv r0 = com.google.android.gms.internal.nu.CREATOR
                com.google.android.gms.internal.nu r3 = r0.createFromParcel(r10)
            L_0x0278:
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x0299
                com.google.android.gms.internal.oi r0 = com.google.android.gms.internal.oh.CREATOR
                com.google.android.gms.internal.oh r4 = r0.createFromParcel(r10)
            L_0x0284:
                android.os.IBinder r0 = r10.readStrongBinder()
                com.google.android.gms.internal.og r5 = com.google.android.gms.internal.og.a.aP(r0)
                r0 = r8
                r0.a((com.google.android.gms.maps.model.LatLngBounds) r1, (int) r2, (com.google.android.gms.internal.nu) r3, (com.google.android.gms.internal.oh) r4, (com.google.android.gms.internal.og) r5)
                r11.writeNoException()
                goto L_0x000a
            L_0x0295:
                r1 = r5
                goto L_0x0268
            L_0x0297:
                r3 = r5
                goto L_0x0278
            L_0x0299:
                r4 = r5
                goto L_0x0284
            L_0x029b:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x02dd
                com.google.android.gms.maps.model.g r0 = com.google.android.gms.maps.model.LatLngBounds.CREATOR
                com.google.android.gms.maps.model.LatLngBounds r1 = r0.createFromParcel(r10)
            L_0x02ac:
                int r2 = r10.readInt()
                java.lang.String r3 = r10.readString()
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x02df
                com.google.android.gms.internal.nv r0 = com.google.android.gms.internal.nu.CREATOR
                com.google.android.gms.internal.nu r4 = r0.createFromParcel(r10)
            L_0x02c0:
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x02cc
                com.google.android.gms.internal.oi r0 = com.google.android.gms.internal.oh.CREATOR
                com.google.android.gms.internal.oh r5 = r0.createFromParcel(r10)
            L_0x02cc:
                android.os.IBinder r0 = r10.readStrongBinder()
                com.google.android.gms.internal.og r6 = com.google.android.gms.internal.og.a.aP(r0)
                r0 = r8
                r0.a(r1, r2, r3, r4, r5, r6)
                r11.writeNoException()
                goto L_0x000a
            L_0x02dd:
                r1 = r5
                goto L_0x02ac
            L_0x02df:
                r4 = r5
                goto L_0x02c0
            L_0x02e1:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                java.lang.String r0 = r10.readString()
                int r1 = r10.readInt()
                if (r1 == 0) goto L_0x02f6
                com.google.android.gms.internal.oi r1 = com.google.android.gms.internal.oh.CREATOR
                com.google.android.gms.internal.oh r5 = r1.createFromParcel(r10)
            L_0x02f6:
                android.os.IBinder r1 = r10.readStrongBinder()
                com.google.android.gms.internal.og r1 = com.google.android.gms.internal.og.a.aP(r1)
                r8.a((java.lang.String) r0, (com.google.android.gms.internal.oh) r5, (com.google.android.gms.internal.og) r1)
                r11.writeNoException()
                goto L_0x000a
            L_0x0306:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x033f
                com.google.android.gms.maps.model.i r0 = com.google.android.gms.maps.model.LatLng.CREATOR
                com.google.android.gms.maps.model.LatLng r0 = r0.createFromParcel(r10)
            L_0x0317:
                int r1 = r10.readInt()
                if (r1 == 0) goto L_0x0341
                com.google.android.gms.internal.nv r1 = com.google.android.gms.internal.nu.CREATOR
                com.google.android.gms.internal.nu r1 = r1.createFromParcel(r10)
            L_0x0323:
                int r2 = r10.readInt()
                if (r2 == 0) goto L_0x032f
                com.google.android.gms.internal.oi r2 = com.google.android.gms.internal.oh.CREATOR
                com.google.android.gms.internal.oh r5 = r2.createFromParcel(r10)
            L_0x032f:
                android.os.IBinder r2 = r10.readStrongBinder()
                com.google.android.gms.internal.og r2 = com.google.android.gms.internal.og.a.aP(r2)
                r8.a((com.google.android.gms.maps.model.LatLng) r0, (com.google.android.gms.internal.nu) r1, (com.google.android.gms.internal.oh) r5, (com.google.android.gms.internal.og) r2)
                r11.writeNoException()
                goto L_0x000a
            L_0x033f:
                r0 = r5
                goto L_0x0317
            L_0x0341:
                r1 = r5
                goto L_0x0323
            L_0x0343:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x0370
                com.google.android.gms.internal.nv r0 = com.google.android.gms.internal.nu.CREATOR
                com.google.android.gms.internal.nu r0 = r0.createFromParcel(r10)
            L_0x0354:
                int r1 = r10.readInt()
                if (r1 == 0) goto L_0x0360
                com.google.android.gms.internal.oi r1 = com.google.android.gms.internal.oh.CREATOR
                com.google.android.gms.internal.oh r5 = r1.createFromParcel(r10)
            L_0x0360:
                android.os.IBinder r1 = r10.readStrongBinder()
                com.google.android.gms.internal.og r1 = com.google.android.gms.internal.og.a.aP(r1)
                r8.a((com.google.android.gms.internal.nu) r0, (com.google.android.gms.internal.oh) r5, (com.google.android.gms.internal.og) r1)
                r11.writeNoException()
                goto L_0x000a
            L_0x0370:
                r0 = r5
                goto L_0x0354
            L_0x0372:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                java.lang.String r0 = r10.readString()
                int r1 = r10.readInt()
                if (r1 == 0) goto L_0x0387
                com.google.android.gms.internal.oi r1 = com.google.android.gms.internal.oh.CREATOR
                com.google.android.gms.internal.oh r5 = r1.createFromParcel(r10)
            L_0x0387:
                android.os.IBinder r1 = r10.readStrongBinder()
                com.google.android.gms.internal.og r1 = com.google.android.gms.internal.og.a.aP(r1)
                r8.b(r0, r5, r1)
                r11.writeNoException()
                goto L_0x000a
            L_0x0397:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                java.util.ArrayList r0 = r10.createStringArrayList()
                int r1 = r10.readInt()
                if (r1 == 0) goto L_0x03ac
                com.google.android.gms.internal.oi r1 = com.google.android.gms.internal.oh.CREATOR
                com.google.android.gms.internal.oh r5 = r1.createFromParcel(r10)
            L_0x03ac:
                android.os.IBinder r1 = r10.readStrongBinder()
                com.google.android.gms.internal.og r1 = com.google.android.gms.internal.og.a.aP(r1)
                r8.a((java.util.List<java.lang.String>) r0, (com.google.android.gms.internal.oh) r5, (com.google.android.gms.internal.og) r1)
                r11.writeNoException()
                goto L_0x000a
            L_0x03bc:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x03fa
                com.google.android.gms.internal.of r0 = com.google.android.gms.internal.oe.CREATOR
                com.google.android.gms.internal.oe r1 = r0.createFromParcel(r10)
            L_0x03cd:
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x03fc
                com.google.android.gms.maps.model.g r0 = com.google.android.gms.maps.model.LatLngBounds.CREATOR
                com.google.android.gms.maps.model.LatLngBounds r2 = r0.createFromParcel(r10)
            L_0x03d9:
                java.util.ArrayList r3 = r10.createStringArrayList()
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x03fe
                com.google.android.gms.internal.oi r0 = com.google.android.gms.internal.oh.CREATOR
                com.google.android.gms.internal.oh r4 = r0.createFromParcel(r10)
            L_0x03e9:
                android.os.IBinder r0 = r10.readStrongBinder()
                com.google.android.gms.internal.og r5 = com.google.android.gms.internal.og.a.aP(r0)
                r0 = r8
                r0.a((com.google.android.gms.internal.oe) r1, (com.google.android.gms.maps.model.LatLngBounds) r2, (java.util.List<java.lang.String>) r3, (com.google.android.gms.internal.oh) r4, (com.google.android.gms.internal.og) r5)
                r11.writeNoException()
                goto L_0x000a
            L_0x03fa:
                r1 = r5
                goto L_0x03cd
            L_0x03fc:
                r2 = r5
                goto L_0x03d9
            L_0x03fe:
                r4 = r5
                goto L_0x03e9
            L_0x0400:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x0435
                com.google.android.gms.internal.nz r0 = com.google.android.gms.internal.ny.CREATOR
                com.google.android.gms.internal.ny r0 = r0.createFromParcel(r10)
                r1 = r0
            L_0x0412:
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x0437
                com.google.android.gms.internal.oi r0 = com.google.android.gms.internal.oh.CREATOR
                com.google.android.gms.internal.oh r0 = r0.createFromParcel(r10)
                r2 = r0
            L_0x041f:
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x0439
                android.os.Parcelable$Creator r0 = android.app.PendingIntent.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r10)
                android.app.PendingIntent r0 = (android.app.PendingIntent) r0
            L_0x042d:
                r8.a((com.google.android.gms.internal.ny) r1, (com.google.android.gms.internal.oh) r2, (android.app.PendingIntent) r0)
                r11.writeNoException()
                goto L_0x000a
            L_0x0435:
                r1 = r5
                goto L_0x0412
            L_0x0437:
                r2 = r5
                goto L_0x041f
            L_0x0439:
                r0 = r5
                goto L_0x042d
            L_0x043b:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x0463
                com.google.android.gms.internal.oi r0 = com.google.android.gms.internal.oh.CREATOR
                com.google.android.gms.internal.oh r0 = r0.createFromParcel(r10)
                r1 = r0
            L_0x044d:
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x0465
                android.os.Parcelable$Creator r0 = android.app.PendingIntent.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r10)
                android.app.PendingIntent r0 = (android.app.PendingIntent) r0
            L_0x045b:
                r8.a((com.google.android.gms.internal.oh) r1, (android.app.PendingIntent) r0)
                r11.writeNoException()
                goto L_0x000a
            L_0x0463:
                r1 = r5
                goto L_0x044d
            L_0x0465:
                r0 = r5
                goto L_0x045b
            L_0x0467:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x049c
                com.google.android.gms.internal.nt r0 = com.google.android.gms.internal.ns.CREATOR
                com.google.android.gms.internal.ns r0 = r0.createFromParcel(r10)
                r1 = r0
            L_0x0479:
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x049e
                com.google.android.gms.internal.oi r0 = com.google.android.gms.internal.oh.CREATOR
                com.google.android.gms.internal.oh r0 = r0.createFromParcel(r10)
                r2 = r0
            L_0x0486:
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x04a0
                android.os.Parcelable$Creator r0 = android.app.PendingIntent.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r10)
                android.app.PendingIntent r0 = (android.app.PendingIntent) r0
            L_0x0494:
                r8.a((com.google.android.gms.internal.ns) r1, (com.google.android.gms.internal.oh) r2, (android.app.PendingIntent) r0)
                r11.writeNoException()
                goto L_0x000a
            L_0x049c:
                r1 = r5
                goto L_0x0479
            L_0x049e:
                r2 = r5
                goto L_0x0486
            L_0x04a0:
                r0 = r5
                goto L_0x0494
            L_0x04a2:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x04ca
                com.google.android.gms.internal.oi r0 = com.google.android.gms.internal.oh.CREATOR
                com.google.android.gms.internal.oh r0 = r0.createFromParcel(r10)
                r1 = r0
            L_0x04b4:
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x04cc
                android.os.Parcelable$Creator r0 = android.app.PendingIntent.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r10)
                android.app.PendingIntent r0 = (android.app.PendingIntent) r0
            L_0x04c2:
                r8.b(r1, r0)
                r11.writeNoException()
                goto L_0x000a
            L_0x04ca:
                r1 = r5
                goto L_0x04b4
            L_0x04cc:
                r0 = r5
                goto L_0x04c2
            L_0x04ce:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                java.lang.String r1 = r10.readString()
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x050c
                com.google.android.gms.maps.model.g r0 = com.google.android.gms.maps.model.LatLngBounds.CREATOR
                com.google.android.gms.maps.model.LatLngBounds r2 = r0.createFromParcel(r10)
            L_0x04e3:
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x050e
                com.google.android.gms.internal.nr r0 = com.google.android.gms.internal.nq.CREATOR
                com.google.android.gms.internal.nq r3 = r0.createFromParcel(r10)
            L_0x04ef:
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x0510
                com.google.android.gms.internal.oi r0 = com.google.android.gms.internal.oh.CREATOR
                com.google.android.gms.internal.oh r4 = r0.createFromParcel(r10)
            L_0x04fb:
                android.os.IBinder r0 = r10.readStrongBinder()
                com.google.android.gms.internal.og r5 = com.google.android.gms.internal.og.a.aP(r0)
                r0 = r8
                r0.a((java.lang.String) r1, (com.google.android.gms.maps.model.LatLngBounds) r2, (com.google.android.gms.internal.nq) r3, (com.google.android.gms.internal.oh) r4, (com.google.android.gms.internal.og) r5)
                r11.writeNoException()
                goto L_0x000a
            L_0x050c:
                r2 = r5
                goto L_0x04e3
            L_0x050e:
                r3 = r5
                goto L_0x04ef
            L_0x0510:
                r4 = r5
                goto L_0x04fb
            L_0x0512:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x0541
                android.os.Parcelable$Creator<com.google.android.gms.internal.oc> r0 = com.google.android.gms.internal.oc.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r10)
                com.google.android.gms.internal.oc r0 = (com.google.android.gms.internal.oc) r0
            L_0x0525:
                int r1 = r10.readInt()
                if (r1 == 0) goto L_0x0531
                com.google.android.gms.internal.oi r1 = com.google.android.gms.internal.oh.CREATOR
                com.google.android.gms.internal.oh r5 = r1.createFromParcel(r10)
            L_0x0531:
                android.os.IBinder r1 = r10.readStrongBinder()
                com.google.android.gms.internal.og r1 = com.google.android.gms.internal.og.a.aP(r1)
                r8.a((com.google.android.gms.internal.oc) r0, (com.google.android.gms.internal.oh) r5, (com.google.android.gms.internal.og) r1)
                r11.writeNoException()
                goto L_0x000a
            L_0x0541:
                r0 = r5
                goto L_0x0525
            L_0x0543:
                java.lang.String r1 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r1)
                java.lang.String r1 = r10.readString()
                android.location.Location r1 = r8.bZ(r1)
                r11.writeNoException()
                if (r1 == 0) goto L_0x055d
                r11.writeInt(r7)
                r1.writeToParcel(r11, r7)
                goto L_0x000a
            L_0x055d:
                r11.writeInt(r0)
                goto L_0x000a
            L_0x0562:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x0584
                com.google.android.gms.internal.nx r0 = com.google.android.gms.internal.nw.CREATOR
                com.google.android.gms.internal.nw r0 = r0.createFromParcel(r10)
            L_0x0573:
                int r1 = r10.readInt()
                if (r1 == 0) goto L_0x057f
                com.google.android.gms.internal.oi r1 = com.google.android.gms.internal.oh.CREATOR
                com.google.android.gms.internal.oh r5 = r1.createFromParcel(r10)
            L_0x057f:
                r8.a((com.google.android.gms.internal.nw) r0, (com.google.android.gms.internal.oh) r5)
                goto L_0x000a
            L_0x0584:
                r0 = r5
                goto L_0x0573
            L_0x0586:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                int r0 = r10.readInt()
                if (r0 == 0) goto L_0x05a5
                android.os.Parcelable$Creator r0 = android.location.Location.CREATOR
                java.lang.Object r0 = r0.createFromParcel(r10)
                android.location.Location r0 = (android.location.Location) r0
            L_0x0599:
                int r1 = r10.readInt()
                r8.a((android.location.Location) r0, (int) r1)
                r11.writeNoException()
                goto L_0x000a
            L_0x05a5:
                r0 = r5
                goto L_0x0599
            L_0x05a7:
                java.lang.String r1 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r1)
                java.lang.String r1 = r10.readString()
                com.google.android.gms.location.e r1 = r8.ca(r1)
                r11.writeNoException()
                if (r1 == 0) goto L_0x05c1
                r11.writeInt(r7)
                r1.writeToParcel(r11, r7)
                goto L_0x000a
            L_0x05c1:
                r11.writeInt(r0)
                goto L_0x000a
            L_0x05c6:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                android.os.IBinder r0 = r8.nj()
                r11.writeNoException()
                r11.writeStrongBinder(r0)
                goto L_0x000a
            L_0x05d7:
                java.lang.String r0 = "com.google.android.gms.location.internal.IGoogleLocationManagerService"
                r10.enforceInterface(r0)
                android.os.IBinder r0 = r8.nk()
                r11.writeNoException()
                r11.writeStrongBinder(r0)
                goto L_0x000a
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ni.a.onTransact(int, android.os.Parcel, android.os.Parcel, int):boolean");
        }
    }

    void S(boolean z) throws RemoteException;

    void a(long j, boolean z, PendingIntent pendingIntent) throws RemoteException;

    void a(PendingIntent pendingIntent) throws RemoteException;

    void a(PendingIntent pendingIntent, nh nhVar, String str) throws RemoteException;

    void a(Location location, int i) throws RemoteException;

    void a(nh nhVar, String str) throws RemoteException;

    void a(nl nlVar, PendingIntent pendingIntent) throws RemoteException;

    void a(nl nlVar, b bVar) throws RemoteException;

    void a(ns nsVar, oh ohVar, PendingIntent pendingIntent) throws RemoteException;

    void a(nu nuVar, oh ohVar, og ogVar) throws RemoteException;

    void a(nw nwVar, oh ohVar) throws RemoteException;

    void a(ny nyVar, oh ohVar, PendingIntent pendingIntent) throws RemoteException;

    void a(oc ocVar, oh ohVar, og ogVar) throws RemoteException;

    void a(oe oeVar, LatLngBounds latLngBounds, List<String> list, oh ohVar, og ogVar) throws RemoteException;

    void a(oh ohVar, PendingIntent pendingIntent) throws RemoteException;

    void a(GeofencingRequest geofencingRequest, PendingIntent pendingIntent, nh nhVar) throws RemoteException;

    void a(LocationRequest locationRequest, PendingIntent pendingIntent) throws RemoteException;

    void a(LocationRequest locationRequest, b bVar) throws RemoteException;

    void a(LocationRequest locationRequest, b bVar, String str) throws RemoteException;

    void a(b bVar) throws RemoteException;

    void a(LatLng latLng, nu nuVar, oh ohVar, og ogVar) throws RemoteException;

    void a(LatLngBounds latLngBounds, int i, nu nuVar, oh ohVar, og ogVar) throws RemoteException;

    void a(LatLngBounds latLngBounds, int i, String str, nu nuVar, oh ohVar, og ogVar) throws RemoteException;

    void a(String str, oh ohVar, og ogVar) throws RemoteException;

    void a(String str, LatLngBounds latLngBounds, nq nqVar, oh ohVar, og ogVar) throws RemoteException;

    void a(List<nn> list, PendingIntent pendingIntent, nh nhVar, String str) throws RemoteException;

    void a(List<String> list, oh ohVar, og ogVar) throws RemoteException;

    void a(String[] strArr, nh nhVar, String str) throws RemoteException;

    void b(PendingIntent pendingIntent) throws RemoteException;

    void b(Location location) throws RemoteException;

    void b(oh ohVar, PendingIntent pendingIntent) throws RemoteException;

    void b(String str, oh ohVar, og ogVar) throws RemoteException;

    Location bZ(String str) throws RemoteException;

    e ca(String str) throws RemoteException;

    Location ni() throws RemoteException;

    IBinder nj() throws RemoteException;

    IBinder nk() throws RemoteException;
}
