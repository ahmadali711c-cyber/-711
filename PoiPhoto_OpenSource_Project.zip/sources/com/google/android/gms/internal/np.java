package com.google.android.gms.internal;

import android.os.DeadObjectException;
import android.os.IInterface;

public interface np<T extends IInterface> {
    void dS();

    T hw() throws DeadObjectException;
}
