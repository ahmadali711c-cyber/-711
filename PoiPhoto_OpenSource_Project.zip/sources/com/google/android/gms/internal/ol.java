package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.RemoteException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.BaseImplementation;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.oj;
import com.google.android.gms.panorama.Panorama;
import com.google.android.gms.panorama.PanoramaApi;

public class ol implements PanoramaApi {

    private static abstract class a extends c<PanoramaApi.PanoramaResult> {
        public a(GoogleApiClient googleApiClient) {
            super(googleApiClient);
        }

        /* access modifiers changed from: protected */
        /* renamed from: ay */
        public PanoramaApi.PanoramaResult c(Status status) {
            return new on(status, (Intent) null);
        }
    }

    private static final class b extends oj.a {
        private final BaseImplementation.b<PanoramaApi.PanoramaResult> Ea;

        public b(BaseImplementation.b<PanoramaApi.PanoramaResult> bVar) {
            this.Ea = bVar;
        }

        public void a(int i, Bundle bundle, int i2, Intent intent) {
            this.Ea.b(new on(new Status(i, (String) null, bundle != null ? (PendingIntent) bundle.getParcelable("pendingIntent") : null), intent));
        }
    }

    private static abstract class c<R extends Result> extends BaseImplementation.a<R, om> {
        protected c(GoogleApiClient googleApiClient) {
            super(Panorama.DQ, googleApiClient);
        }

        /* access modifiers changed from: protected */
        public abstract void a(Context context, ok okVar) throws RemoteException;

        /* access modifiers changed from: protected */
        public final void a(om omVar) throws RemoteException {
            a(omVar.getContext(), (ok) omVar.hw());
        }
    }

    /* access modifiers changed from: private */
    public static void a(Context context, Uri uri) {
        context.revokeUriPermission(uri, 1);
    }

    /* access modifiers changed from: private */
    public static void a(final Context context, ok okVar, final oj ojVar, final Uri uri, Bundle bundle) throws RemoteException {
        context.grantUriPermission(GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE, uri, 1);
        try {
            okVar.a(new oj.a() {
                public void a(int i, Bundle bundle, int i2, Intent intent) throws RemoteException {
                    ol.a(context, uri);
                    ojVar.a(i, bundle, i2, intent);
                }
            }, uri, bundle, true);
        } catch (RemoteException e) {
            a(context, uri);
            throw e;
        } catch (RuntimeException e2) {
            a(context, uri);
            throw e2;
        }
    }

    public PendingResult<PanoramaApi.PanoramaResult> loadPanoramaInfo(GoogleApiClient client, final Uri uri) {
        return client.a(new a(client) {
            /* access modifiers changed from: protected */
            public void a(Context context, ok okVar) throws RemoteException {
                okVar.a(new b(this), uri, (Bundle) null, false);
            }
        });
    }

    public PendingResult<PanoramaApi.PanoramaResult> loadPanoramaInfoAndGrantAccess(GoogleApiClient client, final Uri uri) {
        return client.a(new a(client) {
            /* access modifiers changed from: protected */
            public void a(Context context, ok okVar) throws RemoteException {
                ol.a(context, okVar, new b(this), uri, (Bundle) null);
            }
        });
    }
}
