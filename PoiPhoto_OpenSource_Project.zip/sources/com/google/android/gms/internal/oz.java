package com.google.android.gms.internal;

import com.google.android.gms.plus.a;

public final class oz implements a {
}
