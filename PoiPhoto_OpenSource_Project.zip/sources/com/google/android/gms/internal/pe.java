package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.util.TimeUtils;
import com.google.ads.AdSize;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.games.Notifications;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class pe implements Parcelable.Creator<pd> {
    static void a(pd pdVar, Parcel parcel, int i) {
        int H = b.H(parcel);
        Set<Integer> set = pdVar.aon;
        if (set.contains(1)) {
            b.c(parcel, 1, pdVar.CK);
        }
        if (set.contains(2)) {
            b.a(parcel, 2, (Parcelable) pdVar.aoo, i, true);
        }
        if (set.contains(3)) {
            b.b(parcel, 3, pdVar.aop, true);
        }
        if (set.contains(4)) {
            b.a(parcel, 4, (Parcelable) pdVar.aoq, i, true);
        }
        if (set.contains(5)) {
            b.a(parcel, 5, pdVar.aor, true);
        }
        if (set.contains(6)) {
            b.a(parcel, 6, pdVar.aos, true);
        }
        if (set.contains(7)) {
            b.a(parcel, 7, pdVar.aot, true);
        }
        if (set.contains(8)) {
            b.c(parcel, 8, pdVar.aou, true);
        }
        if (set.contains(9)) {
            b.c(parcel, 9, pdVar.aov);
        }
        if (set.contains(10)) {
            b.c(parcel, 10, pdVar.aow, true);
        }
        if (set.contains(11)) {
            b.a(parcel, 11, (Parcelable) pdVar.aox, i, true);
        }
        if (set.contains(12)) {
            b.c(parcel, 12, pdVar.aoy, true);
        }
        if (set.contains(13)) {
            b.a(parcel, 13, pdVar.aoz, true);
        }
        if (set.contains(14)) {
            b.a(parcel, 14, pdVar.aoA, true);
        }
        if (set.contains(15)) {
            b.a(parcel, 15, (Parcelable) pdVar.aoB, i, true);
        }
        if (set.contains(17)) {
            b.a(parcel, 17, pdVar.aoD, true);
        }
        if (set.contains(16)) {
            b.a(parcel, 16, pdVar.aoC, true);
        }
        if (set.contains(19)) {
            b.c(parcel, 19, pdVar.aoE, true);
        }
        if (set.contains(18)) {
            b.a(parcel, 18, pdVar.ov, true);
        }
        if (set.contains(21)) {
            b.a(parcel, 21, pdVar.aoG, true);
        }
        if (set.contains(20)) {
            b.a(parcel, 20, pdVar.aoF, true);
        }
        if (set.contains(23)) {
            b.a(parcel, 23, pdVar.UO, true);
        }
        if (set.contains(22)) {
            b.a(parcel, 22, pdVar.aoH, true);
        }
        if (set.contains(25)) {
            b.a(parcel, 25, pdVar.aoJ, true);
        }
        if (set.contains(24)) {
            b.a(parcel, 24, pdVar.aoI, true);
        }
        if (set.contains(27)) {
            b.a(parcel, 27, pdVar.aoL, true);
        }
        if (set.contains(26)) {
            b.a(parcel, 26, pdVar.aoK, true);
        }
        if (set.contains(29)) {
            b.a(parcel, 29, (Parcelable) pdVar.aoN, i, true);
        }
        if (set.contains(28)) {
            b.a(parcel, 28, pdVar.aoM, true);
        }
        if (set.contains(31)) {
            b.a(parcel, 31, pdVar.aoP, true);
        }
        if (set.contains(30)) {
            b.a(parcel, 30, pdVar.aoO, true);
        }
        if (set.contains(34)) {
            b.a(parcel, 34, (Parcelable) pdVar.aoR, i, true);
        }
        if (set.contains(32)) {
            b.a(parcel, 32, pdVar.CE, true);
        }
        if (set.contains(33)) {
            b.a(parcel, 33, pdVar.aoQ, true);
        }
        if (set.contains(38)) {
            b.a(parcel, 38, pdVar.agh);
        }
        if (set.contains(39)) {
            b.a(parcel, 39, pdVar.mName, true);
        }
        if (set.contains(36)) {
            b.a(parcel, 36, pdVar.agg);
        }
        if (set.contains(37)) {
            b.a(parcel, 37, (Parcelable) pdVar.aoS, i, true);
        }
        if (set.contains(42)) {
            b.a(parcel, 42, pdVar.aoV, true);
        }
        if (set.contains(43)) {
            b.a(parcel, 43, pdVar.aoW, true);
        }
        if (set.contains(40)) {
            b.a(parcel, 40, (Parcelable) pdVar.aoT, i, true);
        }
        if (set.contains(41)) {
            b.c(parcel, 41, pdVar.aoU, true);
        }
        if (set.contains(46)) {
            b.a(parcel, 46, (Parcelable) pdVar.aoZ, i, true);
        }
        if (set.contains(47)) {
            b.a(parcel, 47, pdVar.apa, true);
        }
        if (set.contains(44)) {
            b.a(parcel, 44, pdVar.aoX, true);
        }
        if (set.contains(45)) {
            b.a(parcel, 45, pdVar.aoY, true);
        }
        if (set.contains(51)) {
            b.a(parcel, 51, pdVar.ape, true);
        }
        if (set.contains(50)) {
            b.a(parcel, 50, (Parcelable) pdVar.apd, i, true);
        }
        if (set.contains(49)) {
            b.a(parcel, 49, pdVar.apc, true);
        }
        if (set.contains(48)) {
            b.a(parcel, 48, pdVar.apb, true);
        }
        if (set.contains(55)) {
            b.a(parcel, 55, pdVar.apg, true);
        }
        if (set.contains(54)) {
            b.a(parcel, 54, pdVar.vf, true);
        }
        if (set.contains(53)) {
            b.a(parcel, 53, pdVar.vc, true);
        }
        if (set.contains(52)) {
            b.a(parcel, 52, pdVar.apf, true);
        }
        if (set.contains(56)) {
            b.a(parcel, 56, pdVar.aph, true);
        }
        b.H(parcel, H);
    }

    /* renamed from: dx */
    public pd createFromParcel(Parcel parcel) {
        int G = a.G(parcel);
        HashSet hashSet = new HashSet();
        int i = 0;
        pd pdVar = null;
        ArrayList<String> arrayList = null;
        pd pdVar2 = null;
        String str = null;
        String str2 = null;
        String str3 = null;
        ArrayList arrayList2 = null;
        int i2 = 0;
        ArrayList arrayList3 = null;
        pd pdVar3 = null;
        ArrayList arrayList4 = null;
        String str4 = null;
        String str5 = null;
        pd pdVar4 = null;
        String str6 = null;
        String str7 = null;
        String str8 = null;
        ArrayList arrayList5 = null;
        String str9 = null;
        String str10 = null;
        String str11 = null;
        String str12 = null;
        String str13 = null;
        String str14 = null;
        String str15 = null;
        String str16 = null;
        String str17 = null;
        pd pdVar5 = null;
        String str18 = null;
        String str19 = null;
        String str20 = null;
        String str21 = null;
        pd pdVar6 = null;
        double d = 0.0d;
        pd pdVar7 = null;
        double d2 = 0.0d;
        String str22 = null;
        pd pdVar8 = null;
        ArrayList arrayList6 = null;
        String str23 = null;
        String str24 = null;
        String str25 = null;
        String str26 = null;
        pd pdVar9 = null;
        String str27 = null;
        String str28 = null;
        String str29 = null;
        pd pdVar10 = null;
        String str30 = null;
        String str31 = null;
        String str32 = null;
        String str33 = null;
        String str34 = null;
        String str35 = null;
        while (parcel.dataPosition() < G) {
            int F = a.F(parcel);
            switch (a.aH(F)) {
                case 1:
                    i = a.g(parcel, F);
                    hashSet.add(1);
                    break;
                case 2:
                    hashSet.add(2);
                    pdVar = (pd) a.a(parcel, F, pd.CREATOR);
                    break;
                case 3:
                    arrayList = a.C(parcel, F);
                    hashSet.add(3);
                    break;
                case 4:
                    hashSet.add(4);
                    pdVar2 = (pd) a.a(parcel, F, pd.CREATOR);
                    break;
                case 5:
                    str = a.o(parcel, F);
                    hashSet.add(5);
                    break;
                case 6:
                    str2 = a.o(parcel, F);
                    hashSet.add(6);
                    break;
                case 7:
                    str3 = a.o(parcel, F);
                    hashSet.add(7);
                    break;
                case 8:
                    arrayList2 = a.c(parcel, F, pd.CREATOR);
                    hashSet.add(8);
                    break;
                case 9:
                    i2 = a.g(parcel, F);
                    hashSet.add(9);
                    break;
                case 10:
                    arrayList3 = a.c(parcel, F, pd.CREATOR);
                    hashSet.add(10);
                    break;
                case 11:
                    hashSet.add(11);
                    pdVar3 = (pd) a.a(parcel, F, pd.CREATOR);
                    break;
                case 12:
                    arrayList4 = a.c(parcel, F, pd.CREATOR);
                    hashSet.add(12);
                    break;
                case 13:
                    str4 = a.o(parcel, F);
                    hashSet.add(13);
                    break;
                case 14:
                    str5 = a.o(parcel, F);
                    hashSet.add(14);
                    break;
                case 15:
                    hashSet.add(15);
                    pdVar4 = (pd) a.a(parcel, F, pd.CREATOR);
                    break;
                case 16:
                    str6 = a.o(parcel, F);
                    hashSet.add(16);
                    break;
                case 17:
                    str7 = a.o(parcel, F);
                    hashSet.add(17);
                    break;
                case 18:
                    str8 = a.o(parcel, F);
                    hashSet.add(18);
                    break;
                case TimeUtils.HUNDRED_DAY_FIELD_LEN:
                    arrayList5 = a.c(parcel, F, pd.CREATOR);
                    hashSet.add(19);
                    break;
                case 20:
                    str9 = a.o(parcel, F);
                    hashSet.add(20);
                    break;
                case 21:
                    str10 = a.o(parcel, F);
                    hashSet.add(21);
                    break;
                case 22:
                    str11 = a.o(parcel, F);
                    hashSet.add(22);
                    break;
                case 23:
                    str12 = a.o(parcel, F);
                    hashSet.add(23);
                    break;
                case 24:
                    str13 = a.o(parcel, F);
                    hashSet.add(24);
                    break;
                case 25:
                    str14 = a.o(parcel, F);
                    hashSet.add(25);
                    break;
                case 26:
                    str15 = a.o(parcel, F);
                    hashSet.add(26);
                    break;
                case 27:
                    str16 = a.o(parcel, F);
                    hashSet.add(27);
                    break;
                case 28:
                    str17 = a.o(parcel, F);
                    hashSet.add(28);
                    break;
                case 29:
                    hashSet.add(29);
                    pdVar5 = (pd) a.a(parcel, F, pd.CREATOR);
                    break;
                case 30:
                    str18 = a.o(parcel, F);
                    hashSet.add(30);
                    break;
                case Notifications.NOTIFICATION_TYPES_ALL:
                    str19 = a.o(parcel, F);
                    hashSet.add(31);
                    break;
                case 32:
                    str20 = a.o(parcel, F);
                    hashSet.add(32);
                    break;
                case 33:
                    str21 = a.o(parcel, F);
                    hashSet.add(33);
                    break;
                case 34:
                    hashSet.add(34);
                    pdVar6 = (pd) a.a(parcel, F, pd.CREATOR);
                    break;
                case 36:
                    d = a.m(parcel, F);
                    hashSet.add(36);
                    break;
                case 37:
                    hashSet.add(37);
                    pdVar7 = (pd) a.a(parcel, F, pd.CREATOR);
                    break;
                case 38:
                    d2 = a.m(parcel, F);
                    hashSet.add(38);
                    break;
                case 39:
                    str22 = a.o(parcel, F);
                    hashSet.add(39);
                    break;
                case 40:
                    hashSet.add(40);
                    pdVar8 = (pd) a.a(parcel, F, pd.CREATOR);
                    break;
                case 41:
                    arrayList6 = a.c(parcel, F, pd.CREATOR);
                    hashSet.add(41);
                    break;
                case 42:
                    str23 = a.o(parcel, F);
                    hashSet.add(42);
                    break;
                case 43:
                    str24 = a.o(parcel, F);
                    hashSet.add(43);
                    break;
                case 44:
                    str25 = a.o(parcel, F);
                    hashSet.add(44);
                    break;
                case 45:
                    str26 = a.o(parcel, F);
                    hashSet.add(45);
                    break;
                case 46:
                    hashSet.add(46);
                    pdVar9 = (pd) a.a(parcel, F, pd.CREATOR);
                    break;
                case 47:
                    str27 = a.o(parcel, F);
                    hashSet.add(47);
                    break;
                case 48:
                    str28 = a.o(parcel, F);
                    hashSet.add(48);
                    break;
                case 49:
                    str29 = a.o(parcel, F);
                    hashSet.add(49);
                    break;
                case AdSize.PORTRAIT_AD_HEIGHT:
                    hashSet.add(50);
                    pdVar10 = (pd) a.a(parcel, F, pd.CREATOR);
                    break;
                case 51:
                    str30 = a.o(parcel, F);
                    hashSet.add(51);
                    break;
                case 52:
                    str31 = a.o(parcel, F);
                    hashSet.add(52);
                    break;
                case 53:
                    str32 = a.o(parcel, F);
                    hashSet.add(53);
                    break;
                case 54:
                    str33 = a.o(parcel, F);
                    hashSet.add(54);
                    break;
                case 55:
                    str34 = a.o(parcel, F);
                    hashSet.add(55);
                    break;
                case 56:
                    str35 = a.o(parcel, F);
                    hashSet.add(56);
                    break;
                default:
                    a.b(parcel, F);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new pd(hashSet, i, pdVar, arrayList, pdVar2, str, str2, str3, arrayList2, i2, arrayList3, pdVar3, arrayList4, str4, str5, pdVar4, str6, str7, str8, arrayList5, str9, str10, str11, str12, str13, str14, str15, str16, str17, pdVar5, str18, str19, str20, str21, pdVar6, d, pdVar7, d2, str22, pdVar8, arrayList6, str23, str24, str25, str26, pdVar9, str27, str28, str29, pdVar10, str30, str31, str32, str33, str34, str35);
        }
        throw new a.C0004a("Overread allowed size end=" + G, parcel);
    }

    /* renamed from: fv */
    public pd[] newArray(int i) {
        return new pd[i];
    }
}
