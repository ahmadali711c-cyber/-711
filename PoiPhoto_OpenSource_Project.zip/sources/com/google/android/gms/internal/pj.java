package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.util.TimeUtils;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.internal.pi;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class pj implements Parcelable.Creator<pi> {
    static void a(pi piVar, Parcel parcel, int i) {
        int H = b.H(parcel);
        Set<Integer> set = piVar.aon;
        if (set.contains(1)) {
            b.c(parcel, 1, piVar.CK);
        }
        if (set.contains(2)) {
            b.a(parcel, 2, piVar.apl, true);
        }
        if (set.contains(3)) {
            b.a(parcel, 3, (Parcelable) piVar.apm, i, true);
        }
        if (set.contains(4)) {
            b.a(parcel, 4, piVar.apn, true);
        }
        if (set.contains(5)) {
            b.a(parcel, 5, piVar.apo, true);
        }
        if (set.contains(6)) {
            b.c(parcel, 6, piVar.app);
        }
        if (set.contains(7)) {
            b.a(parcel, 7, (Parcelable) piVar.apq, i, true);
        }
        if (set.contains(8)) {
            b.a(parcel, 8, piVar.apr, true);
        }
        if (set.contains(9)) {
            b.a(parcel, 9, piVar.OS, true);
        }
        if (set.contains(12)) {
            b.c(parcel, 12, piVar.ow);
        }
        if (set.contains(14)) {
            b.a(parcel, 14, piVar.CE, true);
        }
        if (set.contains(15)) {
            b.a(parcel, 15, (Parcelable) piVar.aps, i, true);
        }
        if (set.contains(16)) {
            b.a(parcel, 16, piVar.apt);
        }
        if (set.contains(19)) {
            b.a(parcel, 19, (Parcelable) piVar.apu, i, true);
        }
        if (set.contains(18)) {
            b.a(parcel, 18, piVar.FR, true);
        }
        if (set.contains(21)) {
            b.c(parcel, 21, piVar.apw);
        }
        if (set.contains(20)) {
            b.a(parcel, 20, piVar.apv, true);
        }
        if (set.contains(23)) {
            b.c(parcel, 23, piVar.apy, true);
        }
        if (set.contains(22)) {
            b.c(parcel, 22, piVar.apx, true);
        }
        if (set.contains(25)) {
            b.c(parcel, 25, piVar.apA);
        }
        if (set.contains(24)) {
            b.c(parcel, 24, piVar.apz);
        }
        if (set.contains(27)) {
            b.a(parcel, 27, piVar.vf, true);
        }
        if (set.contains(26)) {
            b.a(parcel, 26, piVar.apB, true);
        }
        if (set.contains(29)) {
            b.a(parcel, 29, piVar.apD);
        }
        if (set.contains(28)) {
            b.c(parcel, 28, piVar.apC, true);
        }
        b.H(parcel, H);
    }

    /* renamed from: dz */
    public pi createFromParcel(Parcel parcel) {
        int G = a.G(parcel);
        HashSet hashSet = new HashSet();
        int i = 0;
        String str = null;
        pi.a aVar = null;
        String str2 = null;
        String str3 = null;
        int i2 = 0;
        pi.b bVar = null;
        String str4 = null;
        String str5 = null;
        int i3 = 0;
        String str6 = null;
        pi.c cVar = null;
        boolean z = false;
        String str7 = null;
        pi.d dVar = null;
        String str8 = null;
        int i4 = 0;
        ArrayList arrayList = null;
        ArrayList arrayList2 = null;
        int i5 = 0;
        int i6 = 0;
        String str9 = null;
        String str10 = null;
        ArrayList arrayList3 = null;
        boolean z2 = false;
        while (parcel.dataPosition() < G) {
            int F = a.F(parcel);
            switch (a.aH(F)) {
                case 1:
                    i = a.g(parcel, F);
                    hashSet.add(1);
                    break;
                case 2:
                    str = a.o(parcel, F);
                    hashSet.add(2);
                    break;
                case 3:
                    hashSet.add(3);
                    aVar = (pi.a) a.a(parcel, F, pi.a.CREATOR);
                    break;
                case 4:
                    str2 = a.o(parcel, F);
                    hashSet.add(4);
                    break;
                case 5:
                    str3 = a.o(parcel, F);
                    hashSet.add(5);
                    break;
                case 6:
                    i2 = a.g(parcel, F);
                    hashSet.add(6);
                    break;
                case 7:
                    hashSet.add(7);
                    bVar = (pi.b) a.a(parcel, F, pi.b.CREATOR);
                    break;
                case 8:
                    str4 = a.o(parcel, F);
                    hashSet.add(8);
                    break;
                case 9:
                    str5 = a.o(parcel, F);
                    hashSet.add(9);
                    break;
                case 12:
                    i3 = a.g(parcel, F);
                    hashSet.add(12);
                    break;
                case 14:
                    str6 = a.o(parcel, F);
                    hashSet.add(14);
                    break;
                case 15:
                    hashSet.add(15);
                    cVar = (pi.c) a.a(parcel, F, pi.c.CREATOR);
                    break;
                case 16:
                    z = a.c(parcel, F);
                    hashSet.add(16);
                    break;
                case 18:
                    str7 = a.o(parcel, F);
                    hashSet.add(18);
                    break;
                case TimeUtils.HUNDRED_DAY_FIELD_LEN:
                    hashSet.add(19);
                    dVar = (pi.d) a.a(parcel, F, pi.d.CREATOR);
                    break;
                case 20:
                    str8 = a.o(parcel, F);
                    hashSet.add(20);
                    break;
                case 21:
                    i4 = a.g(parcel, F);
                    hashSet.add(21);
                    break;
                case 22:
                    arrayList = a.c(parcel, F, pi.f.CREATOR);
                    hashSet.add(22);
                    break;
                case 23:
                    arrayList2 = a.c(parcel, F, pi.g.CREATOR);
                    hashSet.add(23);
                    break;
                case 24:
                    i5 = a.g(parcel, F);
                    hashSet.add(24);
                    break;
                case 25:
                    i6 = a.g(parcel, F);
                    hashSet.add(25);
                    break;
                case 26:
                    str9 = a.o(parcel, F);
                    hashSet.add(26);
                    break;
                case 27:
                    str10 = a.o(parcel, F);
                    hashSet.add(27);
                    break;
                case 28:
                    arrayList3 = a.c(parcel, F, pi.h.CREATOR);
                    hashSet.add(28);
                    break;
                case 29:
                    z2 = a.c(parcel, F);
                    hashSet.add(29);
                    break;
                default:
                    a.b(parcel, F);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new pi(hashSet, i, str, aVar, str2, str3, i2, bVar, str4, str5, i3, str6, cVar, z, str7, dVar, str8, i4, arrayList, arrayList2, i5, i6, str9, str10, arrayList3, z2);
        }
        throw new a.C0004a("Overread allowed size end=" + G, parcel);
    }

    /* renamed from: fx */
    public pi[] newArray(int i) {
        return new pi[i];
    }
}
