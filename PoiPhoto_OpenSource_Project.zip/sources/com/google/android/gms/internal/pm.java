package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.internal.pi;
import java.util.HashSet;
import java.util.Set;

public class pm implements Parcelable.Creator<pi.b.a> {
    static void a(pi.b.a aVar, Parcel parcel, int i) {
        int H = b.H(parcel);
        Set<Integer> set = aVar.aon;
        if (set.contains(1)) {
            b.c(parcel, 1, aVar.CK);
        }
        if (set.contains(2)) {
            b.c(parcel, 2, aVar.apJ);
        }
        if (set.contains(3)) {
            b.c(parcel, 3, aVar.apK);
        }
        b.H(parcel, H);
    }

    /* renamed from: dC */
    public pi.b.a createFromParcel(Parcel parcel) {
        int i = 0;
        int G = a.G(parcel);
        HashSet hashSet = new HashSet();
        int i2 = 0;
        int i3 = 0;
        while (parcel.dataPosition() < G) {
            int F = a.F(parcel);
            switch (a.aH(F)) {
                case 1:
                    i3 = a.g(parcel, F);
                    hashSet.add(1);
                    break;
                case 2:
                    i2 = a.g(parcel, F);
                    hashSet.add(2);
                    break;
                case 3:
                    i = a.g(parcel, F);
                    hashSet.add(3);
                    break;
                default:
                    a.b(parcel, F);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new pi.b.a(hashSet, i3, i2, i);
        }
        throw new a.C0004a("Overread allowed size end=" + G, parcel);
    }

    /* renamed from: fA */
    public pi.b.a[] newArray(int i) {
        return new pi.b.a[i];
    }
}
