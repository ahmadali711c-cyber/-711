package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.internal.pi;
import java.util.HashSet;
import java.util.Set;

public class pn implements Parcelable.Creator<pi.b.C0082b> {
    static void a(pi.b.C0082b bVar, Parcel parcel, int i) {
        int H = b.H(parcel);
        Set<Integer> set = bVar.aon;
        if (set.contains(1)) {
            b.c(parcel, 1, bVar.CK);
        }
        if (set.contains(2)) {
            b.c(parcel, 2, bVar.lj);
        }
        if (set.contains(3)) {
            b.a(parcel, 3, bVar.vf, true);
        }
        if (set.contains(4)) {
            b.c(parcel, 4, bVar.li);
        }
        b.H(parcel, H);
    }

    /* renamed from: dD */
    public pi.b.C0082b createFromParcel(Parcel parcel) {
        int i = 0;
        int G = a.G(parcel);
        HashSet hashSet = new HashSet();
        String str = null;
        int i2 = 0;
        int i3 = 0;
        while (parcel.dataPosition() < G) {
            int F = a.F(parcel);
            switch (a.aH(F)) {
                case 1:
                    i3 = a.g(parcel, F);
                    hashSet.add(1);
                    break;
                case 2:
                    i2 = a.g(parcel, F);
                    hashSet.add(2);
                    break;
                case 3:
                    str = a.o(parcel, F);
                    hashSet.add(3);
                    break;
                case 4:
                    i = a.g(parcel, F);
                    hashSet.add(4);
                    break;
                default:
                    a.b(parcel, F);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new pi.b.C0082b(hashSet, i3, i2, str, i);
        }
        throw new a.C0004a("Overread allowed size end=" + G, parcel);
    }

    /* renamed from: fB */
    public pi.b.C0082b[] newArray(int i) {
        return new pi.b.C0082b[i];
    }
}
