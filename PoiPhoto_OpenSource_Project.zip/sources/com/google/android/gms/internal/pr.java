package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.internal.pi;
import java.util.HashSet;
import java.util.Set;

public class pr implements Parcelable.Creator<pi.g> {
    static void a(pi.g gVar, Parcel parcel, int i) {
        int H = b.H(parcel);
        Set<Integer> set = gVar.aon;
        if (set.contains(1)) {
            b.c(parcel, 1, gVar.CK);
        }
        if (set.contains(2)) {
            b.a(parcel, 2, gVar.apR);
        }
        if (set.contains(3)) {
            b.a(parcel, 3, gVar.mValue, true);
        }
        b.H(parcel, H);
    }

    /* renamed from: dH */
    public pi.g createFromParcel(Parcel parcel) {
        boolean z = false;
        int G = a.G(parcel);
        HashSet hashSet = new HashSet();
        String str = null;
        int i = 0;
        while (parcel.dataPosition() < G) {
            int F = a.F(parcel);
            switch (a.aH(F)) {
                case 1:
                    i = a.g(parcel, F);
                    hashSet.add(1);
                    break;
                case 2:
                    z = a.c(parcel, F);
                    hashSet.add(2);
                    break;
                case 3:
                    str = a.o(parcel, F);
                    hashSet.add(3);
                    break;
                default:
                    a.b(parcel, F);
                    break;
            }
        }
        if (parcel.dataPosition() == G) {
            return new pi.g(hashSet, i, z, str);
        }
        throw new a.C0004a("Overread allowed size end=" + G, parcel);
    }

    /* renamed from: fF */
    public pi.g[] newArray(int i) {
        return new pi.g[i];
    }
}
