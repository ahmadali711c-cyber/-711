package com.google.android.gms.internal;

import android.content.Context;
import android.view.MotionEvent;
import com.google.android.gms.internal.u;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicReference;

@ey
class x implements g, Runnable {
    private u.b lB;
    private final List<Object[]> mp = new Vector();
    private final AtomicReference<g> mq = new AtomicReference<>();
    CountDownLatch mr = new CountDownLatch(1);

    public x(u.b bVar) {
        this.lB = bVar;
        if (gq.dB()) {
            gh.a(this);
        } else {
            run();
        }
    }

    private void aB() {
        if (!this.mp.isEmpty()) {
            for (Object[] next : this.mp) {
                if (next.length == 1) {
                    this.mq.get().a((MotionEvent) next[0]);
                } else if (next.length == 3) {
                    this.mq.get().a(((Integer) next[0]).intValue(), ((Integer) next[1]).intValue(), ((Integer) next[2]).intValue());
                }
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0007, code lost:
        r0 = r2.getApplicationContext();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private android.content.Context i(android.content.Context r2) {
        /*
            r1 = this;
            boolean r0 = r1.aC()
            if (r0 != 0) goto L_0x0007
        L_0x0006:
            return r2
        L_0x0007:
            android.content.Context r0 = r2.getApplicationContext()
            if (r0 == 0) goto L_0x0006
            r2 = r0
            goto L_0x0006
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.x.i(android.content.Context):android.content.Context");
    }

    public String a(Context context) {
        g gVar;
        if (!aA() || (gVar = this.mq.get()) == null) {
            return "";
        }
        aB();
        return gVar.a(i(context));
    }

    public String a(Context context, String str) {
        g gVar;
        if (!aA() || (gVar = this.mq.get()) == null) {
            return "";
        }
        aB();
        return gVar.a(i(context), str);
    }

    public void a(int i, int i2, int i3) {
        g gVar = this.mq.get();
        if (gVar != null) {
            aB();
            gVar.a(i, i2, i3);
            return;
        }
        this.mp.add(new Object[]{Integer.valueOf(i), Integer.valueOf(i2), Integer.valueOf(i3)});
    }

    public void a(MotionEvent motionEvent) {
        g gVar = this.mq.get();
        if (gVar != null) {
            aB();
            gVar.a(motionEvent);
            return;
        }
        this.mp.add(new Object[]{motionEvent});
    }

    /* access modifiers changed from: protected */
    public void a(g gVar) {
        this.mq.set(gVar);
    }

    /* access modifiers changed from: protected */
    public boolean aA() {
        try {
            this.mr.await();
            return true;
        } catch (InterruptedException e) {
            gr.d("Interrupted during GADSignals creation.", e);
            return false;
        }
    }

    /* access modifiers changed from: protected */
    public boolean aC() {
        return ga.bN().getBoolean("gads:spam_app_context:enabled", false);
    }

    public void run() {
        try {
            a((g) j.a(this.lB.lO.wS, i(this.lB.lM)));
        } finally {
            this.mr.countDown();
            this.lB = null;
        }
    }
}
