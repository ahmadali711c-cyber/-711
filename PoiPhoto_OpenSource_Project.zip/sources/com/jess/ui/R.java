package com.jess.ui;

public final class R {

    public static final class attr {
        public static final int cacheColorHint = 2130771975;
        public static final int columnWidth = 2130771982;
        public static final int drawSelectorOnTop = 2130771971;
        public static final int gravity = 2130771968;
        public static final int gridViewStyle = 2130771969;
        public static final int horizontalSpacing = 2130771979;
        public static final int listSelector = 2130771970;
        public static final int numColumns = 2130771984;
        public static final int numRows = 2130771985;
        public static final int rowHeight = 2130771983;
        public static final int scrollDirectionLandscape = 2130771978;
        public static final int scrollDirectionPortrait = 2130771977;
        public static final int scrollingCache = 2130771973;
        public static final int smoothScrollbar = 2130771976;
        public static final int stackFromBottom = 2130771972;
        public static final int stretchMode = 2130771981;
        public static final int transcriptMode = 2130771974;
        public static final int verticalSpacing = 2130771980;
    }

    public static final class drawable {
        public static final int icon = 2130837577;
        public static final int spinner_black_76 = 2130837616;
    }

    public static final class id {
        public static final int alwaysScroll = 2131034126;
        public static final int auto_fit = 2131034133;
        public static final int bottom = 2131034113;
        public static final int center = 2131034120;
        public static final int center_horizontal = 2131034118;
        public static final int center_vertical = 2131034116;
        public static final int clip_horizontal = 2131034123;
        public static final int clip_vertical = 2131034122;
        public static final int columnWidth = 2131034131;
        public static final int disabled = 2131034124;
        public static final int fill = 2131034121;
        public static final int fill_horizontal = 2131034119;
        public static final int fill_vertical = 2131034117;
        public static final int gridview = 2131034239;
        public static final int horizontal = 2131034128;
        public static final int left = 2131034114;
        public static final int none = 2131034129;
        public static final int normal = 2131034125;
        public static final int right = 2131034115;
        public static final int spacingWidth = 2131034130;
        public static final int spacingWidthUniform = 2131034132;
        public static final int top = 2131034112;
        public static final int vertical = 2131034127;
    }

    public static final class layout {
        public static final int main = 2130903051;
    }

    public static final class string {
        public static final int app_name = 2131099648;
    }

    public static final class styleable {
        public static final int[] TwoWayAbsListView = {com.jkfantasy.photopoinokia.R.attr.listSelector, com.jkfantasy.photopoinokia.R.attr.drawSelectorOnTop, com.jkfantasy.photopoinokia.R.attr.stackFromBottom, com.jkfantasy.photopoinokia.R.attr.scrollingCache, com.jkfantasy.photopoinokia.R.attr.transcriptMode, com.jkfantasy.photopoinokia.R.attr.cacheColorHint, com.jkfantasy.photopoinokia.R.attr.smoothScrollbar, com.jkfantasy.photopoinokia.R.attr.scrollDirectionPortrait, com.jkfantasy.photopoinokia.R.attr.scrollDirectionLandscape};
        public static final int TwoWayAbsListView_cacheColorHint = 5;
        public static final int TwoWayAbsListView_drawSelectorOnTop = 1;
        public static final int TwoWayAbsListView_listSelector = 0;
        public static final int TwoWayAbsListView_scrollDirectionLandscape = 8;
        public static final int TwoWayAbsListView_scrollDirectionPortrait = 7;
        public static final int TwoWayAbsListView_scrollingCache = 3;
        public static final int TwoWayAbsListView_smoothScrollbar = 6;
        public static final int TwoWayAbsListView_stackFromBottom = 2;
        public static final int TwoWayAbsListView_transcriptMode = 4;
        public static final int[] TwoWayGridView = {com.jkfantasy.photopoinokia.R.attr.gravity, com.jkfantasy.photopoinokia.R.attr.horizontalSpacing, com.jkfantasy.photopoinokia.R.attr.verticalSpacing, com.jkfantasy.photopoinokia.R.attr.stretchMode, com.jkfantasy.photopoinokia.R.attr.columnWidth, com.jkfantasy.photopoinokia.R.attr.rowHeight, com.jkfantasy.photopoinokia.R.attr.numColumns, com.jkfantasy.photopoinokia.R.attr.numRows};
        public static final int TwoWayGridView_columnWidth = 4;
        public static final int TwoWayGridView_gravity = 0;
        public static final int TwoWayGridView_horizontalSpacing = 1;
        public static final int TwoWayGridView_numColumns = 6;
        public static final int TwoWayGridView_numRows = 7;
        public static final int TwoWayGridView_rowHeight = 5;
        public static final int TwoWayGridView_stretchMode = 3;
        public static final int TwoWayGridView_verticalSpacing = 2;
    }
}
