package com.jkfantasy.photopoinokia;

/* compiled from: MainActivity */
class AD_STATE {
    static final int FAIL = 3;
    static final int INIT = 1;
    static final int NOT_INIT = 0;
    static final int SUCCESS = 2;

    AD_STATE() {
    }
}
