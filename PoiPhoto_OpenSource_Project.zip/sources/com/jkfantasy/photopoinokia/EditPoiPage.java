package com.jkfantasy.photopoinokia;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.media.ExifInterface;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.MotionEventCompat;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;
import com.jess.ui.TwoWayAdapterView;
import com.jess.ui.TwoWayGridView;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.Thread;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class EditPoiPage extends FragmentActivity implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {
    public static final int COLUMN_LAND = 1;
    public static final int COLUMN_PORT = 0;
    static final int MESSAGE_WHAT_EditText_onBackKeyPress = 512;
    static final int MESSAGE_WHAT_setMapViewsInfoFromPhoto_0 = 768;
    public static int column_selected;
    public static int[] displayHeight;
    public static int[] displayWidth;
    public static TwoWayGridView horzGridView;
    public static int m_curFilePosition = 0;
    public static TwoWayGridView vertGridView;
    private final int NUMBER_SOURCE_ITEMS = 500;
    private final int OPAQUE = MotionEventCompat.ACTION_MASK;
    String bestProvider;
    BgThread bgThread = null;
    Button btn_content1_normal_full_screen;
    Button btn_title_back;
    Button btn_update_poi;
    FrameLayout content1_container;
    int content1_height;
    int content1_marginTop;
    Spinner content1_sp_map_type;
    int content1_width;
    Handler customHandler = null;
    TextView et_info_Altitude;
    EditTextWithBackKey et_info_Latitude;
    EditTextWithBackKey et_info_Longitude;
    FrameLayout fl_cross_center;
    final int gBuildVerSDK = Build.VERSION.SDK_INT;
    Location gCurLocation = null;
    Geocoder gGeocoder = null;
    GPS_MAP_ADDRESS gGpsMapAddress = new GPS_MAP_ADDRESS();
    boolean gIsThreadStarted = false;
    Boolean gIs_content1_full_screen = false;
    List<MyLatLng> gMapcenterList = new ArrayList();
    ProgressDialog gProgressDlg;
    boolean g_is_et_message_inFocus = false;
    Boolean hasMeasuredLayout = false;
    HorzGridViewAdapter horzGridViewAdapter;
    LinearLayout layout_content1;
    FrameLayout layout_root;
    int layout_root_height;
    int layout_root_width;
    LinearLayout ll_title_bar;
    LocationManager locMgr;
    Context mContext;
    protected GoogleApiClient mGoogleApiClient;
    protected Location mLastLocation = null;
    boolean m_editLatLngSaved = false;
    float m_editLatitude = 0.0f;
    float m_editLongitude = 0.0f;
    int m_mapTypeSelect = 0;
    float m_mapZoomLevel = 15.0f;
    EditMapGoogleAndroidV2 mapGoogleAndroidV2 = new EditMapGoogleAndroidV2();
    protected boolean mbLocationServiceInitialized = false;
    SharedPreferences settings;
    String tmp_info_Latitude;
    String tmp_info_Longitude;
    TextView tv_editLatLngAfter;
    TextView tv_info_Altitude;
    TextView tv_info_Help;
    TextView tv_info_Latitude;
    TextView tv_info_Longitude;

    public class GPS_MAP_ADDRESS {
        Address address;
        MyLatLng latLng;
        int whichCalcAddressMethod;

        public GPS_MAP_ADDRESS() {
        }
    }

    /* access modifiers changed from: package-private */
    public void createCustomHandler() {
        this.customHandler = new Handler() {
            public void handleMessage(Message msg) {
                if (msg.what == 512) {
                    EditPoiPage.this.et_onBackPressed();
                }
                if (msg.what == EditPoiPage.MESSAGE_WHAT_setMapViewsInfoFromPhoto_0) {
                    EditPoiPage.this.setMapViewsInfoFromPhoto(0, true);
                }
                super.handleMessage(msg);
            }
        };
    }

    /* access modifiers changed from: package-private */
    public void destroyCustomHandler() {
        if (this.customHandler != null) {
            this.customHandler.removeCallbacksAndMessages((Object) null);
            this.customHandler = null;
        }
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.mapGoogleAndroidV2.setMainActivity(this);
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setContentView(R.layout.edit_poi_page);
        this.mContext = getApplicationContext();
        horzGridView = (TwoWayGridView) findViewById(R.id.horz_gridview);
        this.horzGridViewAdapter = new HorzGridViewAdapter(this.mContext, ((MyApplication) getApplication()).editPoiList);
        horzGridView.setAdapter((ListAdapter) this.horzGridViewAdapter);
        m_curFilePosition = 0;
        horzGridView.setSelection(m_curFilePosition);
        horzGridView.setOnItemClickListener(new TwoWayAdapterView.OnItemClickListener() {
            public void onItemClick(TwoWayAdapterView<?> twoWayAdapterView, View view, int position, long id) {
                EditPoiPage.m_curFilePosition = position;
                EditPoiPage.horzGridView.setSelection(EditPoiPage.m_curFilePosition);
                EditPoiPage.this.horzGridViewAdapter.notifyDataSetChanged();
                EditPoiPage.this.setMapViewsInfoFromPhoto(position, false);
            }
        });
        createCustomHandler();
        findViews();
        initLocMgr();
        this.bgThread = new BgThread(this);
        buildGoogleApiClient();
        new AsyncTask<Void, Void, Void>() {
            /* access modifiers changed from: protected */
            public void onPreExecute() {
                EditPoiPage.this.gProgressDlg = ProgressDialog.show(EditPoiPage.this, EditPoiPage.this.getString(R.string.ProgressDlg_Title_Loading), EditPoiPage.this.getString(R.string.ProgressDlg_Message_Loading));
                super.onPreExecute();
            }

            /* access modifiers changed from: protected */
            public Void doInBackground(Void... params) {
                while (!EditPoiPage.this.mbLocationServiceInitialized) {
                    try {
                        Thread.sleep(500);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                try {
                    Thread.sleep(1000);
                    return null;
                } catch (Exception e2) {
                    e2.printStackTrace();
                    return null;
                }
            }

            /* access modifiers changed from: protected */
            public void onPostExecute(Void result) {
                EditPoiPage.this.gProgressDlg.dismiss();
                super.onPostExecute(result);
            }
        }.execute(new Void[0]);
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
        this.mGoogleApiClient.connect();
    }

    /* access modifiers changed from: protected */
    public void onRestart() {
        super.onRestart();
        this.mGoogleApiClient.connect();
    }

    /* access modifiers changed from: protected */
    public void onResumeFragments() {
        super.onResumeFragments();
        initializeSettings();
        startBgThread();
        this.tv_editLatLngAfter.setFocusableInTouchMode(true);
        this.tv_editLatLngAfter.requestFocus();
        this.et_info_Latitude.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == 3 || actionId == 6) {
                    EditPoiPage.this.et_onBackPressed();
                    ((InputMethodManager) EditPoiPage.this.getSystemService("input_method")).hideSoftInputFromWindow(EditPoiPage.this.et_info_Latitude.getWindowToken(), 0);
                    return true;
                } else if (event == null || event.getAction() != 0 || event.getKeyCode() != 66) {
                    return false;
                } else {
                    EditPoiPage.this.et_onBackPressed();
                    ((InputMethodManager) EditPoiPage.this.getSystemService("input_method")).hideSoftInputFromWindow(EditPoiPage.this.et_info_Latitude.getWindowToken(), 0);
                    return true;
                }
            }
        });
        this.et_info_Latitude.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    FrameLayout.LayoutParams params2 = (FrameLayout.LayoutParams) EditPoiPage.this.content1_container.getLayoutParams();
                    params2.width = EditPoiPage.this.content1_width;
                    params2.height = EditPoiPage.this.content1_height;
                    params2.topMargin = EditPoiPage.this.content1_marginTop;
                    params2.leftMargin = EditPoiPage.this.layout_root_width;
                    EditPoiPage.this.content1_container.setLayoutParams(params2);
                    EditPoiPage.this.tmp_info_Latitude = EditPoiPage.this.et_info_Latitude.getText().toString();
                    EditPoiPage.this.tmp_info_Longitude = EditPoiPage.this.et_info_Longitude.getText().toString();
                    EditPoiPage.this.g_is_et_message_inFocus = true;
                }
            }
        });
        this.et_info_Latitude.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) {
                String afterStr;
                if (s != null && (afterStr = s.toString()) != null && afterStr.length() > 0) {
                    try {
                        float fAfterValue = Float.valueOf(afterStr).floatValue();
                        if (fAfterValue > 90.0f) {
                            EditPoiPage.this.et_info_Latitude.setText("90");
                        }
                        if (fAfterValue < -90.0f) {
                            EditPoiPage.this.et_info_Latitude.setText("-90");
                        }
                    } catch (NumberFormatException e) {
                    }
                }
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
        });
        this.et_info_Longitude.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == 3 || actionId == 6) {
                    EditPoiPage.this.et_onBackPressed();
                    ((InputMethodManager) EditPoiPage.this.getSystemService("input_method")).hideSoftInputFromWindow(EditPoiPage.this.et_info_Longitude.getWindowToken(), 0);
                    return true;
                } else if (event == null || event.getAction() != 0 || event.getKeyCode() != 66) {
                    return false;
                } else {
                    EditPoiPage.this.et_onBackPressed();
                    ((InputMethodManager) EditPoiPage.this.getSystemService("input_method")).hideSoftInputFromWindow(EditPoiPage.this.et_info_Longitude.getWindowToken(), 0);
                    return true;
                }
            }
        });
        this.et_info_Longitude.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    FrameLayout.LayoutParams params2 = (FrameLayout.LayoutParams) EditPoiPage.this.content1_container.getLayoutParams();
                    params2.width = EditPoiPage.this.content1_width;
                    params2.height = EditPoiPage.this.content1_height;
                    params2.topMargin = EditPoiPage.this.content1_marginTop;
                    params2.leftMargin = EditPoiPage.this.layout_root_width;
                    EditPoiPage.this.content1_container.setLayoutParams(params2);
                    EditPoiPage.this.tmp_info_Latitude = EditPoiPage.this.et_info_Latitude.getText().toString();
                    EditPoiPage.this.tmp_info_Longitude = EditPoiPage.this.et_info_Longitude.getText().toString();
                    EditPoiPage.this.g_is_et_message_inFocus = true;
                }
            }
        });
        this.et_info_Longitude.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) {
                String afterStr;
                if (s != null && (afterStr = s.toString()) != null && afterStr.length() > 0) {
                    try {
                        float fAfterValue = Float.valueOf(afterStr).floatValue();
                        if (fAfterValue > 180.0f) {
                            EditPoiPage.this.et_info_Longitude.setText("180");
                        }
                        if (fAfterValue < -180.0f) {
                            EditPoiPage.this.et_info_Longitude.setText("-180");
                        }
                    } catch (NumberFormatException e) {
                    }
                }
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
        });
        this.layout_content1.setVisibility(4);
        this.content1_container.setVisibility(0);
        Message m = this.customHandler.obtainMessage();
        m.what = MESSAGE_WHAT_setMapViewsInfoFromPhoto_0;
        this.customHandler.sendMessageDelayed(m, 500);
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        saveCurrentSettings();
        stopBgThread();
        super.onPause();
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
        if (this.mGoogleApiClient.isConnected()) {
            this.mGoogleApiClient.disconnect();
        }
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
        destroyCustomHandler();
        ((MyApplication) getApplication()).editPoiList.clear();
    }

    public void onBackPressed() {
        if (this.g_is_et_message_inFocus) {
            et_onBackPressed();
        } else if (this.gIs_content1_full_screen.booleanValue()) {
            this.gIs_content1_full_screen = false;
            FrameLayout.LayoutParams params2 = (FrameLayout.LayoutParams) this.content1_container.getLayoutParams();
            params2.width = this.content1_width;
            params2.height = this.content1_height;
            params2.topMargin = this.content1_marginTop;
            this.content1_container.setLayoutParams(params2);
            this.btn_content1_normal_full_screen.setBackgroundDrawable(getResources().getDrawable(R.drawable.to_full_screen_normal));
        } else {
            super.onBackPressed();
        }
    }

    private void findViews() {
        this.layout_root = (FrameLayout) findViewById(R.id.layout_root);
        this.ll_title_bar = (LinearLayout) findViewById(R.id.ll_title_bar);
        this.btn_title_back = (Button) findViewById(R.id.btn_title_back);
        this.layout_content1 = (LinearLayout) findViewById(R.id.layout_content1);
        this.content1_container = (FrameLayout) findViewById(R.id.content1_container);
        this.btn_content1_normal_full_screen = (Button) findViewById(R.id.btn_content1_normal_full_screen);
        this.btn_content1_normal_full_screen.getBackground().setAlpha(170);
        this.fl_cross_center = (FrameLayout) findViewById(R.id.fl_cross_center);
        this.content1_sp_map_type = (Spinner) findViewById(R.id.content1_sp_map_type);
        this.content1_sp_map_type.getBackground().setAlpha(170);
        this.content1_sp_map_type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> adapterView, View view, int pos, long id) {
                EditPoiPage.this.m_mapTypeSelect = pos;
                EditPoiPage.this.mapGoogleAndroidV2.setMapTypeEx(pos);
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        this.tv_info_Latitude = (TextView) findViewById(R.id.tv_info_Latitude);
        this.tv_info_Longitude = (TextView) findViewById(R.id.tv_info_Longitude);
        this.tv_info_Altitude = (TextView) findViewById(R.id.tv_info_Altitude);
        this.tv_editLatLngAfter = (TextView) findViewById(R.id.tv_editLatLngAfter);
        this.et_info_Latitude = (EditTextWithBackKey) findViewById(R.id.et_info_Latitude);
        this.et_info_Longitude = (EditTextWithBackKey) findViewById(R.id.et_info_Longitude);
        this.et_info_Altitude = (TextView) findViewById(R.id.et_info_Altitude);
        this.et_info_Latitude.setMainActivity(this);
        this.et_info_Longitude.setMainActivity(this);
        this.btn_update_poi = (Button) findViewById(R.id.btn_update_poi);
        this.btn_update_poi.setEnabled(false);
        this.tv_info_Help = (TextView) findViewById(R.id.tv_info_Help);
        this.layout_root.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            public boolean onPreDraw() {
                if (!EditPoiPage.this.hasMeasuredLayout.booleanValue()) {
                    EditPoiPage.this.layout_root_width = EditPoiPage.this.layout_root.getWidth();
                    EditPoiPage.this.layout_root_height = EditPoiPage.this.layout_root.getHeight();
                    EditPoiPage.this.content1_width = EditPoiPage.this.layout_content1.getWidth();
                    EditPoiPage.this.content1_height = EditPoiPage.this.layout_content1.getHeight();
                    EditPoiPage.this.content1_marginTop = EditPoiPage.this.ll_title_bar.getHeight();
                    FrameLayout.LayoutParams params2 = (FrameLayout.LayoutParams) EditPoiPage.this.content1_container.getLayoutParams();
                    params2.width = EditPoiPage.this.content1_width;
                    params2.height = EditPoiPage.this.content1_height;
                    params2.topMargin = EditPoiPage.this.content1_marginTop;
                    params2.bottomMargin = 0;
                    params2.gravity = 48;
                    EditPoiPage.this.content1_container.setLayoutParams(params2);
                    EditPoiPage.this.hasMeasuredLayout = true;
                }
                return true;
            }
        });
        this.btn_title_back.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return EditPoiPage.this.btn_process_title_back(v, event);
            }
        });
        this.btn_content1_normal_full_screen.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return EditPoiPage.this.content1_normal_full_screen_switch(v, event);
            }
        });
        this.btn_update_poi.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(EditPoiPage.this);
                builder.setMessage(EditPoiPage.this.getString(R.string.EditPoiUpdateLatLng)).setCancelable(false).setPositiveButton(EditPoiPage.this.getString(R.string.EditPoiOK), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        synchronized (EditPoiPage.this.gGpsMapAddress) {
                            if (EditPoiPage.this.gGpsMapAddress.latLng != null) {
                                EditPoiPage.this.updatePhotoExif_LatLngAlt(EditPoiPage.this.gGpsMapAddress.latLng);
                            }
                        }
                        dialog.cancel();
                    }
                }).setNegativeButton(EditPoiPage.this.getString(R.string.EditPoiCancel), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
                builder.create().show();
            }
        });
    }

    public boolean btn_process_title_back(View view, MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            case 0:
                this.btn_title_back.setBackgroundDrawable(getResources().getDrawable(R.drawable.rect_blue_btn_press));
                return false;
            case 1:
                this.btn_title_back.setBackgroundDrawable(getResources().getDrawable(R.drawable.rect_blue_btn_normal));
                finish();
                return false;
            default:
                return false;
        }
    }

    public void content1_normal_full_screen_swicth() {
        if (this.content1_container.getHeight() == this.content1_height) {
            this.gIs_content1_full_screen = true;
            FrameLayout.LayoutParams params2 = (FrameLayout.LayoutParams) this.content1_container.getLayoutParams();
            params2.width = this.layout_root_width;
            params2.height = this.layout_root_height;
            params2.topMargin = 0;
            this.content1_container.setLayoutParams(params2);
        } else {
            this.gIs_content1_full_screen = false;
            FrameLayout.LayoutParams params22 = (FrameLayout.LayoutParams) this.content1_container.getLayoutParams();
            params22.width = this.content1_width;
            params22.height = this.content1_height;
            params22.topMargin = this.content1_marginTop;
            this.content1_container.setLayoutParams(params22);
        }
        if (this.gIs_content1_full_screen.booleanValue()) {
            this.btn_content1_normal_full_screen.setBackgroundDrawable(getResources().getDrawable(R.drawable.to_normal_screen_normal));
        } else {
            this.btn_content1_normal_full_screen.setBackgroundDrawable(getResources().getDrawable(R.drawable.to_full_screen_normal));
        }
        this.btn_content1_normal_full_screen.getBackground().setAlpha(200);
    }

    public boolean content1_normal_full_screen_switch(View view, MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            case 0:
                if (this.gIs_content1_full_screen.booleanValue()) {
                    this.btn_content1_normal_full_screen.setBackgroundDrawable(getResources().getDrawable(R.drawable.to_normal_screen_press));
                } else {
                    this.btn_content1_normal_full_screen.setBackgroundDrawable(getResources().getDrawable(R.drawable.to_full_screen_press));
                }
                this.btn_content1_normal_full_screen.getBackground().setAlpha(200);
                return false;
            case 1:
                content1_normal_full_screen_swicth();
                return false;
            default:
                return false;
        }
    }

    public void et_onBackPressed() {
        FrameLayout.LayoutParams params2 = (FrameLayout.LayoutParams) this.content1_container.getLayoutParams();
        params2.width = this.content1_width;
        params2.height = this.content1_height;
        params2.topMargin = this.content1_marginTop;
        params2.leftMargin = 0;
        this.content1_container.setLayoutParams(params2);
        this.tv_editLatLngAfter.setFocusableInTouchMode(true);
        this.tv_editLatLngAfter.requestFocus();
        this.g_is_et_message_inFocus = false;
        String str_info_latitude = this.et_info_Latitude.getText().toString();
        String str_info_longitude = this.et_info_Longitude.getText().toString();
        if (str_info_latitude != null && str_info_longitude != null && str_info_latitude.length() > 0 && str_info_longitude.length() > 0) {
            try {
                this.mapGoogleAndroidV2.setLatitudeLongitude((double) Float.parseFloat(str_info_latitude), (double) Float.parseFloat(str_info_longitude));
                this.mapGoogleAndroidV2.setUpMapIfNeeded();
                this.mapGoogleAndroidV2.onResetMap();
            } catch (NumberFormatException e) {
                this.et_info_Latitude.setText(this.tmp_info_Latitude);
                this.et_info_Longitude.setText(this.tmp_info_Longitude);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void setMapViewsInfoFromPhoto(int position, boolean bMoveIfPhotoNoLatLng) {
        MyLatLng myLatLng = getPhotoLatLng(position);
        if (myLatLng != null) {
            this.mapGoogleAndroidV2.setMapNeedMove(true);
            this.mapGoogleAndroidV2.setMarkerVisible(true);
            this.mapGoogleAndroidV2.setLatitudeLongitude(myLatLng.latitude, myLatLng.longitude);
            this.tv_info_Latitude.setText(String.valueOf(HelpFuncs.getFloatValueDotN(myLatLng.latitude, 6)));
            this.tv_info_Longitude.setText(String.valueOf(HelpFuncs.getFloatValueDotN(myLatLng.longitude, 6)));
            if (myLatLng.altitudeIncluded) {
                this.tv_info_Altitude.setText(String.valueOf(myLatLng.altitude));
            } else {
                this.tv_info_Altitude.setText("-");
            }
        } else {
            this.mapGoogleAndroidV2.setMapNeedMove(bMoveIfPhotoNoLatLng);
            this.gCurLocation = getLocation2();
            if (this.gCurLocation != null) {
                this.mapGoogleAndroidV2.setMarkerVisible(false);
                this.mapGoogleAndroidV2.setLatitudeLongitude(this.gCurLocation.getLatitude(), this.gCurLocation.getLongitude());
            } else {
                this.mapGoogleAndroidV2.setMarkerVisible(false);
                this.mapGoogleAndroidV2.setLatitudeLongitude((double) this.m_editLatitude, (double) this.m_editLongitude);
            }
            this.tv_info_Latitude.setText("-");
            this.tv_info_Longitude.setText("-");
            this.tv_info_Altitude.setText("-");
        }
        this.mapGoogleAndroidV2.setUpMapIfNeeded();
        this.mapGoogleAndroidV2.onResetMap();
        if (this.mapGoogleAndroidV2.isMapReadyForUse()) {
            this.mapGoogleAndroidV2.setMapVisible(true);
            this.content1_sp_map_type.setVisibility(0);
            this.btn_content1_normal_full_screen.setVisibility(0);
            this.fl_cross_center.setVisibility(0);
        }
    }

    /* access modifiers changed from: package-private */
    public void __________mark_on_complete() {
    }

    /* access modifiers changed from: package-private */
    public void initializeSettings() {
        this.settings = getSharedPreferences("JK.FinalFantasy_PoiPhoto_V1.0.0.ini", 0);
        this.m_editLatLngSaved = this.settings.getBoolean("editLatLngSaved", false);
        this.m_editLatitude = this.settings.getFloat("editLatitude", 40.72677f);
        this.m_editLongitude = this.settings.getFloat("editLongitude", -74.07755f);
    }

    /* access modifiers changed from: package-private */
    public void saveCurrentSettings() {
        this.m_editLatLngSaved = true;
        this.settings = getSharedPreferences("JK.FinalFantasy_PoiPhoto_V1.0.0.ini", 0);
        this.settings.edit().putBoolean("editLatLngSaved", this.m_editLatLngSaved).putFloat("editLatitude", this.m_editLatitude).putFloat("editLongitude", this.m_editLongitude).commit();
    }

    /* access modifiers changed from: package-private */
    public void __________mark_Location() {
    }

    private void initLocMgr() {
        this.locMgr = (LocationManager) getSystemService("location");
        setGpsCriteria();
    }

    public void setGpsCriteria() {
        Criteria criteria = new Criteria();
        criteria.setAccuracy(2);
        this.bestProvider = this.locMgr.getBestProvider(criteria, true);
    }

    public Location getLocation() {
        if (this.bestProvider != null) {
            return this.locMgr.getLastKnownLocation(this.bestProvider);
        }
        return null;
    }

    /* access modifiers changed from: package-private */
    public void __________mark_Location_google_play_service() {
    }

    /* access modifiers changed from: protected */
    public synchronized void buildGoogleApiClient() {
        this.mGoogleApiClient = new GoogleApiClient.Builder(this).addConnectionCallbacks(this).addOnConnectionFailedListener(this).addApi(LocationServices.API).build();
    }

    public void onConnected(Bundle connectionHint) {
        this.mbLocationServiceInitialized = true;
    }

    public void onConnectionFailed(ConnectionResult result) {
        this.mbLocationServiceInitialized = true;
    }

    public void onDisconnected() {
        this.mbLocationServiceInitialized = false;
    }

    public void onConnectionSuspended(int cause) {
        this.mGoogleApiClient.connect();
    }

    public Location getLocation2() {
        if (!this.mbLocationServiceInitialized) {
            return null;
        }
        this.mLastLocation = LocationServices.FusedLocationApi.getLastLocation(this.mGoogleApiClient);
        return this.mLastLocation;
    }

    /* access modifiers changed from: package-private */
    public void __________mark_Others() {
    }

    /* access modifiers changed from: package-private */
    public MyLatLng getPhotoLatLng(int position) {
        MyLatLng myLatLng = null;
        if (this.horzGridViewAdapter == null) {
            return null;
        }
        if (this.horzGridViewAdapter.data == null) {
            return null;
        }
        if (this.horzGridViewAdapter.data.get(position) == null) {
            return null;
        }
        if (this.horzGridViewAdapter.data.get(position).get("latitude") == null) {
            return null;
        }
        try {
            ExifInterface exif = new ExifInterface((String) this.horzGridViewAdapter.data.get(position).get("data"));
            if (!(exif == null || exif.getAttribute("GPSLatitude") == null)) {
                GeoDegree gDegree = new GeoDegree(exif);
                MyLatLng myLatLng2 = new MyLatLng((double) gDegree.Latitude.floatValue(), (double) gDegree.Longitude.floatValue());
                try {
                    if (!gDegree.isAltitudeNull.booleanValue()) {
                        myLatLng2.setAltitude((double) gDegree.Altitude.floatValue());
                        myLatLng = myLatLng2;
                    } else {
                        myLatLng = myLatLng2;
                    }
                } catch (IOException e) {
                    e = e;
                    MyLatLng myLatLng3 = myLatLng2;
                    e.printStackTrace();
                    myLatLng = null;
                    return myLatLng;
                }
            }
        } catch (IOException e2) {
            e = e2;
            e.printStackTrace();
            myLatLng = null;
            return myLatLng;
        }
        return myLatLng;
    }

    /* access modifiers changed from: package-private */
    public void __________mark_thread() {
    }

    public void startBgThread() {
        this.bgThread.setPriority(4);
        if (this.bgThread.getState() == Thread.State.NEW) {
            this.bgThread.start();
        }
        this.gIsThreadStarted = true;
    }

    public void pauseBgThread() {
        if (this.gIsThreadStarted) {
            this.bgThread.onPause();
        }
    }

    public void resumeBgThread() {
        if (this.gIsThreadStarted) {
            this.bgThread.onResume();
        }
    }

    public void stopBgThread() {
        if (this.gIsThreadStarted) {
            this.bgThread.interrupt();
            this.gIsThreadStarted = false;
        }
    }

    class BgThread extends Thread {
        Activity a;
        private Object mPauseLock = new Object();
        private boolean mPaused = false;

        BgThread(Activity activity) {
            this.a = activity;
        }

        public void onPause() {
            synchronized (this.mPauseLock) {
                this.mPaused = true;
            }
        }

        public void onResume() {
            synchronized (this.mPauseLock) {
                this.mPaused = false;
                this.mPauseLock.notifyAll();
            }
        }

        public void run() {
            List<Address> addresses;
            while (!Thread.interrupted()) {
                MyLatLng googleMapLatLng = null;
                Address googleMapGoogleAddress = null;
                Boolean bGetLocationFromList = false;
                synchronized (EditPoiPage.this.gMapcenterList) {
                    for (int i = 0; i < EditPoiPage.this.gMapcenterList.size(); i++) {
                        googleMapLatLng = EditPoiPage.this.gMapcenterList.remove(0);
                        bGetLocationFromList = true;
                    }
                }
                if (bGetLocationFromList.booleanValue()) {
                    if (googleMapLatLng != null) {
                        if (EditPoiPage.this.gGeocoder == null) {
                            EditPoiPage.this.gGeocoder = new Geocoder(EditPoiPage.this.getApplicationContext(), Locale.getDefault());
                        }
                        try {
                            List<Address> addresses2 = EditPoiPage.this.gGeocoder.getFromLocation(googleMapLatLng.latitude, googleMapLatLng.longitude, 1);
                            if (addresses2 != null && addresses2.size() > 0) {
                                googleMapGoogleAddress = addresses2.get(0);
                            }
                        } catch (IllegalArgumentException e) {
                            e.printStackTrace();
                        } catch (IOException e2) {
                            e2.printStackTrace();
                        }
                        if (googleMapGoogleAddress == null && (addresses = ReverseGeocode.getFromLocation(googleMapLatLng.latitude, googleMapLatLng.longitude, 1)) != null && addresses.size() > 0) {
                            googleMapGoogleAddress = addresses.get(0);
                        }
                    }
                    synchronized (EditPoiPage.this.gGpsMapAddress) {
                        EditPoiPage.this.gGpsMapAddress.latLng = googleMapLatLng;
                        EditPoiPage.this.gGpsMapAddress.address = googleMapGoogleAddress;
                        this.a.runOnUiThread(new MapUpdateDisplayer());
                    }
                }
                for (int i2 = 0; i2 < 10; i2++) {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e3) {
                        e3.printStackTrace();
                    }
                    if (Thread.interrupted()) {
                        continue;
                        break;
                    }
                    synchronized (this.mPauseLock) {
                        while (this.mPaused) {
                            try {
                                this.mPauseLock.wait();
                            } catch (InterruptedException e4) {
                            }
                        }
                    }
                }
            }
        }
    }

    class MapUpdateDisplayer implements Runnable {
        MapUpdateDisplayer() {
        }

        public void run() {
            synchronized (EditPoiPage.this.gGpsMapAddress) {
                if (EditPoiPage.this.gGpsMapAddress.latLng != null) {
                    double dLatitude = EditPoiPage.this.gGpsMapAddress.latLng.latitude;
                    double dLongitude = EditPoiPage.this.gGpsMapAddress.latLng.longitude;
                    double dAltitude = EditPoiPage.this.gGpsMapAddress.latLng.altitude;
                    EditPoiPage.this.et_info_Latitude.setText(String.valueOf(HelpFuncs.getFloatValueDotN(dLatitude, 6)));
                    EditPoiPage.this.et_info_Longitude.setText(String.valueOf(HelpFuncs.getFloatValueDotN(dLongitude, 6)));
                    if (EditPoiPage.this.gGpsMapAddress.latLng.altitudeIncluded) {
                        EditPoiPage.this.et_info_Altitude.setText(String.valueOf(dAltitude));
                    }
                    if (EditPoiPage.this.gGpsMapAddress.address != null) {
                        String addressLine = EditPoiPage.this.gGpsMapAddress.address.getAddressLine(0);
                        if (addressLine != null) {
                            EditPoiPage.this.tv_info_Help.setText(addressLine);
                        } else {
                            EditPoiPage.this.tv_info_Help.setText("");
                        }
                    } else {
                        EditPoiPage.this.tv_info_Help.setText("");
                    }
                    if (!EditPoiPage.this.btn_update_poi.isEnabled()) {
                        EditPoiPage.this.btn_update_poi.setEnabled(true);
                    }
                }
            }
        }
    }

    private MyLatLng getElevationFromGoogleMaps(MyLatLng myLatLng) {
        MyLatLng retLatLng = new MyLatLng(myLatLng.latitude, myLatLng.longitude);
        String response = "";
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new DefaultHttpClient().execute(new HttpGet("https://maps.googleapis.com/maps/api/elevation/json?locations=" + myLatLng.latitude + "," + myLatLng.longitude + "&sensor=false&key=AIzaSyAJl2GP8pID4WK8SHrA_IaShPPFCyiR8pY")).getEntity().getContent()));
            while (true) {
                String buff = br.readLine();
                if (buff == null) {
                    break;
                }
                response = String.valueOf(response) + buff;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        String statusString = null;
        try {
            JSONObject jSONObject = new JSONObject(response);
            if (jSONObject != null) {
                try {
                    statusString = jSONObject.getString("status");
                } catch (JSONException e1) {
                    e1.printStackTrace();
                }
                if (statusString == null) {
                    return null;
                }
                if (statusString.equalsIgnoreCase("OK")) {
                    try {
                        JSONArray results = (JSONArray) jSONObject.get("results");
                        for (int i = 0; i < 1; i++) {
                            JSONObject result = results.getJSONObject(i);
                            if (result.has("elevation")) {
                                retLatLng.setAltitude(Double.valueOf(result.getString("elevation")).doubleValue());
                                return retLatLng;
                            }
                        }
                    } catch (JSONException e2) {
                        e2.printStackTrace();
                    }
                }
            }
            return null;
        } catch (JSONException e3) {
            return null;
        }
    }

    /* access modifiers changed from: package-private */
    public String dec2DMS(double coord) {
        if (coord <= 0.0d) {
            coord = -coord;
        }
        String sOut = String.valueOf(Integer.toString((int) coord)) + "/1,";
        double coord2 = (coord % 1.0d) * 60.0d;
        return String.valueOf(String.valueOf(sOut) + Integer.toString((int) coord2) + "/1,") + Integer.toString((int) ((coord2 % 1.0d) * 60000.0d)) + "/1000";
    }

    /* access modifiers changed from: private */
    @SuppressLint({"NewApi"})
    public void updatePhotoExif_LatLngAlt(MyLatLng orgLatLng) {
        if (orgLatLng != null) {
            try {
                ExifInterface orgexif = new ExifInterface((String) ((MyApplication) getApplication()).editPoiList.get(m_curFilePosition).get("data"));
                orgexif.setAttribute("GPSLatitude", dec2DMS(orgLatLng.latitude));
                if (orgLatLng.latitude > 0.0d) {
                    orgexif.setAttribute("GPSLatitudeRef", "N");
                } else {
                    orgexif.setAttribute("GPSLatitudeRef", "S");
                }
                orgexif.setAttribute("GPSLongitude", dec2DMS(orgLatLng.longitude));
                if (orgLatLng.longitude > 0.0d) {
                    orgexif.setAttribute("GPSLongitudeRef", "E");
                } else {
                    orgexif.setAttribute("GPSLongitudeRef", "W");
                }
                orgexif.saveAttributes();
                ContentValues values = new ContentValues();
                values.put("latitude", String.valueOf(HelpFuncs.getFloatValueDotN(orgLatLng.latitude, 6)));
                values.put("longitude", String.valueOf(HelpFuncs.getFloatValueDotN(orgLatLng.longitude, 6)));
                getContentResolver().update(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values, "_id=" + ((String) ((MyApplication) getApplication()).editPoiList.get(m_curFilePosition).get("id")), (String[]) null);
                this.tv_info_Latitude.setText(String.valueOf(HelpFuncs.getFloatValueDotN(orgLatLng.latitude, 6)));
                this.tv_info_Longitude.setText(String.valueOf(HelpFuncs.getFloatValueDotN(orgLatLng.longitude, 6)));
                this.horzGridViewAdapter.data.get(m_curFilePosition).put("latitude", String.valueOf(HelpFuncs.getFloatValueDotN(orgLatLng.latitude, 6)));
                this.mapGoogleAndroidV2.setMapNeedMove(false);
                this.mapGoogleAndroidV2.setMarkerVisible(true);
                this.mapGoogleAndroidV2.setLatitudeLongitude(orgLatLng.latitude, orgLatLng.longitude);
                this.mapGoogleAndroidV2.setUpMapIfNeeded();
                this.mapGoogleAndroidV2.onResetMap();
                if (this.mapGoogleAndroidV2.isMapReadyForUse()) {
                    this.mapGoogleAndroidV2.setMapVisible(true);
                    this.content1_sp_map_type.setVisibility(0);
                    this.btn_content1_normal_full_screen.setVisibility(0);
                    this.fl_cross_center.setVisibility(0);
                }
                this.m_editLatitude = (float) orgLatLng.latitude;
                this.m_editLongitude = (float) orgLatLng.longitude;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
