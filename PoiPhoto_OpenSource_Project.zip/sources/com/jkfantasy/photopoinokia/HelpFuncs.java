package com.jkfantasy.photopoinokia;

public class HelpFuncs {
    static double getFloatValueDotN(double inValue, int N) {
        double multiValue = Math.pow(10.0d, (double) N);
        return ((double) Math.round(inValue * multiValue)) / multiValue;
    }
}
