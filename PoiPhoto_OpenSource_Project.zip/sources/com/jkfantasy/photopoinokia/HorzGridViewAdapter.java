package com.jkfantasy.photopoinokia;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.AsyncTask;
import android.os.Build;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import java.lang.ref.SoftReference;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;

public class HorzGridViewAdapter extends BaseAdapter {
    private final int childLayoutResourceId = R.layout.horz_gridview_child_layout;
    /* access modifiers changed from: private */
    public int columnWidth;
    private int columns;
    ArrayList<HashMap<String, String>> data;
    private Map<ImageView, String> imageViews = Collections.synchronizedMap(new WeakHashMap());
    private int itemPadding;
    private Context mContext;
    MemoryCache memoryCache = new MemoryCache();
    /* access modifiers changed from: private */
    public int rowHeight;
    private int rows;

    public HorzGridViewAdapter(Context context, ArrayList<HashMap<String, String>> data2) {
        this.mContext = context;
        this.data = data2;
        Resources res = this.mContext.getResources();
        this.itemPadding = (int) res.getDimension(R.dimen.horz_item_padding);
        int[] rowsColumns = res.getIntArray(R.array.horz_gv_rows_columns);
        this.rows = rowsColumns[0];
        this.columns = rowsColumns[1];
        EditPoiPage.horzGridView.setNumRows(this.rows);
        EditPoiPage.horzGridView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @SuppressLint({"NewApi"})
            public void onGlobalLayout() {
                HorzGridViewAdapter horzGridViewAdapter = HorzGridViewAdapter.this;
                HorzGridViewAdapter horzGridViewAdapter2 = HorzGridViewAdapter.this;
                int height = (int) ((float) EditPoiPage.horzGridView.getHeight());
                horzGridViewAdapter2.rowHeight = height;
                horzGridViewAdapter.columnWidth = height;
                EditPoiPage.horzGridView.setRowHeight(HorzGridViewAdapter.this.rowHeight);
                ViewTreeObserver vto = EditPoiPage.horzGridView.getViewTreeObserver();
                if (Build.VERSION.SDK_INT >= 16) {
                    vto.removeOnGlobalLayoutListener(this);
                } else {
                    vto.removeGlobalOnLayoutListener(this);
                }
            }
        });
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHandler handler;
        HashMap hashMap = this.data.get(position);
        if (convertView == null) {
            convertView = ((LayoutInflater) this.mContext.getSystemService("layout_inflater")).inflate(R.layout.horz_gridview_child_layout, parent, false);
            handler = new ViewHandler(this, (ViewHandler) null);
            handler.iv = (ImageView) convertView.findViewById(R.id.horz_gv_iv);
            convertView.setTag(handler);
        } else {
            handler = (ViewHandler) convertView.getTag();
        }
        DisplayImage(String.valueOf(position), handler.iv);
        if (EditPoiPage.m_curFilePosition == position) {
            handler.iv.setBackgroundColor(-16711681);
        } else {
            handler.iv.setBackgroundColor(-1);
        }
        handler.iv.setLayoutParams(new FrameLayout.LayoutParams(this.columnWidth, this.rowHeight));
        Log.d("HorzGVAdapter", "Position:" + position + ",children:" + parent.getChildCount());
        return convertView;
    }

    private class ViewHandler {
        ImageView iv;

        private ViewHandler() {
        }

        /* synthetic */ ViewHandler(HorzGridViewAdapter horzGridViewAdapter, ViewHandler viewHandler) {
            this();
        }
    }

    public int getCount() {
        return this.data.size();
    }

    public Object getItem(int position) {
        return this.data.get(position);
    }

    public long getItemId(int position) {
        return 0;
    }

    /* access modifiers changed from: package-private */
    public void __________mark_memory_cache() {
    }

    public class MemoryCache {
        private HashMap<String, SoftReference<Bitmap>> cache = new HashMap<>();

        public MemoryCache() {
        }

        public Bitmap get(String id) {
            if (!this.cache.containsKey(id)) {
                return null;
            }
            return this.cache.get(id).get();
        }

        public void put(String id, Bitmap bitmap) {
            this.cache.put(id, new SoftReference(bitmap));
        }

        public void clear() {
            this.cache.clear();
        }
    }

    public void DisplayImage(String url, ImageView imageView) {
        this.imageViews.put(imageView, url);
        Bitmap bitmap = this.memoryCache.get(url);
        if (bitmap != null) {
            imageView.setImageBitmap(bitmap);
            return;
        }
        loadBitmap(url, imageView);
        imageView.setImageResource(R.drawable.gray_16x16);
    }

    /* access modifiers changed from: package-private */
    public void __________mark_decode_jpeg_async() {
    }

    public void loadBitmap(String sPosition, ImageView imageView) {
        new BitmapWorkerTask(imageView).execute(new String[]{sPosition});
    }

    class BitmapWorkerTask extends AsyncTask<String, Void, Bitmap> {
        private String data = "";
        private final WeakReference<ImageView> imageViewReference;
        int iv_height = 0;
        int iv_width = 0;

        public BitmapWorkerTask(ImageView imageView) {
            this.imageViewReference = new WeakReference<>(imageView);
            this.iv_width = imageView.getWidth();
            this.iv_height = imageView.getHeight();
        }

        /* access modifiers changed from: protected */
        public Bitmap doInBackground(String... params) {
            this.data = params[0];
            return HorzGridViewAdapter.this.decodeThumbnailBitmapFromPhotoPosition(this.data, this.iv_width, this.iv_height);
        }

        /* access modifiers changed from: protected */
        public void onPostExecute(Bitmap bitmap) {
            ImageView imageView;
            if (this.imageViewReference != null && bitmap != null && (imageView = (ImageView) this.imageViewReference.get()) != null) {
                imageView.setImageBitmap(bitmap);
            }
        }
    }

    public Bitmap decodeThumbnailBitmapFromPhotoPosition(String sPosition, int reqWidth, int reqHeight) {
        int image_orientation;
        int position = Integer.valueOf(sPosition).intValue();
        Bitmap bmThumbnail = MediaStore.Images.Thumbnails.getThumbnail(this.mContext.getContentResolver(), (long) Integer.valueOf((String) this.data.get(position).get("id")).intValue(), 3, (BitmapFactory.Options) null);
        if (bmThumbnail != null && (image_orientation = Integer.valueOf((String) this.data.get(position).get("orientation")).intValue()) > 0) {
            Matrix matrix = new Matrix();
            matrix.postRotate((float) image_orientation);
            bmThumbnail = Bitmap.createBitmap(bmThumbnail, 0, 0, bmThumbnail.getWidth(), bmThumbnail.getHeight(), matrix, true);
        }
        this.memoryCache.put(sPosition, bmThumbnail);
        return bmThumbnail;
    }
}
