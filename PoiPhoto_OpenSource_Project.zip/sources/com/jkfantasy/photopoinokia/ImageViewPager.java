package com.jkfantasy.photopoinokia;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;

public class ImageViewPager extends ViewPager {
    private boolean post_swipe = true;
    private boolean swipe = true;

    public boolean isSwipe() {
        return this.swipe;
    }

    public void setSwipe(boolean in_swipe) {
        this.post_swipe = in_swipe;
        this.swipe = in_swipe;
    }

    public ImageViewPager(Context context) {
        super(context);
    }

    public ImageViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public boolean onInterceptTouchEvent(MotionEvent arg0) {
        if (this.swipe) {
            return super.onInterceptTouchEvent(arg0);
        }
        return false;
    }
}
