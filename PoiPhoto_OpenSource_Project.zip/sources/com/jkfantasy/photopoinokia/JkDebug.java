package com.jkfantasy.photopoinokia;

class JkDebug {
    static final Boolean isAdEnable = true;
    static final Boolean isAdInDebugMode = false;
    static final Boolean isPowerWakeLockEnable = true;
    static final Boolean isRunOnDevice = true;

    JkDebug() {
    }
}
