package com.jkfantasy.photopoinokia;

public final class Manifest {

    public static final class permission {
        public static final String MAPS_RECEIVE = "com.jkfantasy.photopoinokia.permission.MAPS_RECEIVE";
    }
}
