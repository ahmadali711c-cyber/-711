package com.jkfantasy.photopoinokia;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Message;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;

public class MapNokiaJavascript {
    boolean bPageFinished = false;
    MainActivity mActivity = null;
    boolean mIsPlaceSearchInputFocus = false;
    WebView mMap = null;
    ArrayList<HashMap<String, String>> mPlaceList = new ArrayList<>();
    MyLatLng m_curLatLng = null;

    public class MyLatLng {
        double latitude;
        double longitude;

        MyLatLng(double lati, double longi) {
            this.latitude = lati;
            this.longitude = longi;
        }
    }

    public class MyWebViewInterface {
        public MyWebViewInterface() {
        }

        @JavascriptInterface
        public void onMapZoomLevelChanged(int zoomLevel) {
            MapNokiaJavascript.this.mActivity.m_mapZoomLevel = Float.valueOf((float) zoomLevel).floatValue();
        }

        @JavascriptInterface
        public void onMapTypeIdChanged(int mapTypeSelect) {
            MapNokiaJavascript.this.mActivity.m_mapTypeSelect = mapTypeSelect;
        }

        @JavascriptInterface
        public void onMapScreenChanged() {
            Message m = MapNokiaJavascript.this.mActivity.customHandler.obtainMessage();
            m.what = 512;
            MapNokiaJavascript.this.mActivity.customHandler.sendMessageDelayed(m, 10);
        }

        @JavascriptInterface
        public void onPlaceNameAddrBegin() {
            MapNokiaJavascript.this.mPlaceList.clear();
        }

        @JavascriptInterface
        public void onPlaceNameAddrSet(int id, String name, String addr) {
            HashMap<String, String> hash = new HashMap<>();
            hash.put("id", new StringBuilder(String.valueOf(id)).toString());
            hash.put("name", name);
            hash.put("addr", addr);
            MapNokiaJavascript.this.mPlaceList.add(hash);
        }

        @JavascriptInterface
        public void onPlaceNameAddrEnd() {
            Message m = MapNokiaJavascript.this.mActivity.customHandler.obtainMessage();
            m.what = 513;
            MapNokiaJavascript.this.mActivity.customHandler.sendMessageDelayed(m, 10);
        }

        @JavascriptInterface
        public void onSettingsLayerIndex(int value) {
            MapNokiaJavascript.this.mActivity.m_mapLayerIndex = value;
        }

        @JavascriptInterface
        public void onSettingsWeatherDegreeIsC(boolean value) {
            MapNokiaJavascript.this.mActivity.m_mapWeatherDegreeIsC = value;
        }

        @JavascriptInterface
        public void onSettingsPlaceSearchValue(String value) {
            MapNokiaJavascript.this.mActivity.m_mapPlaceSearchValue = value;
        }

        @JavascriptInterface
        public void onSettingsPlaceCmpIndex(int value) {
            MapNokiaJavascript.this.mActivity.m_mapPlaceCmpIndex = value;
        }

        @JavascriptInterface
        public void onSettingsPlaceCmpString(String value) {
            MapNokiaJavascript.this.mActivity.m_mapPlaceCmpString = value;
        }

        @JavascriptInterface
        public void onPlaceSearchInputFocus(boolean value) {
            MapNokiaJavascript.this.mIsPlaceSearchInputFocus = value;
        }

        @JavascriptInterface
        public void onToastPlaceSearchStatusERROR(String searchStr, String value) {
            String errorStr = null;
            if (value.equals("ERROR")) {
                errorStr = "\"" + searchStr + "\":\n" + MapNokiaJavascript.this.mActivity.getString(R.string.MT_PlaceSearchStatus_ERROR);
            } else if (value.equals("INVALID_REQUEST")) {
                errorStr = "\"" + searchStr + "\":\n" + MapNokiaJavascript.this.mActivity.getString(R.string.MT_PlaceSearchStatus_INVALID_REQUEST);
            } else if (value.equals("OVER_QUERY_LIMIT")) {
                errorStr = "\"" + searchStr + "\":\n" + MapNokiaJavascript.this.mActivity.getString(R.string.MT_PlaceSearchStatus_OVER_QUERY_LIMIT);
            } else if (value.equals("NOT_FOUND")) {
                errorStr = "\"" + searchStr + "\":\n" + MapNokiaJavascript.this.mActivity.getString(R.string.MT_PlaceSearchStatus_NOT_FOUND);
            } else if (value.equals("REQUEST_DENIED")) {
                errorStr = "\"" + searchStr + "\":\n" + MapNokiaJavascript.this.mActivity.getString(R.string.MT_PlaceSearchStatus_REQUEST_DENIED);
            } else if (value.equals("UNKNOWN_ERROR")) {
                errorStr = "\"" + searchStr + "\":\n" + MapNokiaJavascript.this.mActivity.getString(R.string.MT_PlaceSearchStatus_UNKNOWN_ERROR);
            } else if (value.equals("ZERO_RESULTS")) {
                errorStr = "\"" + searchStr + "\":\n" + MapNokiaJavascript.this.mActivity.getString(R.string.MT_PlaceSearchStatus_ZERO_RESULTS);
            }
            if (errorStr != null) {
                Toast.makeText(MapNokiaJavascript.this.mActivity, errorStr, 1).show();
            }
        }

        @JavascriptInterface
        public void onToastClearSearchText() {
            Toast.makeText(MapNokiaJavascript.this.mActivity, MapNokiaJavascript.this.mActivity.getString(R.string.MT_ClearSearchText), 1).show();
        }

        @JavascriptInterface
        public void onLogString(String logStr) {
        }
    }

    class MyWebViewClient extends WebViewClient {
        MyWebViewClient() {
        }

        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
        }

        public void onPageFinished(WebView view, String url) {
            MapNokiaJavascript.this.bPageFinished = true;
            MapNokiaJavascript.this.mMap.loadUrl("javascript:addChangeListener()");
            MapNokiaJavascript.this.mMap.loadUrl("javascript:initOtherSettings()");
            Message m = MapNokiaJavascript.this.mActivity.customHandler.obtainMessage();
            m.what = 514;
            MapNokiaJavascript.this.mActivity.customHandler.sendMessageDelayed(m, 2000);
            super.onPageFinished(view, url);
        }

        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            super.onReceivedError(view, errorCode, description, failingUrl);
        }

        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            MapNokiaJavascript.this.mActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
            return true;
        }
    }

    class MyWebChromeClient extends WebChromeClient {
        MyWebChromeClient() {
        }

        public boolean onConsoleMessage(ConsoleMessage cm) {
            return super.onConsoleMessage(cm);
        }
    }

    /* access modifiers changed from: package-private */
    public void setMainActivity(MainActivity mainActivity) {
        this.mActivity = mainActivity;
    }

    public void setUpMapIfNeeded() {
        if (!this.bPageFinished) {
            this.mMap = (WebView) this.mActivity.findViewById(R.id.googleMapJavascriptV3);
            if (this.mMap != null) {
                setUpMap();
                return;
            }
            this.mActivity.content1_sp_map_type.setVisibility(4);
            this.mActivity.btn_content1_normal_full_screen.setVisibility(4);
        }
    }

    private void setUpMap() {
        try {
            this.mMap.getSettings().setJavaScriptEnabled(true);
            this.mMap.addJavascriptInterface(new MyWebViewInterface(), "MainActivityInterface");
            this.mMap.setWebViewClient(new MyWebViewClient());
            InputStream stream = this.mActivity.getAssets().open("nok/main.html");
            byte[] buffer = new byte[stream.available()];
            stream.read(buffer);
            stream.close();
            this.mMap.loadDataWithBaseURL("file:///android_asset/nok", new String(buffer).replace("center:[0,0]", "center:[" + this.m_curLatLng.latitude + "," + this.m_curLatLng.longitude + "]").replace("API_ID_CODE", "nokia.Settings.set('app_id', '4JbXt814TNgO2LQsz71x');nokia.Settings.set('app_code', '7aqz7eZ2oQiRd_kca0zBrg');"), "text/html", "utf-8", (String) null);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void addMarkersToMap() {
        if (this.m_curLatLng != null) {
            this.mMap.loadUrl("javascript:modifyMarker(" + this.m_curLatLng.latitude + "," + this.m_curLatLng.longitude + ")");
        }
    }

    private boolean checkReady() {
        if (this.mMap != null) {
            return true;
        }
        Toast.makeText(this.mActivity, R.string.map_not_ready, 0).show();
        return false;
    }

    public void onResetMap() {
        if (this.bPageFinished && checkReady()) {
            addMarkersToMap();
        }
    }

    public void setMapTypeEx(int posOfSelect) {
    }

    public boolean isMapReadyForUse() {
        if (((WebView) this.mActivity.findViewById(R.id.googleMapJavascriptV3)) != null) {
            return true;
        }
        return false;
    }

    public void setLatitudeLongitude(double latitude, double longitude) {
        this.m_curLatLng = new MyLatLng(latitude, longitude);
    }

    public void setMapVisible(boolean bVisible) {
        if (bVisible) {
            WebView tmpView = (WebView) this.mActivity.findViewById(R.id.googleMapJavascriptV3);
            if (tmpView != null) {
                tmpView.setVisibility(0);
                return;
            }
            return;
        }
        WebView tmpView2 = (WebView) this.mActivity.findViewById(R.id.googleMapJavascriptV3);
        if (tmpView2 != null) {
            tmpView2.setVisibility(4);
        }
    }

    public void setPlacePosition(int position) {
        this.mMap.loadUrl("javascript:placeSetPosition(" + String.valueOf(position) + ")");
    }

    public void setBackKeyPressed() {
        this.mMap.loadUrl("javascript:setBackKeyPressed()");
    }

    public void setGotoFullScreenImage(boolean isFullScreen) {
        this.mMap.loadUrl("javascript:setGotoFullScreenImage(" + String.valueOf(isFullScreen) + ")");
    }
}
