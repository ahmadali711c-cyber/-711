package com.jkfantasy.photopoinokia;

import android.app.Application;
import java.util.ArrayList;
import java.util.HashMap;

public class MyApplication extends Application {
    ArrayList<HashMap<String, String>> editPoiList = new ArrayList<>();

    public void onCreate() {
        try {
            Class.forName("android.os.AsyncTask");
        } catch (Throwable th) {
        }
    }
}
