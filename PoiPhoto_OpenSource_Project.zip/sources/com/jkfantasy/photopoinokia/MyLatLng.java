package com.jkfantasy.photopoinokia;

public class MyLatLng {
    double altitude = 0.0d;
    boolean altitudeIncluded = false;
    double latitude = 0.0d;
    double longitude = 0.0d;

    MyLatLng(double lati, double longi) {
        this.latitude = lati;
        this.longitude = longi;
    }

    /* access modifiers changed from: package-private */
    public void setAltitude(double alti) {
        this.altitude = alti;
        this.altitudeIncluded = true;
    }
}
