package com.jkfantasy.photopoinokia;

/* compiled from: PhotoProcessAsyncTask */
class PHOTO_PROCESS_MODE {
    static final int DELETE = 0;
    static final int ROTATE_LEFT = 1;
    static final int ROTATE_RIGHT = 2;

    PHOTO_PROCESS_MODE() {
    }
}
