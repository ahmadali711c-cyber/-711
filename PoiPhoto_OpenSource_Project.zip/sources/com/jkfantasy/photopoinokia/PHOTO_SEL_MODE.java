package com.jkfantasy.photopoinokia;

/* compiled from: MainActivity */
class PHOTO_SEL_MODE {
    static final String NOMAL = "1";
    static final String NOT_JPEG = "-2";
    static final String NOT_SELECT = "0";

    PHOTO_SEL_MODE() {
    }
}
