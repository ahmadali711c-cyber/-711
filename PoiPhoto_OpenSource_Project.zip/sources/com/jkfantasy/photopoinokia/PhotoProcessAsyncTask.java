package com.jkfantasy.photopoinokia;

import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.media.ExifInterface;
import android.os.AsyncTask;
import android.provider.MediaStore;
import android.support.v4.view.PagerAdapter;
import android.util.Log;
import android.widget.ListAdapter;
import java.io.File;
import java.io.IOException;

public class PhotoProcessAsyncTask extends AsyncTask<Void, Integer, Void> {
    MainActivity activity;
    int finish_func_file_count = 0;
    int max_func_file_count = 0;
    int photoProcessMode = 0;
    private volatile boolean running = true;

    /* access modifiers changed from: package-private */
    public void setMainActivity(MainActivity activity2) {
        this.activity = activity2;
    }

    /* access modifiers changed from: package-private */
    public void setProcessMode(int photoProcessMode2) {
        this.photoProcessMode = photoProcessMode2;
    }

    /* access modifiers changed from: package-private */
    public String getLeftOrientationNumber(String curNumber) {
        int number = Integer.valueOf(curNumber).intValue();
        if (number == 1 || number == 0) {
            return "8";
        }
        if (number == 8) {
            return "3";
        }
        if (number == 3) {
            return "6";
        }
        if (number == 6) {
            return "1";
        }
        return "1";
    }

    /* access modifiers changed from: package-private */
    public String getRightOrientationNumber(String curNumber) {
        int number = Integer.valueOf(curNumber).intValue();
        if (number == 1 || number == 0) {
            return "6";
        }
        if (number == 6) {
            return "3";
        }
        if (number == 3) {
            return "8";
        }
        if (number == 8) {
            return "1";
        }
        return "1";
    }

    /* access modifiers changed from: protected */
    public void onPreExecute() {
        this.activity.gProgressDlg = new ProgressDialog(this.activity);
        if (this.photoProcessMode == 0) {
            this.activity.gProgressDlg.setTitle(this.activity.getString(R.string.photo_delete_low_ch));
        } else if (this.photoProcessMode == 1) {
            this.activity.gProgressDlg.setTitle(this.activity.getString(R.string.photo_rotate_left));
        } else {
            this.activity.gProgressDlg.setTitle(this.activity.getString(R.string.photo_rotate_right));
        }
        this.activity.gProgressDlg.setIndeterminate(false);
        this.activity.gProgressDlg.setCancelable(false);
        this.activity.gProgressDlg.setOnCancelListener(new DialogInterface.OnCancelListener() {
            public void onCancel(DialogInterface dialog) {
                PhotoProcessAsyncTask.this.cancel(true);
            }
        });
        this.activity.gProgressDlg.setProgressStyle(1);
        for (int i = 0; i < this.activity.mainList.size(); i++) {
            if (this.activity.imageList_forSel.get(i) != "0") {
                this.max_func_file_count++;
            }
        }
        this.activity.gProgressDlg.setMax(this.max_func_file_count);
        this.activity.gProgressDlg.show();
        super.onPreExecute();
    }

    /* access modifiers changed from: protected */
    public Void doInBackground(Void... params) {
        String degreeStr;
        String degreeStr2;
        String[] paths = {new String()};
        while (this.finish_func_file_count < this.max_func_file_count) {
            for (int i = 0; i < this.activity.mainList.size(); i++) {
                if (this.activity.imageList_forSel.get(i) != "0") {
                    Log.i("ExternalStorageEx", "i = " + Integer.valueOf(i));
                    if (this.photoProcessMode == 0) {
                        paths[0] = (String) this.activity.mainList.get(i).get("data");
                        if (new File(paths[0]).delete()) {
                            this.activity.getContentResolver().delete(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "_id=" + ((String) this.activity.mainList.get(i).get("id")), (String[]) null);
                        }
                        this.finish_func_file_count++;
                        publishProgress(new Integer[]{Integer.valueOf(this.finish_func_file_count)});
                    }
                    if (this.photoProcessMode == 1) {
                        paths[0] = (String) this.activity.mainList.get(i).get("data");
                        try {
                            ExifInterface exif = new ExifInterface(paths[0]);
                            String tagNextOrient = getLeftOrientationNumber(exif.getAttribute("Orientation"));
                            exif.setAttribute("Orientation", tagNextOrient);
                            exif.saveAttributes();
                            if (Integer.valueOf(tagNextOrient).intValue() == 1) {
                                degreeStr2 = "0";
                            } else if (Integer.valueOf(tagNextOrient).intValue() == 6) {
                                degreeStr2 = "90";
                            } else if (Integer.valueOf(tagNextOrient).intValue() == 3) {
                                degreeStr2 = "180";
                            } else if (Integer.valueOf(tagNextOrient).intValue() == 8) {
                                degreeStr2 = "270";
                            } else {
                                degreeStr2 = "0";
                            }
                            ContentValues values = new ContentValues();
                            values.put("orientation", degreeStr2);
                            this.activity.getContentResolver().update(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values, "_id=" + ((String) this.activity.mainList.get(i).get("id")), (String[]) null);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        this.finish_func_file_count++;
                        publishProgress(new Integer[]{Integer.valueOf(this.finish_func_file_count)});
                    }
                    if (this.photoProcessMode == 2) {
                        paths[0] = (String) this.activity.mainList.get(i).get("data");
                        try {
                            ExifInterface exif2 = new ExifInterface(paths[0]);
                            String tagNextOrient2 = getRightOrientationNumber(exif2.getAttribute("Orientation"));
                            exif2.setAttribute("Orientation", tagNextOrient2);
                            exif2.saveAttributes();
                            if (Integer.valueOf(tagNextOrient2).intValue() == 1) {
                                degreeStr = "0";
                            } else if (Integer.valueOf(tagNextOrient2).intValue() == 6) {
                                degreeStr = "90";
                            } else if (Integer.valueOf(tagNextOrient2).intValue() == 3) {
                                degreeStr = "180";
                            } else if (Integer.valueOf(tagNextOrient2).intValue() == 8) {
                                degreeStr = "270";
                            } else {
                                degreeStr = "0";
                            }
                            ContentValues values2 = new ContentValues();
                            values2.put("orientation", degreeStr);
                            this.activity.getContentResolver().update(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values2, "_id=" + ((String) this.activity.mainList.get(i).get("id")), (String[]) null);
                        } catch (IOException e2) {
                            e2.printStackTrace();
                        }
                        this.finish_func_file_count++;
                        publishProgress(new Integer[]{Integer.valueOf(this.finish_func_file_count)});
                    }
                }
                if (!this.running) {
                    break;
                }
            }
            if (!this.running) {
                return null;
            }
        }
        return null;
    }

    /* access modifiers changed from: protected */
    public void onProgressUpdate(Integer... progress) {
        this.activity.gProgressDlg.setProgress(progress[0].intValue());
    }

    /* access modifiers changed from: protected */
    public void onPostExecute(Void result) {
        this.activity.isFileSelectModeEnabled = false;
        this.activity.isLongItemSelected = false;
        this.activity.submenu_toolbar_func0.setVisibility(0);
        this.activity.submenu_toolbar_func1.setVisibility(4);
        if (!this.activity.isFileSelectModeEnabled.booleanValue()) {
            this.activity.imageList_forSel.clear();
        }
        if (this.activity.content0_pageAdapter != null) {
            this.activity.content0_viewPager.setAdapter((PagerAdapter) null);
            this.activity.content0_pageAdapter = null;
        }
        if (!(this.activity.adapter == null || this.activity.adapter.imageLoader == null)) {
            this.activity.adapter.imageLoader.stopThread();
            try {
                this.activity.adapter.imageLoader.photoLoaderThread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        if (this.activity.adapter != null) {
            this.activity.gridView.setAdapter((ListAdapter) null);
        }
        if (!this.activity.getMediaData().booleanValue()) {
            this.activity.finish();
            return;
        }
        this.activity.getCurrentData();
        this.activity.initialGridView();
        if (!this.activity.isInPause.booleanValue()) {
            this.activity.settingKernelToUI();
        }
        this.activity.gProgressDlg.dismiss();
        if (!this.activity.isInPause.booleanValue()) {
            this.activity.isAsyncTaskDialogOn = false;
            this.activity.isAsyncTaskDirtyWork = false;
        } else {
            this.activity.isAsyncTaskDialogOn = false;
            this.activity.isAsyncTaskDirtyWork = true;
        }
        super.onPostExecute(result);
    }

    /* access modifiers changed from: protected */
    public void onCancelled() {
        this.running = false;
    }
}
