package com.jkfantasy.photopoinokia;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.HashMap;
import java.util.List;

public class PromoteExpandableListAdapter extends BaseExpandableListAdapter {
    private Context _context;
    private HashMap<String, List<PromoteItem>> _listDataChild;
    private List<String> _listDataHeader;

    public PromoteExpandableListAdapter(Context context, List<String> listDataHeader, HashMap<String, List<PromoteItem>> listChildData) {
        this._context = context;
        this._listDataHeader = listDataHeader;
        this._listDataChild = listChildData;
    }

    public Object getChild(int groupPosition, int childPosititon) {
        return this._listDataChild.get(this._listDataHeader.get(groupPosition)).get(childPosititon);
    }

    public long getChildId(int groupPosition, int childPosition) {
        return (long) childPosition;
    }

    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        PromoteItem promoteItem = (PromoteItem) getChild(groupPosition, childPosition);
        if (convertView == null) {
            convertView = ((LayoutInflater) this._context.getSystemService("layout_inflater")).inflate(R.layout.explv_promote_list_item, (ViewGroup) null);
        }
        ((ImageView) convertView.findViewById(R.id.iv_list_item)).setImageDrawable(this._context.getResources().getDrawable(promoteItem.getDrawableId()));
        ((TextView) convertView.findViewById(R.id.tv_list_item)).setText(promoteItem.getAppName());
        return convertView;
    }

    public int getChildrenCount(int groupPosition) {
        return this._listDataChild.get(this._listDataHeader.get(groupPosition)).size();
    }

    public Object getGroup(int groupPosition) {
        return this._listDataHeader.get(groupPosition);
    }

    public int getGroupCount() {
        return this._listDataHeader.size();
    }

    public long getGroupId(int groupPosition) {
        return (long) groupPosition;
    }

    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        String headerTitle = (String) getGroup(groupPosition);
        if (convertView == null) {
            convertView = ((LayoutInflater) this._context.getSystemService("layout_inflater")).inflate(R.layout.explv_promote_list_group, (ViewGroup) null);
        }
        TextView lblListHeader = (TextView) convertView.findViewById(R.id.tv_list_group);
        lblListHeader.setTypeface((Typeface) null, 1);
        lblListHeader.setText(headerTitle);
        return convertView;
    }

    public boolean hasStableIds() {
        return false;
    }

    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }
}
