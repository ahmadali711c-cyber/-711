package com.jkfantasy.photopoinokia;

import android.location.Address;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ReverseGeocode {
    public static List<Address> getFromLocation(double lat, double lon, int maxResults) {
        String response = "";
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new DefaultHttpClient().execute(new HttpGet("http://maps.googleapis.com/maps/api/geocode/json?latlng=" + lat + "," + lon + "&sensor=false&language=" + Locale.getDefault().toString())).getEntity().getContent()));
            while (true) {
                String buff = br.readLine();
                if (buff == null) {
                    break;
                }
                response = String.valueOf(response) + buff;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        String statusString = null;
        try {
            JSONObject jSONObject = new JSONObject(response);
            if (jSONObject != null) {
                try {
                    statusString = jSONObject.getString("status");
                } catch (JSONException e1) {
                    e1.printStackTrace();
                }
                if (statusString != null && statusString.equalsIgnoreCase("OK")) {
                    String addressLine = null;
                    String countryName = null;
                    String adminArea = null;
                    String locality = null;
                    String thoroughFare = null;
                    String admin1Area = null;
                    String admin2Area = null;
                    String admin3Area = null;
                    try {
                        JSONArray results = (JSONArray) jSONObject.get("results");
                        for (int i = 0; i < 1; i++) {
                            JSONObject result = results.getJSONObject(i);
                            if (result.has("formatted_address")) {
                                addressLine = result.getString("formatted_address");
                            }
                            if (result.has("address_components")) {
                                JSONArray addressComponents = result.getJSONArray("address_components");
                                for (int j = 0; j < addressComponents.length(); j++) {
                                    JSONObject addressComponent = addressComponents.getJSONObject(j);
                                    if (result.has("types")) {
                                        JSONArray types = addressComponent.getJSONArray("types");
                                        for (int k = 0; k < types.length(); k++) {
                                            if ("country".equals(types.getString(k)) && countryName == null) {
                                                if (addressComponent.has("long_name")) {
                                                    countryName = addressComponent.getString("long_name");
                                                } else if (addressComponent.has("short_name")) {
                                                    countryName = addressComponent.getString("short_name");
                                                }
                                            }
                                            if ("administrative_area_level_1".equals(types.getString(k)) && admin1Area == null) {
                                                if (addressComponent.has("long_name")) {
                                                    admin1Area = addressComponent.getString("long_name");
                                                } else if (addressComponent.has("short_name")) {
                                                    admin1Area = addressComponent.getString("short_name");
                                                }
                                            }
                                            if ("administrative_area_level_2".equals(types.getString(k)) && admin2Area == null) {
                                                if (addressComponent.has("long_name")) {
                                                    admin2Area = addressComponent.getString("long_name");
                                                } else if (addressComponent.has("short_name")) {
                                                    admin2Area = addressComponent.getString("short_name");
                                                }
                                            }
                                            if ("administrative_area_level_3".equals(types.getString(k)) && admin3Area == null) {
                                                if (addressComponent.has("long_name")) {
                                                    admin3Area = addressComponent.getString("long_name");
                                                } else if (addressComponent.has("short_name")) {
                                                    admin3Area = addressComponent.getString("short_name");
                                                }
                                            }
                                            if ("locality".equals(types.getString(k)) && locality == null) {
                                                if (addressComponent.has("long_name")) {
                                                    locality = addressComponent.getString("long_name");
                                                } else if (addressComponent.has("short_name")) {
                                                    locality = addressComponent.getString("short_name");
                                                }
                                            }
                                            if ("route".equals(types.getString(k)) && thoroughFare == null) {
                                                if (addressComponent.has("long_name")) {
                                                    thoroughFare = addressComponent.getString("long_name");
                                                } else if (addressComponent.has("short_name")) {
                                                    thoroughFare = addressComponent.getString("short_name");
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } catch (JSONException e2) {
                        e2.printStackTrace();
                    }
                    if (admin3Area != null) {
                        adminArea = admin3Area;
                    } else if (admin2Area != null) {
                        adminArea = admin2Area;
                    } else if (admin1Area != null) {
                        adminArea = admin1Area;
                    }
                    if (!(addressLine == null && countryName == null && adminArea == null && locality == null && thoroughFare == null)) {
                        Address addy = new Address(Locale.getDefault());
                        addy.setAddressLine(0, addressLine);
                        addy.setCountryName(countryName);
                        addy.setAdminArea(adminArea);
                        addy.setLocality(locality);
                        addy.setThoroughfare(thoroughFare);
                        ArrayList arrayList = new ArrayList();
                        arrayList.add(addy);
                        return arrayList;
                    }
                }
            }
            return null;
        } catch (JSONException e3) {
            return null;
        }
    }
}
