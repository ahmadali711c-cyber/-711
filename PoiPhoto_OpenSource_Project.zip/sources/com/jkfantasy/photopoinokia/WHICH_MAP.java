package com.jkfantasy.photopoinokia;

/* compiled from: MainActivity */
class WHICH_MAP {
    static int AMAZON_MAP_ANDROID = 3;
    static int BAIDU_MAP_ANDROID = 2;
    static int GOOGLE_MAP_ANDROID_V2 = 0;
    static int GOOGLE_MAP_JS_V3 = 1;
    static int NOKIA_MAP_JS = 4;

    WHICH_MAP() {
    }
}
